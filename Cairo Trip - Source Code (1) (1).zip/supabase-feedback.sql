-- ============================================================================
-- Cairo Trip - Feedback table (public submissions, name required)
-- Run once in the Supabase SQL editor. Idempotent.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.feedback (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name       TEXT NOT NULL,
  email      TEXT,
  rating     INTEGER CHECK (rating BETWEEN 1 AND 5),
  message    TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;

-- Anyone (even signed-out QR scanners) may submit feedback.
DROP POLICY IF EXISTS "Anyone can submit feedback" ON public.feedback;
CREATE POLICY "Anyone can submit feedback"
  ON public.feedback FOR INSERT WITH CHECK (true);

-- Only admins can read the submissions.
DROP POLICY IF EXISTS "Admins can read feedback" ON public.feedback;
CREATE POLICY "Admins can read feedback"
  ON public.feedback FOR SELECT USING (public.is_admin());

-- Keep intake clean: the submitter cannot backdate rows.
CREATE OR REPLACE FUNCTION public.enforce_feedback_create()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.created_at := now();
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS trg_enforce_feedback_create ON public.feedback;
CREATE TRIGGER trg_enforce_feedback_create
  BEFORE INSERT ON public.feedback
  FOR EACH ROW EXECUTE FUNCTION public.enforce_feedback_create();
