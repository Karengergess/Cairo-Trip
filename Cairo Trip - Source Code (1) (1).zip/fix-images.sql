UPDATE public.profiles SET role = 'admin' WHERE id = (
  SELECT id FROM auth.users WHERE email = 'admin@egypttrip.com'
);



UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/1897_bis_1902_wurde_das_%C3%84gyptische_Museum_in_Kairo_gebaut._04.jpg/960px-1897_bis_1902_wurde_das_%C3%84gyptische_Museum_in_Kairo_gebaut._04.jpg' WHERE name = 'Egyptian Museum';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/%D8%AE%D8%A7%D9%86_%D8%A7%D9%84%D8%AE%D9%84%D9%8A%D9%84%D9%8A_1.jpg/960px-%D8%AE%D8%A7%D9%86_%D8%A7%D9%84%D8%AE%D9%84%D9%8A%D9%84%D9%8A_1.jpg' WHERE name = 'Khan El-Khalili Bazaar';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Mosqu%C3%A9e_Al-Azhar.jpg/960px-Mosqu%C3%A9e_Al-Azhar.jpg' WHERE name = 'Al-Azhar Mosque';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/GEM%2C_December_22nd%2C_2025%2C_by_Dyolf77%2C_ZVE07664.jpg/960px-GEM%2C_December_22nd%2C_2025%2C_by_Dyolf77%2C_ZVE07664.jpg' WHERE name = 'Grand Egyptian Museum';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Cairotower.jpg/960px-Cairotower.jpg' WHERE name = 'Cairo Tower';

UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Pyramids_of_the_Giza_Necropolis.jpg/960px-Pyramids_of_the_Giza_Necropolis.jpg' WHERE name = 'Great Pyramids of Giza';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Sphinx_with_the_third_pyramid.jpg/960px-Sphinx_with_the_third_pyramid.jpg' WHERE name = 'Great Sphinx';

UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/0/0c/Luxor%2C_Tal_der_K%C3%B6nige_%281995%2C_860x605%29.jpg' WHERE name = 'Valley of the Kings';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/Temple_de_Louxor_68.jpg/960px-Temple_de_Louxor_68.jpg' WHERE name = 'Karnak Temple';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/Templo_de_Luxor%2C_Luxor%2C_Egipto%2C_2022-04-01%2C_DD_01.jpg/960px-Templo_de_Luxor%2C_Luxor%2C_Egipto%2C_2022-04-01%2C_DD_01.jpg' WHERE name = 'Luxor Temple';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Tempel_der_Hatschepsut_%28Deir_el-Bahari%29.jpg/960px-Tempel_der_Hatschepsut_%28Deir_el-Bahari%29.jpg' WHERE name = 'Hatshepsut Temple';

UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Philae_temple.jpg/960px-Philae_temple.jpg' WHERE name = 'Philae Temple';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/BarragemAssu%C3%A3o.jpg/960px-BarragemAssu%C3%A3o.jpg' WHERE name = 'Aswan High Dam';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Nubians_at_Aswan.jpg/960px-Nubians_at_Aswan.jpg' WHERE name = 'Nubian Village';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/Ramsis%2C_Aswan_Governorate%2C_Egypt_-_panoramio.jpg/960px-Ramsis%2C_Aswan_Governorate%2C_Egypt_-_panoramio.jpg' WHERE name = 'Abu Simbel Temples';

UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Giftun_Soraya01.JPG/960px-Giftun_Soraya01.JPG' WHERE name = 'Giftun Island';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Hurghada_Hotels_R03.jpg/960px-Hurghada_Hotels_R03.jpg' WHERE name = 'Hurghada Marina';

UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/%D8%A8%D9%88%D8%A7%D8%A8%D8%A7%D8%AA_%D9%85%D8%AD%D9%85%D9%8A%D9%87_%D8%B1%D8%A7%D8%B3_%D9%85%D8%AD%D9%85%D8%AF.png/960px-%D8%A8%D9%88%D8%A7%D8%A8%D8%A7%D8%AA_%D9%85%D8%AD%D9%85%D9%8A%D9%87_%D8%B1%D8%A7%D8%B3_%D9%85%D8%AD%D9%85%D8%AF.png' WHERE name = 'Ras Mohammed National Park';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Naama_Bay_R01.jpg/960px-Naama_Bay_R01.jpg' WHERE name = 'Naama Bay';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Blue_Whole%2C_Dahab.jpg/960px-Blue_Whole%2C_Dahab.jpg' WHERE name = 'Blue Hole' AND city_id = (SELECT id FROM cities WHERE slug='sharm-el-sheikh');

UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Alexandria%27s_Bibliotheca.jpg/960px-Alexandria%27s_Bibliotheca.jpg' WHERE name = 'Bibliotheca Alexandrina';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/QaitbeyCitadel.jpg/960px-QaitbeyCitadel.jpg' WHERE name = 'Qaitbay Citadel';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ab/At_monatza_palace.jpg/960px-At_monatza_palace.jpg' WHERE name = 'Montaza Palace Gardens';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/...Catacombsa.jpg/960px-...Catacombsa.jpg' WHERE name = 'Catacombs of Kom El-Shoqafa';

UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Blue_Whole%2C_Dahab.jpg/960px-Blue_Whole%2C_Dahab.jpg' WHERE name = 'Blue Hole Dahab';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Naama_Bay_R01.jpg/960px-Naama_Bay_R01.jpg' WHERE name = 'Three Pools';
UPDATE public.attractions SET image_url = 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Mount_Sinai_from_the_southwest.jpg/960px-Mount_Sinai_from_the_southwest.jpg' WHERE name = 'Mount Sinai';


UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/The_Oberoi_-_Mena_House%2C_Egypt.jpg/960px-The_Oberoi_-_Mena_House%2C_Egypt.jpg"]' WHERE name = 'Marriott Mena House';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Cairo_From_Tower_4.jpg/960px-Cairo_From_Tower_4.jpg"]' WHERE name = 'Four Seasons Nile Plaza';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/1897_bis_1902_wurde_das_%C3%84gyptische_Museum_in_Kairo_gebaut._04.jpg/960px-1897_bis_1902_wurde_das_%C3%84gyptische_Museum_in_Kairo_gebaut._04.jpg"]' WHERE name = 'Steigenberger El Tahrir';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Cairo_From_Tower_4.jpg/960px-Cairo_From_Tower_4.jpg"]' WHERE name = 'Le Meridien Cairo Airport';

UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/All_Gizah_Pyramids.jpg/960px-All_Gizah_Pyramids.jpg"]' WHERE name = 'Pyramids View Inn';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/All_Gizah_Pyramids.jpg/960px-All_Gizah_Pyramids.jpg"]' WHERE name = 'Guardian Guest House';

UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/3/35/LuxorHotelsIbnWalidSt.jpg"]' WHERE name = 'Sofitel Winter Palace';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/3/35/LuxorHotelsIbnWalidSt.jpg"]' WHERE name = 'Steigenberger Nile Palace';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/3/35/LuxorHotelsIbnWalidSt.jpg"]' WHERE name = 'Bob Marley Hostel';

UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Aswan_Nile_R02.jpg/960px-Aswan_Nile_R02.jpg"]' WHERE name = 'Sofitel Legend Old Cataract';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Panoramic_view_of_Aswan%2C_Egypt.jpg/960px-Panoramic_view_of_Aswan%2C_Egypt.jpg"]' WHERE name = 'Basma Hotel';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Nubians_at_Aswan.jpg/960px-Nubians_at_Aswan.jpg"]' WHERE name = 'Ekadolli Nubian Guesthouse';

UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Hurghada_Hotels_R03.jpg/960px-Hurghada_Hotels_R03.jpg"]' WHERE name = 'Steigenberger Al Dau Beach';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Hurghada_Hotels_R03.jpg/960px-Hurghada_Hotels_R03.jpg"]' WHERE name = 'Jaz Aquamarine Resort';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Hurghada_Hotels_R03.jpg/960px-Hurghada_Hotels_R03.jpg"]' WHERE name = 'Sea Horse Hotel';

UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Sharm_El_Sheikh_Panoramic.jpg/960px-Sharm_El_Sheikh_Panoramic.jpg"]' WHERE name = 'Four Seasons Sharm';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Naama_Bay_R01.jpg/960px-Naama_Bay_R01.jpg"]' WHERE name = 'Rixos Premium Seagate';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Naama_Bay_R01.jpg/960px-Naama_Bay_R01.jpg"]' WHERE name = 'Camel Hotel';

UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/San_Stefano_Grand_Plaza.JPG/960px-San_Stefano_Grand_Plaza.JPG"]' WHERE name = 'Four Seasons Alexandria';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Cecil_Hotel_Alexandria_%286896067741%29.jpg/960px-Cecil_Hotel_Alexandria_%286896067741%29.jpg"]' WHERE name = 'Steigenberger Cecil';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/San_Stefano_Grand_Plaza.JPG/960px-San_Stefano_Grand_Plaza.JPG"]' WHERE name = 'Cherry Maryski Hotel';

UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Dahab_-_Egypte_07-2012_%287614814042%29.jpg/960px-Dahab_-_Egypte_07-2012_%287614814042%29.jpg"]' WHERE name = 'Le Meridien Dahab';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Dahab_-_Egypte_07-2012_%287614814042%29.jpg/960px-Dahab_-_Egypte_07-2012_%287614814042%29.jpg"]' WHERE name = 'Alaska Camp & Hotel';
UPDATE public.hotels SET image_urls = '["https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Dahab_-_Egypte_07-2012_%287614814042%29.jpg/960px-Dahab_-_Egypte_07-2012_%287614814042%29.jpg"]' WHERE name = 'Coral Coast Hotel';
