# Egypt Trip Planner

Full-stack trip planning application for Egypt. Built with Next.js 15, Supabase, and Tailwind CSS.

Covers 8 cities, 26 hotels, 28 attractions, and emergency services across Cairo, Giza, Luxor, Aswan, Hurghada, Sharm El-Sheikh, Alexandria, and Dahab.

## Tech Stack

- **Framework**: Next.js 15 (App Router) + TypeScript
- **Styling**: Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Storage)
- **Deployment**: Vercel
- **Maps**: Leaflet + OpenStreetMap + Overpass API
- **Weather**: OpenWeatherMap API
- **Animations**: Framer Motion
- **Icons**: Lucide React

## Features

- **Bilingual**: Full English and Arabic support with RTL layout switching
- **Role-based access**: Admin panel, user dashboard, guest browsing
- **Interactive map**: Live POIs from OpenStreetMap via Overpass API
- **Trip planner**: Day-by-day itinerary builder with cost tracking
- **Budget tools**: Currency converter (7 currencies), daily cost tips
- **Emergency info**: One-tap call, directions to hospitals/police/pharmacies
- **Crowd estimation**: Heuristic badges based on time and day of week
- **Admin CRUD**: Manage hotels, attractions, cities, users, complaints, bookings

## Pages

| Page | Route | Description |
|------|-------|-------------|
| Home | `/` | Hero, search, featured listings, categories |
| Discover | `/discover` | Interactive map with filter tabs |
| Hotels | `/hotels` | Grid with city/price/star filters |
| Hotel Detail | `/hotels/[id]` | Info, amenities, weather, directions |
| Attractions | `/attractions` | Grid with category filter, crowd badges |
| Attraction Detail | `/attractions/[id]` | Info, hours, tickets, weather |
| Trip Planner | `/planner` | Day-by-day builder, EGP + USD costs |
| Budget | `/budget` | Budget tracker, currency converter |
| Emergency | `/emergency` | Facilities list, one-tap call |
| Complaint | `/complaint` | Submit complaints to admin |
| Booking | `/book` | 3-step booking form |
| Payment | `/payment` | Card / InstaPay options |
| Login | `/auth/login` | Email + password |
| Signup | `/auth/signup` | Registration |
| Profile | `/profile` | Edit name, avatar, language, currency |
| Dashboard | `/dashboard` | Saved places, bookings, quick links |
| Admin | `/admin` | Full CRUD, user management, complaints |
| About | `/about` | Team, mission, tech stack |
| Search | `/search` | Cross-search hotels + attractions |
| UML Diagrams | `/uml-diagrams.html` | 9 diagrams with EN/AR toggle |
| Design System | `/design-system.html` | Colors, typography, components |

## Getting Started

### Prerequisites

- Node.js 18+
- A Supabase project (free tier works)

### Setup

1. Clone the repository

```bash
git clone <repo-url>
cd egypt-trip-planner
```

2. Install dependencies

```bash
npm install
```

3. Configure environment variables

```bash
cp .env.local.example .env.local
# Edit .env.local with your Supabase URL and anon key
```

4. Set up the database

Go to your Supabase dashboard, open the SQL Editor, and run these files in order:
- `supabase-schema.sql` (creates all tables, RLS policies, indexes)
- `supabase-seed.sql` (inserts 8 cities, 26 hotels, 28 attractions, emergency facilities)

5. Start the dev server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### Create an Admin User

1. Sign up through the app at `/auth/signup`
2. In Supabase dashboard, go to Table Editor, open `profiles`
3. Find your user row and change `role` from `user` to `admin`
4. Refresh the app to see the Admin button in the navbar

## Database Schema

| Table | Key Columns |
|-------|------------|
| profiles | id (FK auth.users), full_name, avatar_url, role, is_banned, preferred_language, preferred_currency |
| cities | id, slug (unique), name, name_ar, description, image_url, latitude, longitude |
| hotels | id, city_id (FK), name, name_ar, star_rating, price_per_night_usd, amenities (jsonb), image_urls (jsonb), booking_url, rating, latitude, longitude |
| attractions | id, city_id (FK), name, name_ar, category, entry_fee_usd, duration_hours, opening_hours (jsonb), crowd_data (jsonb), wikipedia_slug, latitude, longitude, image_url |
| emergency_facilities | id, city_id (FK), name, name_ar, type, phone, latitude, longitude, is_24h |
| bookings | id, user_id (FK), hotel_id (FK), check_in, check_out, guests, total_price_usd, status |
| saved_places | id, user_id (FK), place_type, place_id, UNIQUE(user_id, place_type, place_id) |
| reviews | id, user_id (FK), place_type, place_id, rating, comment |
| complaints | id, user_id (FK), user_email, category, subject, description, status, admin_notes |

## Deployment

Deploy to Vercel:

```bash
npx vercel
```

Set environment variables in the Vercel dashboard.

## Project Structure

```
src/
  app/              # Next.js App Router pages
    admin/          # Admin panel
    attractions/    # Attractions list + detail
    auth/           # Login + signup
    book/           # Booking flow
    budget/         # Budget tracker + converter
    complaint/      # Complaint form
    dashboard/      # User dashboard
    discover/       # Interactive map
    emergency/      # Emergency facilities
    hotels/         # Hotels list + detail
    payment/        # Payment page
    planner/        # Trip planner
    profile/        # User profile
    search/         # Search results
    about/          # About page
  components/       # Shared components
  contexts/         # React contexts (Auth, Language)
  lib/              # Supabase client, utilities
  types/            # TypeScript type definitions
public/
  uml-diagrams.html # UML diagrams page
  design-system.html # Design system documentation
```
