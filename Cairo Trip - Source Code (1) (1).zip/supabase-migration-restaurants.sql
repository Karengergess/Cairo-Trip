CREATE TABLE IF NOT EXISTS public.restaurants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  city_id UUID NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  description TEXT,
  description_ar TEXT,
  cuisine TEXT NOT NULL DEFAULT 'Egyptian',
  cuisine_ar TEXT,
  price_range INTEGER NOT NULL DEFAULT 2 CHECK (price_range BETWEEN 1 AND 4),
  avg_meal_usd NUMERIC(8,2) NOT NULL DEFAULT 10,
  rating NUMERIC(3,2),
  popular_dishes JSONB DEFAULT '[]'::jsonb,
  opening_hours JSONB,
  image_url TEXT,
  booking_url TEXT,
  phone TEXT,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_restaurants_city ON public.restaurants(city_id);
CREATE INDEX IF NOT EXISTS idx_restaurants_cuisine ON public.restaurants(cuisine);

ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Restaurants are publicly readable" ON public.restaurants;
CREATE POLICY "Restaurants are publicly readable" ON public.restaurants FOR SELECT USING (true);

ALTER TABLE public.saved_places DROP CONSTRAINT IF EXISTS saved_places_place_type_check;
ALTER TABLE public.saved_places ADD CONSTRAINT saved_places_place_type_check
  CHECK (place_type IN ('hotel', 'attraction', 'restaurant'));

INSERT INTO public.restaurants (city_id, name, name_ar, description, description_ar, cuisine, cuisine_ar, price_range, avg_meal_usd, rating, popular_dishes, image_url, latitude, longitude) VALUES
((SELECT id FROM cities WHERE slug='cairo'), 'Abou El Sid', 'أبو السيد', 'Iconic traditional Egyptian restaurant in Zamalek with authentic cuisine and a vintage atmosphere.', 'مطعم مصري تقليدي شهير في الزمالك بأطباق أصيلة وأجواء كلاسيكية.', 'Egyptian', 'مصري', 3, 25, 4.5, '["Molokhia","Stuffed Pigeon","Koshari","Mahshi"]', 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80', 30.0594, 31.2189),
((SELECT id FROM cities WHERE slug='cairo'), 'Felfela', 'فلفلة', 'Famous downtown spot serving classic Egyptian street food since 1959. A Cairo legend.', 'مكان شهير في وسط البلد يقدم الأكل المصري الشعبي الكلاسيكي منذ ١٩٥٩. أسطورة قاهرية.', 'Egyptian', 'مصري', 1, 8, 4.3, '["Foul","Falafel","Shawarma","Liver"]', 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', 30.0488, 31.2412),
((SELECT id FROM cities WHERE slug='cairo'), 'Sequoia', 'سيكويا', 'Upscale Mediterranean restaurant on the Nile with stunning sunset views and modern decor.', 'مطعم متوسطي راقي على النيل بإطلالة غروب خلابة وديكور عصري.', 'Mediterranean', 'متوسطي', 4, 45, 4.6, '["Grilled Seafood","Lamb","Tagine","Mezze"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 30.0729, 31.2233),
((SELECT id FROM cities WHERE slug='cairo'), 'Koshary Abou Tarek', 'كشري أبو طارق', 'The most legendary koshari shop in Egypt. Five floors of pure carb heaven downtown.', 'أشهر محل كشري في مصر. خمسة أدوار من جنة الكشري في وسط البلد.', 'Street Food', 'أكل شعبي', 1, 4, 4.7, '["Koshari","Macaroni","Lentils","Rice"]', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80', 30.0526, 31.2402),
((SELECT id FROM cities WHERE slug='giza'), '9 Pyramids Lounge', 'تسعة أهرامات لاونج', 'Restaurant inside the Pyramids complex with direct views of all 9 pyramids. Truly unique.', 'مطعم داخل منطقة الأهرامات بإطلالة مباشرة على الـ٩ أهرامات. تجربة فريدة.', 'Egyptian', 'مصري', 3, 30, 4.4, '["Grilled Kofta","Mixed Grill","Mezze","Hummus"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 29.9750, 31.1310),
((SELECT id FROM cities WHERE slug='giza'), 'Andrea', 'أندريا', 'Family-favorite grilled chicken and Egyptian appetizers in a garden setting near the Pyramids.', 'مطعم عائلي شهير بالفراخ المشوية والمقبلات المصرية في حديقة قرب الأهرامات.', 'Egyptian', 'مصري', 2, 15, 4.2, '["Grilled Chicken","Salads","Bread","Tahini"]', 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', 29.9890, 31.1492),
((SELECT id FROM cities WHERE slug='luxor'), 'Sofra', 'سفرة', 'Beautiful traditional restaurant in a restored Luxor mansion, serving authentic Upper Egyptian cuisine.', 'مطعم تقليدي جميل في فيلا أقصرية مرممة، يقدم أكلات صعيدية أصيلة.', 'Egyptian', 'مصري', 2, 18, 4.7, '["Tagine","Stuffed Pigeon","Fattah","Molokhia"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 25.7012, 32.6394),
((SELECT id FROM cities WHERE slug='luxor'), '1886 Restaurant', '١٨٨٦', 'Fine dining at the historic Winter Palace hotel. Expect colonial elegance and refined Egyptian-French cuisine.', 'مطعم فاخر في فندق وينتر بالاس التاريخي. أناقة كولونيالية ومطبخ مصري-فرنسي راقي.', 'Fine Dining', 'مطبخ راقي', 4, 60, 4.8, '["Duck","Grilled Sea Bass","Beef Wellington","Soufflé"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 25.6986, 32.6397),
((SELECT id FROM cities WHERE slug='aswan'), 'Bob Marley Peace Hotel Restaurant', 'بوب مارلي', 'Nubian rooftop dining with Nile views. Famous for fresh fish from the river.', 'مطعم نوبي على السطح بإطلالة على النيل. شهير بالسمك الطازج.', 'Nubian', 'نوبي', 1, 7, 4.4, '["Grilled Tilapia","Nubian Tagine","Bamia","Rice"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 24.0902, 32.8997),
((SELECT id FROM cities WHERE slug='aswan'), '1902 Restaurant', '١٩٠٢', 'Legendary restaurant at Old Cataract hotel where royalty dined. Domed Moorish architecture.', 'مطعم أسطوري في فندق أولد كتراكت أكل فيه الملوك. عمارة مغربية بقباب.', 'Fine Dining', 'مطبخ راقي', 4, 70, 4.9, '["Grilled Lobster","Lamb","Foie Gras","Local Fish"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 24.0849, 32.8879),
((SELECT id FROM cities WHERE slug='hurghada'), 'Star Fish Restaurant', 'ستار فيش', 'Beach-front seafood spot with the freshest catch of the day. Pick your fish, they grill it.', 'مطعم سمك على الشاطئ بأطيب صيد اليوم. اختار سمكتك وهيشويها لك.', 'Seafood', 'مأكولات بحرية', 2, 20, 4.5, '["Grilled Sea Bass","Calamari","Shrimp","Fish Tagine"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 27.2345, 33.8412),
((SELECT id FROM cities WHERE slug='hurghada'), 'White Elephant Thai', 'وايت إليفنت تاي', 'Authentic Thai restaurant inside Sheraton hotel. Best non-Egyptian food in Hurghada.', 'مطعم تايلاندي أصيل داخل فندق شيراتون. أحسن أكل غير مصري في الغردقة.', 'Thai', 'تايلاندي', 3, 28, 4.6, '["Pad Thai","Tom Yum","Green Curry","Mango Sticky Rice"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 27.1851, 33.8338),
((SELECT id FROM cities WHERE slug='sharm-el-sheikh'), 'El Masrien', 'المصريين', 'Two-story Egyptian grill house in Old Market. Massive portions, friendly prices.', 'مطعم مشويات مصري دورين في السوق القديم. الكميات كبيرة والأسعار حلوة.', 'Egyptian', 'مصري', 2, 14, 4.3, '["Mixed Grill","Kofta","Liver","Rice"]', 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80', 27.8595, 34.2929),
((SELECT id FROM cities WHERE slug='sharm-el-sheikh'), 'Pomodoro', 'بومودورو', 'Cozy Italian trattoria in Naama Bay. Wood-fired pizza and homemade pasta.', 'مطعم إيطالي دافئ في خليج نعمة. بيتزا فرن حطب ومكرونة منزلية.', 'Italian', 'إيطالي', 2, 18, 4.4, '["Margherita Pizza","Carbonara","Lasagna","Tiramisu"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 27.9118, 34.3216),
((SELECT id FROM cities WHERE slug='alexandria'), 'Mohamed Ahmed', 'محمد أحمد', 'A breakfast institution in Alex. Best foul and falafel since 1957. Always packed.', 'مؤسسة فطار في إسكندرية. أحسن فول وفلافل من ١٩٥٧. دايماً زحمة.', 'Street Food', 'أكل شعبي', 1, 4, 4.8, '["Foul","Falafel","Eggs","Pickles"]', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80', 31.2010, 29.8980),
((SELECT id FROM cities WHERE slug='alexandria'), 'Kadoura', 'قدورة', 'Legendary seafood restaurant on Bahary corniche. Order the catch of the day.', 'مطعم سمك أسطوري على كورنيش بحري. اطلب صيد اليوم.', 'Seafood', 'مأكولات بحرية', 2, 22, 4.7, '["Grilled Sea Bream","Shrimp Soup","Calamari","Sayadeya Rice"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 31.2144, 29.8835),
((SELECT id FROM cities WHERE slug='dahab'), 'Athanor', 'أثانور', 'Wood-fired pizza right on the beach in Dahab. Watch the sun set over the Red Sea while you eat.', 'بيتزا فرن حطب على الشاطئ في دهب. شوف الغروب على البحر الأحمر وأنت بتاكل.', 'Italian', 'إيطالي', 2, 16, 4.6, '["Wood-Fired Pizza","Pasta","Salads","Bruschetta"]', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80', 28.4969, 34.5184);
