-- ============================================================================
-- Cairo Trip - Security Hardening v2
-- Closes: price tampering, self-confirm, privilege-escalation (INSERT path),
--         complaint spoofing, payment-proof path abuse.
-- Safe to run multiple times (idempotent). Run BEFORE deploying the v2 code.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. PROFILES: guard role / is_banned on INSERT *and* UPDATE (was UPDATE-only)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.guard_profile_privileged_fields()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- A self-served INSERT may only create a plain, unbanned user.
    IF (NEW.role IS DISTINCT FROM 'user' OR NEW.is_banned IS DISTINCT FROM false)
       AND NOT public.is_admin() THEN
      RAISE EXCEPTION 'Not authorized to set role or ban status';
    END IF;
    RETURN NEW;
  END IF;

  -- UPDATE path
  IF (NEW.role IS DISTINCT FROM OLD.role)
     OR (NEW.is_banned IS DISTINCT FROM OLD.is_banned) THEN
    IF NOT public.is_admin() THEN
      RAISE EXCEPTION 'Not authorized to change role or ban status';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_guard_profile_privileged_fields ON public.profiles;
CREATE TRIGGER trg_guard_profile_privileged_fields
  BEFORE INSERT OR UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.guard_profile_privileged_fields();

-- Pin role/ban in the INSERT policy too (defense in depth alongside the trigger)
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id AND role = 'user' AND is_banned = false);

-- ---------------------------------------------------------------------------
-- 2. BOOKINGS: server-authoritative price + status on INSERT, locked on UPDATE
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_booking_create()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  nightly   NUMERIC(10,2);
  nights    INTEGER;
  base      NUMERIC(12,2);
  k         NUMERIC;
BEGIN
  -- Always start clean. No client may pre-confirm or pre-mark as paid.
  NEW.status            := 'pending';
  NEW.paid_at           := NULL;
  NEW.payment_method    := NULL;
  NEW.payment_proof_url := NULL;

  -- Basic date sanity
  IF NEW.check_out <= NEW.check_in THEN
    RAISE EXCEPTION 'Check-out must be after check-in';
  END IF;
  IF NEW.check_in < CURRENT_DATE THEN
    RAISE EXCEPTION 'Check-in cannot be in the past';
  END IF;

  SELECT price_per_night_usd INTO nightly FROM public.hotels WHERE id = NEW.hotel_id;
  IF nightly IS NULL THEN
    RAISE EXCEPTION 'Unknown hotel';
  END IF;

  nights := GREATEST(1, NEW.check_out - NEW.check_in);
  base   := nightly * nights;            -- price for one room

  -- The legitimate client total is base x rooms, rooms in 1..5.
  -- Reject anything that is not an exact 1..5 multiple of one room's price.
  IF base = 0 THEN
    RAISE EXCEPTION 'Hotel has no nightly rate';
  END IF;
  k := NEW.total_price_usd / base;
  IF k <> ROUND(k) OR k < 1 OR k > 5 THEN
    RAISE EXCEPTION 'Invalid total price for this stay';
  END IF;

  -- Guest count must fit the implied room count (4 guests per room)
  IF NEW.guests < 1 OR NEW.guests > k * 4 THEN
    RAISE EXCEPTION 'Guest count does not match the rooms paid for';
  END IF;

  -- Availability: no overlap with an existing non-cancelled booking
  IF EXISTS (
    SELECT 1 FROM public.bookings b
    WHERE b.hotel_id = NEW.hotel_id
      AND b.status <> 'cancelled'
      AND b.check_in < NEW.check_out
      AND b.check_out > NEW.check_in
  ) THEN
    RAISE EXCEPTION 'These dates are already booked at this hotel';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_booking_create ON public.bookings;
CREATE TRIGGER trg_enforce_booking_create
  BEFORE INSERT ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.enforce_booking_create();

CREATE OR REPLACE FUNCTION public.enforce_booking_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.is_admin() THEN
    RETURN NEW;                          -- admins may do anything
  END IF;
  -- Owner may only record payment + cancel. Everything money/identity is frozen.
  IF NEW.total_price_usd IS DISTINCT FROM OLD.total_price_usd
     OR NEW.user_id  IS DISTINCT FROM OLD.user_id
     OR NEW.hotel_id IS DISTINCT FROM OLD.hotel_id
     OR NEW.check_in IS DISTINCT FROM OLD.check_in
     OR NEW.check_out IS DISTINCT FROM OLD.check_out
     OR NEW.guests   IS DISTINCT FROM OLD.guests THEN
    RAISE EXCEPTION 'You cannot modify the price or details of a booking';
  END IF;
  -- Only an admin may move a booking to confirmed.
  IF NEW.status = 'confirmed' AND OLD.status <> 'confirmed' THEN
    RAISE EXCEPTION 'Only an administrator can confirm a booking';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_booking_update ON public.bookings;
CREATE TRIGGER trg_enforce_booking_update
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.enforce_booking_update();

-- ---------------------------------------------------------------------------
-- 3. TICKETS: same model (price = people x entry fee; admin-only confirm)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.enforce_ticket_create()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  fee NUMERIC(10,2);
BEGIN
  NEW.status            := 'pending';
  NEW.paid_at           := NULL;
  NEW.payment_method    := NULL;
  NEW.payment_proof_url := NULL;

  IF NEW.visit_date < CURRENT_DATE THEN
    RAISE EXCEPTION 'Visit date cannot be in the past';
  END IF;
  IF NEW.num_people < 1 OR NEW.num_people > 20 THEN
    RAISE EXCEPTION 'Invalid number of people';
  END IF;

  SELECT entry_fee_usd INTO fee FROM public.attractions WHERE id = NEW.attraction_id;
  IF fee IS NULL THEN
    RAISE EXCEPTION 'Unknown attraction';
  END IF;

  -- Server owns the price. No client total is trusted.
  NEW.total_price_usd := fee * NEW.num_people;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_ticket_create ON public.tickets;
CREATE TRIGGER trg_enforce_ticket_create
  BEFORE INSERT ON public.tickets
  FOR EACH ROW EXECUTE FUNCTION public.enforce_ticket_create();

CREATE OR REPLACE FUNCTION public.enforce_ticket_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.is_admin() THEN
    RETURN NEW;
  END IF;
  IF NEW.total_price_usd IS DISTINCT FROM OLD.total_price_usd
     OR NEW.user_id       IS DISTINCT FROM OLD.user_id
     OR NEW.attraction_id IS DISTINCT FROM OLD.attraction_id
     OR NEW.visit_date    IS DISTINCT FROM OLD.visit_date
     OR NEW.num_people    IS DISTINCT FROM OLD.num_people THEN
    RAISE EXCEPTION 'You cannot modify the price or details of a ticket';
  END IF;
  IF NEW.status = 'confirmed' AND OLD.status <> 'confirmed' THEN
    RAISE EXCEPTION 'Only an administrator can confirm a ticket';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_ticket_update ON public.tickets;
CREATE TRIGGER trg_enforce_ticket_update
  BEFORE UPDATE ON public.tickets
  FOR EACH ROW EXECUTE FUNCTION public.enforce_ticket_update();

-- ---------------------------------------------------------------------------
-- 4. COMPLAINTS: stop user_id spoofing; force a clean intake state
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS "Users can create complaints" ON public.complaints;
CREATE POLICY "Users can create complaints"
  ON public.complaints FOR INSERT
  WITH CHECK (user_id IS NULL OR auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.enforce_complaint_create()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.status      := 'pending';   -- inserter cannot pre-set workflow state
  NEW.admin_notes := NULL;        -- inserter cannot write admin notes
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_complaint_create ON public.complaints;
CREATE TRIGGER trg_enforce_complaint_create
  BEFORE INSERT ON public.complaints
  FOR EACH ROW EXECUTE FUNCTION public.enforce_complaint_create();

-- ---------------------------------------------------------------------------
-- 5. PAYMENT PROOFS: re-scope uploads to the caller's own folder
--    (the payments migration had loosened this to "any authenticated user")
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS "Authenticated upload payment proofs" ON storage.objects;
CREATE POLICY "Authenticated upload payment proofs"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'payment-proofs'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

-- ============================================================================
-- Done. Verify with:  SELECT tgname FROM pg_trigger WHERE NOT tgisinternal;
-- ============================================================================
