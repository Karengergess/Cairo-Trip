INSERT INTO storage.buckets (id, name, public)
VALUES ('place-images', 'place-images', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Admin can upload place images" ON storage.objects;
CREATE POLICY "Admin can upload place images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'place-images'
    AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

DROP POLICY IF EXISTS "Admin can update place images" ON storage.objects;
CREATE POLICY "Admin can update place images"
  ON storage.objects FOR UPDATE TO authenticated
  USING (
    bucket_id = 'place-images'
    AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

DROP POLICY IF EXISTS "Admin can delete place images" ON storage.objects;
CREATE POLICY "Admin can delete place images"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'place-images'
    AND EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin')
  );

DROP POLICY IF EXISTS "Public read place images" ON storage.objects;
CREATE POLICY "Public read place images"
  ON storage.objects FOR SELECT TO public
  USING (bucket_id = 'place-images');
