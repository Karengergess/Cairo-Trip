ALTER TABLE public.cities ADD COLUMN IF NOT EXISTS region TEXT;
ALTER TABLE public.cities ADD COLUMN IF NOT EXISTS region_ar TEXT;

UPDATE public.cities SET region='Greater Cairo',  region_ar='القاهرة الكبرى' WHERE slug IN ('cairo','giza');
UPDATE public.cities SET region='Upper Egypt',    region_ar='صعيد مصر'        WHERE slug IN ('luxor','aswan');
UPDATE public.cities SET region='Red Sea Coast',  region_ar='ساحل البحر الأحمر' WHERE slug IN ('hurghada','sharm-el-sheikh','dahab');
UPDATE public.cities SET region='Mediterranean',  region_ar='البحر المتوسط'    WHERE slug IN ('alexandria');

CREATE INDEX IF NOT EXISTS idx_cities_region ON public.cities(region);
