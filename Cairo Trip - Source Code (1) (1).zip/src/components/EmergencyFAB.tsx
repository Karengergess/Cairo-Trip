'use client';

import { useState } from 'react';
import { useLang } from '@/contexts/LanguageContext';
import { Phone, X, Siren, ShieldAlert, Flame, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const emergencyNumbers = [
  { name_en: 'Ambulance', name_ar: 'الإسعاف', number: '123', icon: Siren, color: '#e74c3c', bg: 'rgba(231,76,60,0.12)' },
  { name_en: 'Police', name_ar: 'الشرطة', number: '122', icon: ShieldAlert, color: '#3498db', bg: 'rgba(52,152,219,0.12)' },
  { name_en: 'Fire Dept', name_ar: 'المطافئ', number: '180', icon: Flame, color: '#f39c12', bg: 'rgba(243,156,18,0.12)' },
];

export default function EmergencyFAB() {
  const [open, setOpen] = useState(false);
  const { t } = useLang();

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9997]"
            style={{ background: 'rgba(0,0,0,0.15)' }}
            onClick={() => setOpen(false)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="emergency-popup"
            style={{ position: 'fixed', bottom: '6.5rem', right: '2rem', zIndex: 9998 }}
          >
            <div className="emergency-popup-header">
              <AlertTriangle className="w-5 h-5" />
              {t('Emergency Numbers', 'أرقام الطوارئ')}
            </div>
            <div style={{ padding: '1rem 1.25rem 1.25rem' }}>
              {emergencyNumbers.map((item) => (
                <a
                  key={item.number}
                  href={`tel:${item.number}`}
                  className="emergency-item"
                >
                  <div
                    className="emergency-item-icon"
                    style={{ background: item.bg, color: item.color }}
                  >
                    <item.icon className="w-5 h-5" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: '0.92rem', color: 'var(--text-dark)', marginBottom: '0.1rem' }}>
                      {t(item.name_en, item.name_ar)}
                    </div>
                    <div style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--primary)', direction: 'ltr', display: 'inline-block' }}>
                      {item.number}
                    </div>
                  </div>
                  <Phone className="w-5 h-5" style={{ color: 'var(--success)' }} />
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setOpen(!open)}
        className="emergency-fab"
        style={{
          animation: open ? 'none' : 'emergencyPulse 2s ease-in-out infinite',
          transform: open ? 'rotate(45deg)' : undefined,
        }}
        title={t('Emergency Numbers', 'أرقام الطوارئ')}
      >
        {open ? <X className="w-7 h-7" /> : <Siren className="w-7 h-7" />}
      </button>
    </>
  );
}
