'use client';

import { useState } from 'react';

interface Props {
  src?: string | null;
  alt: string;
  fallbackName?: string;
  style?: React.CSSProperties;
  className?: string;
  loading?: 'lazy' | 'eager';
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h) + s.charCodeAt(i) | 0;
  return Math.abs(h);
}

const palettes = [
  ['#c8860a', '#8b5e00'],   // gold
  ['#27ae60', '#1e8449'],   // green
  ['#3498db', '#2874a6'],   // blue
  ['#9b59b6', '#6c3483'],   // purple
  ['#e67e22', '#a04000'],   // orange
  ['#e74c3c', '#922b21'],   // red
  ['#16a085', '#0e6655'],   // teal
  ['#d4ac0d', '#9a7d0a'],   // yellow
];

function getInitials(name: string) {
  const words = name.trim().split(/\s+/);
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  return (words[0][0] + words[1][0]).toUpperCase();
}

export default function SmartImage({ src, alt, fallbackName, style, className, loading = 'lazy' }: Props) {
  const [errored, setErrored] = useState(false);
  const showFallback = !src || errored;
  const name = fallbackName || alt || 'Cairo';
  const palette = palettes[hash(name) % palettes.length];
  const initials = getInitials(name);

  if (showFallback) {
    return (
      <div className={className} style={{
        width: '100%', height: '100%',
        background: `linear-gradient(135deg, ${palette[0]}, ${palette[1]})`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', overflow: 'hidden',
        ...style,
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.18) 0%, transparent 60%)',
        }} />
        <div style={{
          color: '#fff', fontWeight: 900,
          fontSize: 'clamp(2rem, 8vw, 4rem)',
          letterSpacing: '0.05em',
          textShadow: '0 4px 16px rgba(0,0,0,0.25)',
          position: 'relative', zIndex: 1,
        }}>
          {initials}
        </div>
      </div>
    );
  }

  return (
    <img
      src={src!}
      alt={alt}
      loading={loading}
      onError={() => setErrored(true)}
      className={className}
      style={{ width: '100%', height: '100%', objectFit: 'cover', ...style }}
    />
  );
}
