'use client';

import { Heart } from 'lucide-react';
import { useFavorites } from '@/contexts/FavoritesContext';

interface Props {
  type: 'hotel' | 'attraction' | 'restaurant';
  id: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'overlay' | 'inline';
  stopProp?: boolean;
}

export default function FavoriteButton({ type, id, size = 'md', variant = 'overlay', stopProp = true }: Props) {
  const { isFavorite, toggle } = useFavorites();
  const active = isFavorite(type, id);

  const px = size === 'sm' ? 32 : size === 'lg' ? 44 : 38;
  const ic = size === 'sm' ? 16 : size === 'lg' ? 22 : 18;

  const baseStyle: React.CSSProperties = variant === 'overlay'
    ? {
        position: 'absolute',
        top: '0.75rem',
        insetInlineStart: '0.75rem',
        zIndex: 5,
        width: px, height: px,
        borderRadius: '50%',
        background: active ? '#e74c3c' : 'rgba(255,255,255,0.92)',
        backdropFilter: 'blur(6px)',
        border: 'none', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 4px 12px rgba(0,0,0,0.18)',
        transition: 'all 0.2s ease',
      }
    : {
        width: px, height: px,
        borderRadius: '50%',
        background: active ? '#e74c3c' : 'var(--bg-section)',
        border: `1px solid ${active ? '#e74c3c' : 'var(--border)'}`,
        cursor: 'pointer',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all 0.2s ease',
      };

  return (
    <button
      type="button"
      aria-label={active ? 'Remove from favorites' : 'Add to favorites'}
      onClick={(e) => {
        if (stopProp) { e.preventDefault(); e.stopPropagation(); }
        toggle(type, id);
      }}
      style={baseStyle}
    >
      <Heart
        style={{
          width: ic, height: ic,
          color: active ? '#fff' : '#e74c3c',
          fill: active ? '#fff' : 'transparent',
          strokeWidth: 2.2,
        }}
      />
    </button>
  );
}
