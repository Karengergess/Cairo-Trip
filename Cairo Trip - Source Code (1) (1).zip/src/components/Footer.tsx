'use client';

import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { MapPin, Hotel, Compass, UtensilsCrossed, Heart, Mail, Shield } from 'lucide-react';

export default function Footer() {
  const { t, lang } = useLang();
  const isAr = lang === 'ar';

  return (
    <footer style={{
      marginTop: 'auto',
      background: 'linear-gradient(135deg, #1a1a1a 0%, #2c1810 100%)',
      color: 'rgba(255,255,255,0.85)',
      padding: '3rem 1.5rem 1.5rem',
      borderTop: '1px solid rgba(200,134,10,0.15)',
    }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '2rem', marginBottom: '2rem',
        }}>
          {/* Brand */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.85rem' }}>
              <img src="/logo.svg" alt="" style={{ width: 36, height: 36 }} />
              <span style={{ fontWeight: 900, fontSize: '1.1rem', color: '#fff' }}>
                {t('Cairo Trip', 'رحلتك في القاهرة')}
              </span>
            </div>
            <p style={{ fontSize: '0.85rem', lineHeight: 1.6, opacity: 0.7 }}>
              {t(
                'Plan your Cairo trip in one place. Hotels, attractions, restaurants, prices and tips. From the Pyramids of Giza to Khan el-Khalili.',
                'خطط رحلتك في القاهرة في مكان واحد. فنادق، معالم، مطاعم، أسعار وملاحظات. من الأهرامات لخان الخليلي.'
              )}
            </p>
          </div>

          {/* Explore */}
          <div>
            <h4 style={{ fontWeight: 800, fontSize: '0.95rem', marginBottom: '0.85rem', color: '#fff' }}>
              {t('Explore', 'استكشف')}
            </h4>
            {[
              { href: '/attractions', label: t('Attractions', 'معالم'), icon: Compass },
              { href: '/hotels', label: t('Hotels', 'فنادق'), icon: Hotel },
              { href: '/restaurants', label: t('Restaurants', 'مطاعم'), icon: UtensilsCrossed },
              { href: '/discover', label: t('Discover Map', 'الخريطة'), icon: MapPin },
              { href: '/favorites', label: t('Favorites', 'المفضلة'), icon: Heart },
            ].map(l => (
              <Link key={l.href} href={l.href} style={{
                display: 'flex', alignItems: 'center', gap: '0.45rem',
                padding: '0.35rem 0', fontSize: '0.85rem', textDecoration: 'none',
                color: 'rgba(255,255,255,0.7)', transition: 'color 0.15s',
              }}
              onMouseEnter={e => { e.currentTarget.style.color = '#c8860a'; }}
              onMouseLeave={e => { e.currentTarget.style.color = 'rgba(255,255,255,0.7)'; }}>
                <l.icon style={{ width: 13, height: 13 }} /> {l.label}
              </Link>
            ))}
          </div>

          {/* Account */}
          <div>
            <h4 style={{ fontWeight: 800, fontSize: '0.95rem', marginBottom: '0.85rem', color: '#fff' }}>
              {t('Account', 'الحساب')}
            </h4>
            {[
              { href: '/dashboard', label: t('Dashboard', 'لوحة التحكم') },
              { href: '/profile', label: t('Profile', 'الملف الشخصي') },
              { href: '/planner', label: t('Trip Planner', 'مخطط الرحلة') },
              { href: '/budget', label: t('Budget', 'الميزانية') },
              { href: '/complaint', label: t('Contact / Help', 'تواصل / مساعدة') },
            ].map(l => (
              <Link key={l.href} href={l.href} style={{
                display: 'block', padding: '0.35rem 0', fontSize: '0.85rem',
                textDecoration: 'none', color: 'rgba(255,255,255,0.7)',
              }}
              onMouseEnter={e => { e.currentTarget.style.color = '#c8860a'; }}
              onMouseLeave={e => { e.currentTarget.style.color = 'rgba(255,255,255,0.7)'; }}>
                {l.label}
              </Link>
            ))}
          </div>

          {/* Mission */}
          <div>
            <h4 style={{ fontWeight: 800, fontSize: '0.95rem', marginBottom: '0.85rem', color: '#fff' }}>
              {t('Our Mission', 'مهمتنا')}
            </h4>
            <p style={{ fontSize: '0.82rem', lineHeight: 1.6, opacity: 0.7, marginBottom: '0.85rem' }}>
              {t(
                'We make exploring Cairo easier for foreign visitors - better navigation, real prices, and clear cultural context.',
                'نسهّل اكتشاف القاهرة للزوار الأجانب - تنقل أسهل، أسعار حقيقية، وسياق ثقافي واضح.'
              )}
            </p>
            <a href="mailto:hello@egypttripplanner.app" style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
              padding: '0.45rem 0.9rem', borderRadius: '0.5rem',
              background: 'rgba(200,134,10,0.15)', color: '#f4c842',
              fontSize: '0.8rem', fontWeight: 700, textDecoration: 'none',
              border: '1px solid rgba(200,134,10,0.3)',
            }}>
              <Mail style={{ width: 13, height: 13 }} /> {t('Get in touch', 'تواصل معنا')}
            </a>
          </div>
        </div>

        <div style={{
          padding: '1.25rem 1.5rem',
          background: 'rgba(0,0,0,0.25)',
          borderRadius: '0.85rem',
          border: '1px solid rgba(255,255,255,0.06)',
          marginBottom: '1.5rem',
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem' }}>
            <Shield style={{ width: 16, height: 16, color: '#f4c842', flexShrink: 0, marginTop: '0.15rem' }} />
            <div style={{ fontSize: '0.78rem', lineHeight: 1.6, opacity: 0.7 }}>
              <strong style={{ color: '#fff', opacity: 1 }}>{t('Important notice:', 'تنبيه مهم:')}</strong>{' '}
              {t(
                'Cairo Trip is an independent guide that helps foreign visitors navigate Egypt more easily. All prices, opening hours, and routes shown here are best-effort estimates aggregated from public sources and may change without notice. We are not affiliated with any hotel, restaurant, attraction, transport provider, or government body featured on this site, and we do not handle on-the-ground services. Travelers are solely responsible for their own safety, decisions, and arrangements while in Egypt - including following local laws, securing valid travel insurance, verifying booking details directly with the provider, and exercising caution in unfamiliar areas. Cairo Trip and its operators accept no liability for any loss, injury, illness, theft, scam, missed connection, denied entry, or other damage arising from use of this website or any third-party service we link to.',
                'موقع رحلتك في القاهرة هو دليل مستقل يساعد الزوار الأجانب على التنقل في مصر بسهولة أكبر. جميع الأسعار ومواعيد العمل والمسارات المعروضة هي تقديرات مجمعة من مصادر عامة وقد تتغير دون إشعار. لسنا تابعين لأي فندق أو مطعم أو معلم أو جهة نقل أو هيئة حكومية مذكورة في هذا الموقع، ولا نقدم أي خدمات على أرض الواقع. يتحمل المسافر وحده مسؤولية سلامته وقراراته وترتيباته أثناء وجوده في مصر - بما في ذلك الالتزام بالقوانين المحلية، والحصول على تأمين سفر ساري، والتحقق من تفاصيل الحجز مباشرة مع مقدم الخدمة، وتوخي الحذر في المناطق غير المألوفة. لا يتحمل موقع رحلتك في القاهرة أو القائمين عليه أي مسؤولية عن أي خسارة أو إصابة أو مرض أو سرقة أو احتيال أو تأخير أو رفض دخول أو أضرار أخرى ناتجة عن استخدام هذا الموقع أو أي خدمة طرف ثالث.'
              )}
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          paddingTop: '1.25rem', borderTop: '1px solid rgba(255,255,255,0.08)',
          flexWrap: 'wrap', gap: '0.85rem',
        }}>
          <p style={{ fontSize: '0.78rem', opacity: 0.55, margin: 0 }}>
            © {new Date().getFullYear()} {t('Cairo Trip. All rights reserved.', 'رحلتك في القاهرة. جميع الحقوق محفوظة.')}
          </p>
          <p style={{ fontSize: '0.78rem', opacity: 0.55, margin: 0 }}>
            {t('Built with care for travelers ♥', 'صُنع بحب للمسافرين ♥')}
          </p>
        </div>
      </div>
    </footer>
  );
}
