'use client';

import { ReactNode } from 'react';

interface SplitFormLayoutProps {
  gradientColors: string;
  icon: ReactNode;
  title: string;
  subtitle: string;
  extraContent?: ReactNode;
  children: ReactNode;
}

export default function SplitFormLayout({
  gradientColors,
  icon,
  title,
  subtitle,
  extraContent,
  children,
}: SplitFormLayoutProps) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '100px 1rem 3rem', background: 'var(--bg-main)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', maxWidth: 900, width: '100%', borderRadius: '1.5rem', overflow: 'hidden', boxShadow: '0 8px 40px rgba(0,0,0,0.1)', border: '1px solid var(--border)' }}>
        <div className="auth-side-panel" style={{
          background: gradientColors,
          padding: '3rem 2.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'center', color: '#fff',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: -40, right: -40, width: 180, height: 180, borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
          <div style={{ position: 'absolute', bottom: -60, left: -60, width: 220, height: 220, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />
          <div style={{ position: 'relative', zIndex: 1 }}>
            {icon}
            <h2 style={{ fontSize: '1.8rem', fontWeight: 900, marginBottom: '0.75rem', lineHeight: 1.2 }}>
              {title}
            </h2>
            <p style={{ fontSize: '0.95rem', opacity: 0.85, lineHeight: 1.6 }}>
              {subtitle}
            </p>
            {extraContent}
          </div>
        </div>

        <div style={{ background: 'var(--bg-card)', padding: '3rem 2.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          {children}
        </div>
      </div>
    </div>
  );
}
