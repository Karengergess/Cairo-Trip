'use client';

import { useState, useRef, useEffect } from 'react';
import { useLang } from '@/contexts/LanguageContext';
import { MessageCircle, X, Send, Mail, Sparkles, Loader2 } from 'lucide-react';

type Msg = { role: 'user' | 'assistant'; content: string };

const SUGGESTED = {
  en: [
    "How much does it cost to visit the Pyramids?",
    "Best budget hotel near Giza?",
    "Where to eat traditional Egyptian food?",
    "How many days do I need in Cairo?",
  ],
  ar: [
    'كم تكلفة زيارة الأهرامات؟',
    'أرخص فندق قريب من الجيزة؟',
    'أين آكل أكل مصري شعبي؟',
    'كم يوم أحتاج في القاهرة؟',
  ],
};

export default function ChatBot() {
  const { t, lang } = useLang();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const isAr = lang === 'ar';

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading]);

  const send = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    const next: Msg[] = [...messages, { role: 'user', content: trimmed }];
    setMessages(next);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next }),
      });
      const data = await res.json();
      if (data.error) {
        setMessages(m => [...m, { role: 'assistant', content: data.error }]);
      } else {
        setMessages(m => [...m, { role: 'assistant', content: data.reply }]);
      }
    } catch {
      setMessages(m => [...m, { role: 'assistant', content: t('Network error. Email hello@cairotrip.com if it keeps happening.', 'مشكلة في الاتصال. لو استمرت، راسلنا على hello@cairotrip.com') }]);
    } finally {
      setLoading(false);
    }
  };

  const sugList = isAr ? SUGGESTED.ar : SUGGESTED.en;

  return (
    <>
      {!open && (
        <button onClick={() => setOpen(true)} aria-label="Open chat" style={{
          position: 'fixed', bottom: 24, insetInlineStart: 24, zIndex: 90,
          width: 56, height: 56, borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--primary), var(--accent))',
          border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 24px rgba(200,134,10,0.45)',
          color: '#fff', transition: 'transform 0.2s',
        }}
        onMouseEnter={e => { e.currentTarget.style.transform = 'scale(1.08)'; }}
        onMouseLeave={e => { e.currentTarget.style.transform = ''; }}>
          <MessageCircle style={{ width: 26, height: 26 }} />
        </button>
      )}

      {open && (
        <div style={{
          position: 'fixed', bottom: 24, insetInlineStart: 24,
          width: 'min(380px, calc(100vw - 48px))',
          height: 'min(560px, calc(100vh - 100px))',
          borderRadius: '1.25rem', overflow: 'hidden', zIndex: 90,
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          boxShadow: '0 20px 50px rgba(0,0,0,0.18)',
          display: 'flex', flexDirection: 'column',
          animation: 'slideUp 0.2s ease',
        }} dir={isAr ? 'rtl' : 'ltr'}>

          <div style={{
            padding: '1rem 1.25rem',
            background: 'linear-gradient(135deg, var(--primary), var(--accent))',
            color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <div style={{
                width: 36, height: 36, borderRadius: '50%',
                background: 'rgba(255,255,255,0.22)', backdropFilter: 'blur(8px)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Sparkles style={{ width: 18, height: 18 }} />
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: '0.95rem' }}>{t('Cairo Trip Assistant', 'مساعد رحلتك في القاهرة')}</div>
                <div style={{ fontSize: '0.72rem', opacity: 0.85 }}>
                  <span style={{ display: 'inline-block', width: 7, height: 7, background: '#22d765', borderRadius: '50%', marginInlineEnd: 5 }} />
                  {t('Online · Replies instantly', 'متصل · يرد فوراً')}
                </div>
              </div>
            </div>
            <button onClick={() => setOpen(false)} aria-label="Close" style={{
              width: 32, height: 32, borderRadius: '50%',
              background: 'rgba(255,255,255,0.2)', border: 'none', cursor: 'pointer',
              color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <X style={{ width: 16, height: 16 }} />
            </button>
          </div>

          <div ref={scrollRef} style={{
            flex: 1, overflowY: 'auto', padding: '1rem 1rem 0.5rem',
            display: 'flex', flexDirection: 'column', gap: '0.6rem',
            background: 'var(--bg-section)',
          }}>
            {messages.length === 0 && (
              <>
                <div style={{
                  padding: '0.85rem 1rem', borderRadius: '0.85rem',
                  background: 'var(--bg-card)', border: '1px solid var(--border)',
                  fontSize: '0.88rem', lineHeight: 1.5, color: 'var(--text-body)',
                }}>
                  👋 {t(
                    'Hey! Ask me anything about Cairo and Giza - prices, hotels, attractions, what to eat. I use live data from this site.',
                    'أهلاً! اسألني أي حاجة عن القاهرة والجيزة - أسعار، فنادق، معالم، أكل. باستخدم بيانات الموقع المحدثة.'
                  )}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 700, marginTop: '0.4rem' }}>
                  {t('Try asking', 'جرب اسأل')}
                </div>
                {sugList.map((s) => (
                  <button key={s} onClick={() => send(s)}
                    style={{
                      textAlign: 'start', padding: '0.65rem 0.85rem', borderRadius: '0.7rem',
                      background: 'var(--bg-card)', border: '1px dashed var(--primary)',
                      color: 'var(--primary)', fontSize: '0.82rem', fontWeight: 600,
                      cursor: 'pointer', fontFamily: 'inherit',
                    }}>
                    {s}
                  </button>
                ))}
              </>
            )}

            {messages.map((m, i) => (
              <div key={i} style={{
                alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
                maxWidth: '85%',
                padding: '0.7rem 0.95rem', borderRadius: '1rem',
                background: m.role === 'user' ? 'linear-gradient(135deg, var(--primary), var(--accent))' : 'var(--bg-card)',
                color: m.role === 'user' ? '#fff' : 'var(--text-dark)',
                fontSize: '0.88rem', lineHeight: 1.5,
                border: m.role === 'assistant' ? '1px solid var(--border)' : 'none',
                whiteSpace: 'pre-wrap',
                boxShadow: m.role === 'user' ? '0 4px 12px rgba(200,134,10,0.25)' : 'none',
              }}>
                {m.content}
              </div>
            ))}

            {loading && (
              <div style={{
                alignSelf: 'flex-start', padding: '0.6rem 0.95rem', borderRadius: '1rem',
                background: 'var(--bg-card)', border: '1px solid var(--border)',
                display: 'flex', alignItems: 'center', gap: '0.4rem',
                color: 'var(--text-muted)', fontSize: '0.82rem',
              }}>
                <Loader2 className="animate-spin" style={{ width: 14, height: 14 }} />
                {t('Thinking...', 'يفكر...')}
              </div>
            )}
          </div>

          <form onSubmit={(e) => { e.preventDefault(); send(input); }}
            style={{ padding: '0.75rem 0.85rem', borderTop: '1px solid var(--border)', background: 'var(--bg-card)' }}>
            <div style={{ display: 'flex', gap: '0.4rem', marginBottom: '0.5rem' }}>
              <input
                value={input} onChange={e => setInput(e.target.value)}
                placeholder={t('Type your question...', 'اكتب سؤالك...')}
                disabled={loading}
                style={{
                  flex: 1, padding: '0.65rem 0.85rem', borderRadius: '0.75rem',
                  border: '1px solid var(--border)', background: 'var(--bg-section)',
                  fontSize: '0.88rem', color: 'var(--text-dark)', fontFamily: 'inherit',
                  outline: 'none',
                }}
              />
              <button type="submit" disabled={!input.trim() || loading}
                style={{
                  width: 40, height: 40, borderRadius: '0.65rem',
                  background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                  border: 'none', cursor: input.trim() && !loading ? 'pointer' : 'not-allowed',
                  color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  opacity: input.trim() && !loading ? 1 : 0.5,
                }}>
                <Send style={{ width: 16, height: 16 }} />
              </button>
            </div>
            <a href="mailto:hello@cairotrip.com" style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.35rem',
              fontSize: '0.72rem', color: 'var(--text-muted)', textDecoration: 'none',
            }}>
              <Mail style={{ width: 11, height: 11 }} />
              {t('Need a human? Email hello@cairotrip.com', 'عايز شخص حقيقي؟ راسل hello@cairotrip.com')}
            </a>
          </form>
        </div>
      )}
    </>
  );
}
