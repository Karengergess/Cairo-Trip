'use client';

import { useState, useEffect, useRef } from 'react';
import { ChevronDown, Search } from 'lucide-react';

// Common visitor countries to Egypt + key Arab markets
const COUNTRIES = [
  { code: 'EG', dial: '+20',  name: 'Egypt',          flag: '🇪🇬' },
  { code: 'SA', dial: '+966', name: 'Saudi Arabia',   flag: '🇸🇦' },
  { code: 'AE', dial: '+971', name: 'UAE',            flag: '🇦🇪' },
  { code: 'KW', dial: '+965', name: 'Kuwait',         flag: '🇰🇼' },
  { code: 'QA', dial: '+974', name: 'Qatar',          flag: '🇶🇦' },
  { code: 'BH', dial: '+973', name: 'Bahrain',        flag: '🇧🇭' },
  { code: 'OM', dial: '+968', name: 'Oman',           flag: '🇴🇲' },
  { code: 'JO', dial: '+962', name: 'Jordan',         flag: '🇯🇴' },
  { code: 'LB', dial: '+961', name: 'Lebanon',        flag: '🇱🇧' },
  { code: 'MA', dial: '+212', name: 'Morocco',        flag: '🇲🇦' },
  { code: 'TN', dial: '+216', name: 'Tunisia',        flag: '🇹🇳' },
  { code: 'DZ', dial: '+213', name: 'Algeria',        flag: '🇩🇿' },
  { code: 'IQ', dial: '+964', name: 'Iraq',           flag: '🇮🇶' },
  { code: 'SD', dial: '+249', name: 'Sudan',          flag: '🇸🇩' },
  { code: 'LY', dial: '+218', name: 'Libya',          flag: '🇱🇾' },
  { code: 'PS', dial: '+970', name: 'Palestine',      flag: '🇵🇸' },
  { code: 'SY', dial: '+963', name: 'Syria',          flag: '🇸🇾' },
  { code: 'YE', dial: '+967', name: 'Yemen',          flag: '🇾🇪' },
  { code: 'TR', dial: '+90',  name: 'Turkey',         flag: '🇹🇷' },
  // Europe
  { code: 'GB', dial: '+44',  name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'DE', dial: '+49',  name: 'Germany',        flag: '🇩🇪' },
  { code: 'FR', dial: '+33',  name: 'France',         flag: '🇫🇷' },
  { code: 'IT', dial: '+39',  name: 'Italy',          flag: '🇮🇹' },
  { code: 'ES', dial: '+34',  name: 'Spain',          flag: '🇪🇸' },
  { code: 'NL', dial: '+31',  name: 'Netherlands',    flag: '🇳🇱' },
  { code: 'BE', dial: '+32',  name: 'Belgium',        flag: '🇧🇪' },
  { code: 'CH', dial: '+41',  name: 'Switzerland',    flag: '🇨🇭' },
  { code: 'AT', dial: '+43',  name: 'Austria',        flag: '🇦🇹' },
  { code: 'SE', dial: '+46',  name: 'Sweden',         flag: '🇸🇪' },
  { code: 'NO', dial: '+47',  name: 'Norway',         flag: '🇳🇴' },
  { code: 'DK', dial: '+45',  name: 'Denmark',        flag: '🇩🇰' },
  { code: 'FI', dial: '+358', name: 'Finland',        flag: '🇫🇮' },
  { code: 'IE', dial: '+353', name: 'Ireland',        flag: '🇮🇪' },
  { code: 'PT', dial: '+351', name: 'Portugal',       flag: '🇵🇹' },
  { code: 'GR', dial: '+30',  name: 'Greece',         flag: '🇬🇷' },
  { code: 'PL', dial: '+48',  name: 'Poland',         flag: '🇵🇱' },
  { code: 'CZ', dial: '+420', name: 'Czechia',        flag: '🇨🇿' },
  { code: 'HU', dial: '+36',  name: 'Hungary',        flag: '🇭🇺' },
  { code: 'RO', dial: '+40',  name: 'Romania',        flag: '🇷🇴' },
  { code: 'RU', dial: '+7',   name: 'Russia',         flag: '🇷🇺' },
  // Americas
  { code: 'US', dial: '+1',   name: 'United States',  flag: '🇺🇸' },
  { code: 'CA', dial: '+1',   name: 'Canada',         flag: '🇨🇦' },
  { code: 'MX', dial: '+52',  name: 'Mexico',         flag: '🇲🇽' },
  { code: 'BR', dial: '+55',  name: 'Brazil',         flag: '🇧🇷' },
  { code: 'AR', dial: '+54',  name: 'Argentina',      flag: '🇦🇷' },
  // Asia
  { code: 'CN', dial: '+86',  name: 'China',          flag: '🇨🇳' },
  { code: 'JP', dial: '+81',  name: 'Japan',          flag: '🇯🇵' },
  { code: 'KR', dial: '+82',  name: 'South Korea',    flag: '🇰🇷' },
  { code: 'IN', dial: '+91',  name: 'India',          flag: '🇮🇳' },
  { code: 'PK', dial: '+92',  name: 'Pakistan',       flag: '🇵🇰' },
  { code: 'BD', dial: '+880', name: 'Bangladesh',     flag: '🇧🇩' },
  { code: 'ID', dial: '+62',  name: 'Indonesia',      flag: '🇮🇩' },
  { code: 'MY', dial: '+60',  name: 'Malaysia',       flag: '🇲🇾' },
  { code: 'SG', dial: '+65',  name: 'Singapore',      flag: '🇸🇬' },
  { code: 'TH', dial: '+66',  name: 'Thailand',       flag: '🇹🇭' },
  { code: 'VN', dial: '+84',  name: 'Vietnam',        flag: '🇻🇳' },
  { code: 'PH', dial: '+63',  name: 'Philippines',    flag: '🇵🇭' },
  // Oceania + Africa
  { code: 'AU', dial: '+61',  name: 'Australia',      flag: '🇦🇺' },
  { code: 'NZ', dial: '+64',  name: 'New Zealand',    flag: '🇳🇿' },
  { code: 'ZA', dial: '+27',  name: 'South Africa',   flag: '🇿🇦' },
  { code: 'NG', dial: '+234', name: 'Nigeria',        flag: '🇳🇬' },
  { code: 'KE', dial: '+254', name: 'Kenya',          flag: '🇰🇪' },
];

interface Props {
  value: string;
  onChange: (val: string) => void;
  required?: boolean;
}

export default function PhoneInput({ value, onChange, required }: Props) {
  // Parse incoming "+20 1234567890" into country + number
  const parseDial = (v: string) => {
    const match = COUNTRIES.find(c => v.startsWith(c.dial));
    if (match) return { country: match, rest: v.slice(match.dial.length).trim() };
    return { country: COUNTRIES[0], rest: v.replace(/^\+/, '') };
  };

  const initial = parseDial(value || '');
  const [country, setCountry] = useState(initial.country);
  const [number, setNumber] = useState(initial.rest);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    onChange(number ? `${country.dial} ${number.replace(/\D/g, '')}` : '');
  }, [country, number, onChange]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const filtered = search
    ? COUNTRIES.filter(c => c.name.toLowerCase().includes(search.toLowerCase()) || c.dial.includes(search))
    : COUNTRIES;

  return (
    <div ref={dropdownRef} style={{ position: 'relative' }}>
      <div style={{
        display: 'flex', gap: '0.4rem',
      }}>
        <button
          type="button"
          onClick={() => setOpen(o => !o)}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.35rem',
            padding: '0 0.75rem', borderRadius: '0.6rem',
            background: 'var(--bg-section)', border: '1px solid var(--border)',
            cursor: 'pointer', fontFamily: 'inherit',
            minHeight: 44, color: 'var(--text-dark)',
            whiteSpace: 'nowrap', fontSize: '0.92rem',
          }}>
          <span style={{ fontSize: '1.1rem' }}>{country.flag}</span>
          <span style={{ fontWeight: 700 }}>{country.dial}</span>
          <ChevronDown style={{ width: 14, height: 14, opacity: 0.6 }} />
        </button>
        <input
          type="tel"
          inputMode="tel"
          value={number}
          onChange={e => setNumber(e.target.value.replace(/[^\d\s]/g, ''))}
          placeholder="123 456 7890"
          required={required}
          className="input"
          style={{ flex: 1 }}
        />
      </div>

      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 4px)', insetInlineStart: 0,
          zIndex: 50, width: 'min(320px, 95vw)',
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          borderRadius: '0.75rem', overflow: 'hidden',
          boxShadow: '0 16px 40px rgba(0,0,0,0.18)',
          maxHeight: 320, display: 'flex', flexDirection: 'column',
        }}>
          <div style={{ padding: '0.5rem', borderBottom: '1px solid var(--border)', position: 'relative' }}>
            <Search style={{
              position: 'absolute', insetInlineStart: '0.95rem', top: '50%',
              transform: 'translateY(-50%)',
              width: 14, height: 14, color: 'var(--text-muted)', pointerEvents: 'none',
            }} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search country..."
              autoFocus
              style={{
                width: '100%', padding: '0.5rem 0.85rem 0.5rem 2.2rem',
                borderRadius: '0.5rem', border: '1px solid var(--border)',
                background: 'var(--bg-section)', fontFamily: 'inherit',
                fontSize: '0.9rem', color: 'var(--text-dark)',
              }}
            />
          </div>
          <div style={{ overflowY: 'auto', flex: 1 }}>
            {filtered.length === 0 ? (
              <div style={{ padding: '1rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                No match
              </div>
            ) : (
              filtered.map(c => (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => { setCountry(c); setOpen(false); setSearch(''); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '0.5rem', width: '100%',
                    padding: '0.6rem 0.85rem', background: c.code === country.code ? 'var(--bg-section)' : 'transparent',
                    border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                    textAlign: 'start', fontSize: '0.88rem', color: 'var(--text-dark)',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'var(--bg-section)'; }}
                  onMouseLeave={e => { if (c.code !== country.code) e.currentTarget.style.background = 'transparent'; }}>
                  <span style={{ fontSize: '1.1rem' }}>{c.flag}</span>
                  <span style={{ flex: 1, fontWeight: 600 }}>{c.name}</span>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.82rem', fontWeight: 700 }}>{c.dial}</span>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
