'use client';

import { useEffect, useState, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

interface POI { lat: number; lon: number; name: string; type: string; }

interface MapViewProps {
  pois: POI[];
  center?: [number, number];
  zoom?: number;
}

export default function MapView({ pois, center = [26.8, 30.8], zoom = 6 }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    mapInstance.current = L.map(mapRef.current).setView(center, zoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(mapInstance.current);

    return () => {
      mapInstance.current?.remove();
      mapInstance.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapInstance.current) return;

    mapInstance.current.eachLayer(layer => {
      if (layer instanceof L.Marker) mapInstance.current?.removeLayer(layer);
    });

    pois.forEach(poi => {
      if (poi.lat && poi.lon) {
        const marker = L.marker([poi.lat, poi.lon], {
          icon: L.divIcon({
            className: 'custom-marker',
            html: `<div style="background:var(--primary);color:#fff;padding:4px 8px;border-radius:8px;font-size:11px;font-weight:700;white-space:nowrap;box-shadow:0 2px 8px rgba(0,0,0,0.2)">${poi.name || poi.type}</div>`,
            iconSize: [0, 0],
            iconAnchor: [0, 0],
          }),
        });
        const gmapsUrl = `https://www.google.com/maps/search/?api=1&query=${poi.lat},${poi.lon}`;
        const dirUrl = `https://www.google.com/maps/dir/?api=1&destination=${poi.lat},${poi.lon}`;
        marker.bindPopup(`
          <div style="min-width:180px;font-family:inherit">
            <b style="font-size:14px">${poi.name || 'Unknown'}</b>
            <div style="color:#666;font-size:12px;margin:4px 0 8px;text-transform:capitalize">${poi.type}</div>
            <div style="display:flex;gap:6px;flex-direction:column">
              <a href="${gmapsUrl}" target="_blank" rel="noopener" style="display:block;padding:6px 10px;background:#c8860a;color:#fff;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none;text-align:center">Open in Google Maps</a>
              <a href="${dirUrl}" target="_blank" rel="noopener" style="display:block;padding:6px 10px;background:#fff;color:#c8860a;border:1px solid #c8860a;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none;text-align:center">Get Directions</a>
            </div>
          </div>
        `);
        marker.addTo(mapInstance.current!);
      }
    });
  }, [pois]);

  return <div ref={mapRef} style={{ width: '100%', height: '100%', minHeight: 400 }} />;
}
