'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LanguageContext';
import {
  Home, Map, Hotel, Compass, CalendarDays, Wallet, UtensilsCrossed,
  AlertTriangle, Menu, X, Globe, LogIn, LogOut, Heart,
  LayoutDashboard, Shield, Search
} from 'lucide-react';

export default function Navbar() {
  const { user, isAdmin, signOut } = useAuth();
  const { lang, t, toggleLang } = useLang();
  const router = useRouter();
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [visible, setVisible] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const lastScrollY = useRef(0);
  const ticking = useRef(false);
  const mountedAt = useRef(0);

  // Re-show the navbar on every page navigation and restart the grace period
  // so it never inherits a "hidden" state from the previous page.
  useEffect(() => {
    setVisible(true);
    setMobileOpen(false);
    lastScrollY.current = typeof window !== 'undefined' ? window.scrollY : 0;
    mountedAt.current = Date.now();
  }, [pathname]);

  const handleSignOut = async () => {
    setMobileOpen(false);
    await signOut();
    router.push('/');
  };

  useEffect(() => {
    // Sync to actual scroll position on mount so we don't false-trigger a hide.
    lastScrollY.current = window.scrollY;
    mountedAt.current = Date.now();

    const update = () => {
      const y = window.scrollY;
      setScrolled(y > 50);
      // Grace period: keep navbar visible for the first 400ms after mount
      if (Date.now() - mountedAt.current < 400) {
        setVisible(true);
        lastScrollY.current = y;
        ticking.current = false;
        return;
      }
      // Hide when scrolling down past 100px, show when scrolling up or near top
      if (y < 100 || y < lastScrollY.current - 8) {
        setVisible(true);
      } else if (y > lastScrollY.current + 8) {
        setVisible(false);
        setMobileOpen(false);
      }
      lastScrollY.current = y;
      ticking.current = false;
    };

    const onScroll = () => {
      if (!ticking.current) {
        ticking.current = true;
        window.requestAnimationFrame(update);
      }
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`} style={{
      transform: visible ? 'translateY(0)' : 'translateY(-110%)',
      transition: 'transform 0.25s ease',
      willChange: 'transform',
    }}>
      <Link href="/" className="navbar-brand">
        <img src="/logo.svg" alt="" className="w-8 h-8 animate-float" />
        {t('Cairo Trip', 'رحلتك في القاهرة')}
      </Link>

      <div className="navbar-links hidden md:flex">
        <Link href="/"><Home className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Home', 'الرئيسية')}</Link>
        <Link href="/hotels"><Hotel className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Hotels', 'فنادق')}</Link>
        <Link href="/attractions"><Compass className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Attractions', 'معالم')}</Link>
        <Link href="/restaurants"><UtensilsCrossed className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Food', 'مطاعم')}</Link>
        <Link href="/discover"><Map className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Discover', 'اكتشف')}</Link>
        <Link href="/planner"><CalendarDays className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Planner', 'خطط')}</Link>
        <Link href="/favorites"><Heart className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Saved', 'المفضلة')}</Link>

        <button
          onClick={toggleLang}
          className="flex items-center gap-1"
          style={{ fontSize: '0.85rem' }}
        >
          <Globe className="w-4 h-4" />
          {lang === 'en' ? 'عربي' : 'EN'}
        </button>

        {user ? (
          <>
            {isAdmin && (
              <Link href="/admin" className="btn-admin-link">
                <Shield className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Admin', 'لوحة التحكم')}
              </Link>
            )}
            <Link href="/dashboard"><LayoutDashboard className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Dashboard', 'لوحتي')}</Link>
            <button onClick={handleSignOut}>
              <LogOut className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Logout', 'خروج')}
            </button>
          </>
        ) : (
          <Link href="/auth/login">
            <LogIn className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />{t('Login', 'دخول')}
          </Link>
        )}
      </div>

      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="md:hidden"
        style={{ background: 'none', border: 'none', color: 'var(--text-body)', cursor: 'pointer', padding: '0.5rem' }}
      >
        {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {mobileOpen && (
        <div
          style={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            background: '#fff',
            borderBottom: '1px solid var(--border)',
            boxShadow: 'var(--shadow-md)',
            padding: '1rem',
            animation: 'slideDown 0.3s ease',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.25rem',
          }}
        >
          {[
            { href: '/', label: t('Home', 'الرئيسية'), icon: Home },
            { href: '/hotels', label: t('Hotels', 'فنادق'), icon: Hotel },
            { href: '/attractions', label: t('Attractions', 'معالم'), icon: Compass },
            { href: '/restaurants', label: t('Restaurants', 'مطاعم'), icon: UtensilsCrossed },
            { href: '/discover', label: t('Discover', 'اكتشف'), icon: Map },
            { href: '/planner', label: t('Planner', 'خطط'), icon: CalendarDays },
            { href: '/budget', label: t('Budget', 'ميزانية'), icon: Wallet },
            { href: '/favorites', label: t('Saved', 'المفضلة'), icon: Heart },
            { href: '/emergency', label: t('Emergency', 'طوارئ'), icon: AlertTriangle },
            { href: '/search', label: t('Search', 'بحث'), icon: Search },
          ].map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                padding: '0.75rem 1rem',
                borderRadius: '12px',
                color: 'var(--text-body)',
                textDecoration: 'none',
                fontWeight: 600,
                fontSize: '0.95rem',
                transition: 'all 0.2s',
              }}
            >
              <link.icon className="w-5 h-5" style={{ color: 'var(--primary)' }} />
              {link.label}
            </Link>
          ))}

          {user ? (
            <>
              <Link href="/dashboard" onClick={() => setMobileOpen(false)} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem 1rem', borderRadius: '12px', color: 'var(--text-body)', textDecoration: 'none', fontWeight: 600 }}>
                <LayoutDashboard className="w-5 h-5" style={{ color: 'var(--primary)' }} /> {t('Dashboard', 'لوحتي')}
              </Link>
              <button onClick={handleSignOut} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem 1rem', borderRadius: '12px', color: 'var(--danger)', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Cairo', fontSize: '0.95rem', width: '100%' }}>
                <LogOut className="w-5 h-5" /> {t('Logout', 'خروج')}
              </button>
            </>
          ) : (
            <Link href="/auth/login" onClick={() => setMobileOpen(false)} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem 1rem', borderRadius: '12px', color: 'var(--primary)', textDecoration: 'none', fontWeight: 700 }}>
              <LogIn className="w-5 h-5" /> {t('Login', 'دخول')}
            </Link>
          )}
        </div>
      )}
    </nav>
  );
}
