'use client';

import { useState, useRef } from 'react';
import { Upload, Loader2, X, Image as ImageIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Props {
  value?: string;
  onChange: (url: string) => void;
  folder?: string;
}

export default function ImageUploader({ value, onChange, folder = 'misc' }: Props) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please pick an image file');
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setError('Image must be under 8MB');
      return;
    }
    setError('');
    setUploading(true);

    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
    const filename = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

    const { error: upErr } = await supabase.storage
      .from('place-images')
      .upload(filename, file, { cacheControl: '3600', upsert: false });

    if (upErr) {
      setError(upErr.message);
      setUploading(false);
      return;
    }

    const { data: { publicUrl } } = supabase.storage.from('place-images').getPublicUrl(filename);
    onChange(publicUrl);
    setUploading(false);
  };

  const pick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) handleFile(f);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
      {value && (
        <div style={{
          position: 'relative', width: '100%', height: 120,
          borderRadius: '0.5rem', overflow: 'hidden',
          border: '1px solid var(--border)', background: 'var(--bg-section)',
        }}>
          <img src={value} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <button type="button" onClick={() => onChange('')} style={{
            position: 'absolute', top: 6, insetInlineEnd: 6,
            width: 28, height: 28, borderRadius: '50%',
            background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(6px)',
            border: 'none', cursor: 'pointer', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <X style={{ width: 14, height: 14 }} />
          </button>
        </div>
      )}

      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          const f = e.dataTransfer.files?.[0];
          if (f) handleFile(f);
        }}
        onClick={() => !uploading && inputRef.current?.click()}
        style={{
          padding: dragOver ? '1.25rem 0.85rem' : '0.55rem 0.85rem',
          borderRadius: '0.55rem',
          background: dragOver ? 'rgba(200,134,10,0.08)' : 'var(--bg-section)',
          border: `1px dashed ${dragOver ? 'var(--primary)' : 'var(--primary)'}`,
          color: 'var(--primary)', fontSize: '0.82rem', fontWeight: 700,
          cursor: uploading ? 'not-allowed' : 'pointer', fontFamily: 'inherit',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
          opacity: uploading ? 0.7 : 1, transition: 'all 0.15s', textAlign: 'center',
        }}>
        {uploading
          ? <><Loader2 className="animate-spin" style={{ width: 14, height: 14 }} /> Uploading...</>
          : <><Upload style={{ width: 14, height: 14 }} /> {dragOver ? 'Drop to upload' : (value ? 'Replace image (drag or click)' : 'Drag image here, or click to choose')}</>}
        <input ref={inputRef} type="file" accept="image/*" onChange={pick} style={{ display: 'none' }} />
      </div>

      <input
        type="url" value={value || ''} onChange={e => onChange(e.target.value)}
        placeholder="or paste image URL"
        style={{
          padding: '0.55rem 0.85rem', borderRadius: '0.5rem',
          border: '1px solid var(--border)', background: 'var(--bg-section)',
          fontSize: '0.82rem', color: 'var(--text-body)', fontFamily: 'inherit',
        }}
      />

      {error && (
        <div style={{ fontSize: '0.78rem', color: 'var(--danger)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
          <ImageIcon style={{ width: 12, height: 12 }} /> {error}
        </div>
      )}
    </div>
  );
}
