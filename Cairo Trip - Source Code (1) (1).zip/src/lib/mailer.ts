import nodemailer from 'nodemailer';

const GMAIL_USER = process.env.GMAIL_USER;
const GMAIL_APP_PASSWORD = process.env.GMAIL_APP_PASSWORD;
const FROM_NAME = process.env.MAIL_FROM_NAME || 'Cairo Trip Concierge';

let transporter: nodemailer.Transporter | null = null;

function getTransporter() {
  if (!GMAIL_USER || !GMAIL_APP_PASSWORD) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD },
    });
  }
  return transporter;
}

export async function sendMail(opts: { to: string; subject: string; html: string }) {
  const t = getTransporter();
  if (!t) throw new Error('Mailer not configured. Set GMAIL_USER and GMAIL_APP_PASSWORD.');
  await t.sendMail({
    from: `${FROM_NAME} <${GMAIL_USER}>`,
    to: opts.to,
    subject: opts.subject,
    html: opts.html,
  });
}

export function mailerConfigured() {
  return Boolean(GMAIL_USER && GMAIL_APP_PASSWORD);
}
