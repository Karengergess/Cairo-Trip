// Short, easy-to-read reference code generated from a UUID.
// Format: CT-XXXXXX (8 chars). Deterministic so the same booking
// always shows the same code.
export function refCode(prefix: 'TKT' | 'HTL', uuid: string): string {
  // Take first 8 hex chars of the UUID, uppercase, drop ambiguous chars (0/O/1/I)
  const clean = uuid.replace(/-/g, '').toUpperCase()
    .replace(/[01OI]/g, c => ({ '0': 'X', '1': 'Y', 'O': 'Z', 'I': 'W' }[c] || c));
  return `${prefix}-${clean.slice(0, 6)}`;
}
