
function buildQuery(name: string, cityName?: string | null): string {
  const parts = [name, cityName, 'Egypt'].filter(Boolean) as string[];
  return parts.join(', ');
}

export function mapsSearchUrl(name: string, cityName?: string | null): string {
  const q = encodeURIComponent(buildQuery(name, cityName));
  return `https://www.google.com/maps/search/?api=1&query=${q}`;
}

export function mapsDirectionsUrl(name: string, cityName?: string | null): string {
  const q = encodeURIComponent(buildQuery(name, cityName));
  return `https://www.google.com/maps/dir/?api=1&destination=${q}`;
}
