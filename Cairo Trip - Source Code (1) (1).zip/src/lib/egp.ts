export const EGP_RATE = 50;
export const toEGP = (usd: number) => Math.round(usd * EGP_RATE).toLocaleString();
