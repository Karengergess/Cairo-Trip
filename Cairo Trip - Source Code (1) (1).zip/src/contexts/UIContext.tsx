'use client';

import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, Info, XCircle } from 'lucide-react';

interface ConfirmOptions {
  title: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  danger?: boolean;
}

interface ToastOptions {
  message: string;
  type?: 'success' | 'error' | 'info';
  duration?: number;
}

interface UIContextType {
  confirm: (opts: ConfirmOptions) => Promise<boolean>;
  toast: (opts: ToastOptions) => void;
}

const UIContext = createContext<UIContextType | null>(null);

export function UIProvider({ children }: { children: ReactNode }) {
  const [confirmState, setConfirmState] = useState<(ConfirmOptions & { resolve: (v: boolean) => void }) | null>(null);
  const [toasts, setToasts] = useState<{ id: number; message: string; type: 'success' | 'error' | 'info' }[]>([]);

  const confirm = useCallback((opts: ConfirmOptions) => {
    return new Promise<boolean>((resolve) => {
      setConfirmState({ ...opts, resolve });
    });
  }, []);

  const toast = useCallback((opts: ToastOptions) => {
    const id = Date.now() + Math.random();
    const t = { id, message: opts.message, type: opts.type || 'info' };
    setToasts(prev => [...prev, t]);
    setTimeout(() => setToasts(prev => prev.filter(x => x.id !== id)), opts.duration || 3000);
  }, []);

  const closeConfirm = (result: boolean) => {
    confirmState?.resolve(result);
    setConfirmState(null);
  };

  return (
    <UIContext.Provider value={{ confirm, toast }}>
      {children}

      {confirmState && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 200,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '1rem', animation: 'fadeIn 0.15s ease',
        }}>
          <div onClick={() => closeConfirm(false)}
            style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }} />
          <div style={{
            position: 'relative', background: 'var(--bg-card)',
            border: '1px solid var(--border)', borderRadius: '1.25rem',
            padding: '1.75rem', maxWidth: 420, width: '100%',
            boxShadow: '0 20px 60px rgba(0,0,0,0.25)',
            animation: 'scaleIn 0.18s ease',
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: '50%',
              background: confirmState.danger ? 'rgba(231,76,60,0.12)' : 'rgba(200,134,10,0.12)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 1rem',
            }}>
              <AlertTriangle style={{
                width: 28, height: 28,
                color: confirmState.danger ? '#e74c3c' : 'var(--primary)',
              }} />
            </div>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-dark)', textAlign: 'center', marginBottom: '0.5rem' }}>
              {confirmState.title}
            </h3>
            {confirmState.message && (
              <p style={{ color: 'var(--text-muted)', textAlign: 'center', fontSize: '0.92rem', marginBottom: '1.5rem', lineHeight: 1.5 }}>
                {confirmState.message}
              </p>
            )}
            <div style={{ display: 'flex', gap: '0.6rem' }}>
              <button onClick={() => closeConfirm(false)} style={{
                flex: 1, padding: '0.75rem', borderRadius: '0.75rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                color: 'var(--text-body)', fontWeight: 700, fontSize: '0.92rem',
                cursor: 'pointer', fontFamily: 'inherit',
              }}>
                {confirmState.cancelText || 'Cancel'}
              </button>
              <button onClick={() => closeConfirm(true)} style={{
                flex: 1, padding: '0.75rem', borderRadius: '0.75rem',
                background: confirmState.danger
                  ? 'linear-gradient(135deg, #e74c3c, #c0392b)'
                  : 'linear-gradient(135deg, var(--primary), var(--accent))',
                border: 'none', color: '#fff', fontWeight: 700, fontSize: '0.92rem',
                cursor: 'pointer', fontFamily: 'inherit',
              }}>
                {confirmState.confirmText || 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div style={{
        position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
        zIndex: 250, display: 'flex', flexDirection: 'column', gap: '0.5rem',
        pointerEvents: 'none',
      }}>
        {toasts.map(tst => {
          const Icon = tst.type === 'success' ? CheckCircle2 : tst.type === 'error' ? XCircle : Info;
          const color = tst.type === 'success' ? '#27ae60' : tst.type === 'error' ? '#e74c3c' : '#3498db';
          return (
            <div key={tst.id} style={{
              display: 'flex', alignItems: 'center', gap: '0.6rem',
              padding: '0.75rem 1.25rem', borderRadius: '0.75rem',
              background: 'var(--bg-card)', border: `1px solid ${color}40`,
              boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
              fontWeight: 600, fontSize: '0.9rem', color: 'var(--text-dark)',
              pointerEvents: 'auto', minWidth: 240,
              animation: 'slideUp 0.25s ease',
            }}>
              <Icon style={{ width: 18, height: 18, color, flexShrink: 0 }} />
              {tst.message}
            </div>
          );
        })}
      </div>

      <style jsx global>{`
        @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes scaleIn { from { opacity: 0; transform: scale(0.92) } to { opacity: 1; transform: scale(1) } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(12px) } to { opacity: 1; transform: translateY(0) } }
      `}</style>
    </UIContext.Provider>
  );
}

export function useUI() {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error('useUI must be used within UIProvider');
  return ctx;
}
