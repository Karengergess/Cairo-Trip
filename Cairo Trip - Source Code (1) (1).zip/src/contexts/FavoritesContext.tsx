'use client';

import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

type PlaceType = 'hotel' | 'attraction' | 'restaurant';

interface FavoritesContextType {
  isFavorite: (type: PlaceType, id: string) => boolean;
  toggle: (type: PlaceType, id: string) => Promise<void>;
  favorites: { type: PlaceType; id: string }[];
  refresh: () => Promise<void>;
}

const FavoritesContext = createContext<FavoritesContextType | null>(null);
const LS_KEY = 'etp_favorites_v1';

function loadLocal(): { type: PlaceType; id: string }[] {
  if (typeof window === 'undefined') return [];
  try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); } catch { return []; }
}
function saveLocal(items: { type: PlaceType; id: string }[]) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(LS_KEY, JSON.stringify(items));
}

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<{ type: PlaceType; id: string }[]>([]);

  const refresh = useCallback(async () => {
    if (!user) {
      setFavorites(loadLocal());
      return;
    }
    const { data } = await supabase.from('saved_places').select('place_type, place_id').eq('user_id', user.id);
    if (data) {
      setFavorites(data.map((d: { place_type: PlaceType; place_id: string }) => ({ type: d.place_type, id: d.place_id })));
    }
  }, [user]);

  useEffect(() => {
    async function syncOnLogin() {
      if (!user) {
        setFavorites(loadLocal());
        return;
      }
      const localItems = loadLocal();
      if (localItems.length > 0) {
        await (supabase.from('saved_places') as any).upsert(
          localItems.map(it => ({ user_id: user.id, place_type: it.type, place_id: it.id })),
          { onConflict: 'user_id,place_type,place_id', ignoreDuplicates: true }
        );
        localStorage.removeItem(LS_KEY);
      }
      await refresh();
    }
    syncOnLogin();
  }, [user, refresh]);

  const isFavorite = (type: PlaceType, id: string) =>
    favorites.some(f => f.type === type && f.id === id);

  const toggle = async (type: PlaceType, id: string) => {
    const exists = isFavorite(type, id);
    if (!user) {
      const next = exists
        ? favorites.filter(f => !(f.type === type && f.id === id))
        : [...favorites, { type, id }];
      setFavorites(next);
      saveLocal(next);
      return;
    }
    if (exists) {
      await supabase.from('saved_places').delete()
        .eq('user_id', user.id).eq('place_type', type).eq('place_id', id);
      setFavorites(prev => prev.filter(f => !(f.type === type && f.id === id)));
    } else {
      await (supabase.from('saved_places') as any).insert({ user_id: user.id, place_type: type, place_id: id });
      setFavorites(prev => [...prev, { type, id }]);
    }
  };

  return (
    <FavoritesContext.Provider value={{ favorites, isFavorite, toggle, refresh }}>
      {children}
    </FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const ctx = useContext(FavoritesContext);
  if (!ctx) throw new Error('useFavorites must be used within FavoritesProvider');
  return ctx;
}
