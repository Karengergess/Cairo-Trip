export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: Omit<Profile, 'created_at'>;
        Update: Partial<Profile>;
      };
      cities: {
        Row: City;
        Insert: Omit<City, 'id' | 'created_at'>;
        Update: Partial<City>;
      };
      hotels: {
        Row: Hotel;
        Insert: Omit<Hotel, 'id' | 'created_at'>;
        Update: Partial<Hotel>;
      };
      attractions: {
        Row: Attraction;
        Insert: Omit<Attraction, 'id' | 'created_at'>;
        Update: Partial<Attraction>;
      };
      emergency_facilities: {
        Row: EmergencyFacility;
        Insert: Omit<EmergencyFacility, 'id'>;
        Update: Partial<EmergencyFacility>;
      };
      bookings: {
        Row: Booking;
        Insert: Omit<Booking, 'id' | 'created_at'>;
        Update: Partial<Booking>;
      };
      saved_places: {
        Row: SavedPlace;
        Insert: Omit<SavedPlace, 'id' | 'created_at'>;
        Update: Partial<SavedPlace>;
      };
      restaurants: {
        Row: Restaurant;
        Insert: Omit<Restaurant, 'id' | 'created_at'>;
        Update: Partial<Restaurant>;
      };
      reviews: {
        Row: Review;
        Insert: Omit<Review, 'id' | 'created_at'>;
        Update: Partial<Review>;
      };
      complaints: {
        Row: Complaint;
        Insert: Omit<Complaint, 'id' | 'created_at'>;
        Update: Partial<Complaint>;
      };
    };
  };
}

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  role: 'user' | 'admin';
  is_banned: boolean;
  preferred_language: string;
  preferred_currency: string;
  created_at: string;
}

export interface City {
  id: string;
  slug: string;
  name: string;
  name_ar: string;
  description: string | null;
  description_ar: string | null;
  image_url: string | null;
  latitude: number;
  longitude: number;
  created_at: string;
}

export interface Hotel {
  id: string;
  city_id: string;
  name: string;
  name_ar: string;
  description: string | null;
  description_ar: string | null;
  star_rating: number;
  price_per_night_usd: number;
  amenities: string[];
  image_urls: string[];
  booking_url: string | null;
  rating: number | null;
  latitude: number;
  longitude: number;
  created_at: string;
  city?: City;
}

export interface Attraction {
  id: string;
  city_id: string;
  name: string;
  name_ar: string;
  description: string | null;
  description_ar: string | null;
  category: string;
  entry_fee_usd: number;
  duration_hours: number;
  opening_hours: Record<string, string> | null;
  crowd_data: Record<string, unknown> | null;
  wikipedia_slug: string | null;
  latitude: number;
  longitude: number;
  image_url: string | null;
  created_at: string;
  city?: City;
}

export interface EmergencyFacility {
  id: string;
  city_id: string;
  name: string;
  name_ar: string;
  type: 'hospital' | 'police' | 'pharmacy';
  phone: string | null;
  latitude: number;
  longitude: number;
  is_24h: boolean;
  city?: City;
}

export interface Booking {
  id: string;
  user_id: string;
  hotel_id: string;
  check_in: string;
  check_out: string;
  guests: number;
  total_price_usd: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  created_at: string;
  hotel?: Hotel;
}

export interface SavedPlace {
  id: string;
  user_id: string;
  place_type: 'hotel' | 'attraction' | 'restaurant';
  place_id: string;
  created_at: string;
}

export interface Restaurant {
  id: string;
  city_id: string;
  name: string;
  name_ar: string;
  description: string | null;
  description_ar: string | null;
  cuisine: string;
  cuisine_ar: string | null;
  price_range: 1 | 2 | 3 | 4;
  avg_meal_usd: number;
  rating: number | null;
  popular_dishes: string[];
  opening_hours: Record<string, string> | null;
  image_url: string | null;
  booking_url: string | null;
  phone: string | null;
  latitude: number;
  longitude: number;
  created_at: string;
  city?: City;
}

export interface Review {
  id: string;
  user_id: string;
  place_type: 'hotel' | 'attraction';
  place_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
}

export interface Complaint {
  id: string;
  user_id: string | null;
  user_email: string;
  category: string;
  subject: string;
  description: string;
  status: 'pending' | 'reviewed' | 'forwarded' | 'resolved';
  admin_notes: string | null;
  created_at: string;
}
