'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { Search as SearchIcon, Hotel, Compass, MapPin, Star } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Hotel as HotelType, Attraction, City } from '@/types/database';
import { toEGP } from '@/lib/egp';

function SearchContent() {
  const { t, lang } = useLang();
  const searchParams = useSearchParams();
  const q = searchParams.get('q') || '';
  const [query, setQuery] = useState(q);
  const [hotels, setHotels] = useState<HotelType[]>([]);
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [loading, setLoading] = useState(false);

  const doSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) { setHotels([]); setAttractions([]); return; }
    setLoading(true);
    const pattern = `%${searchQuery}%`;
    const [h, a] = await Promise.all([
      supabase.from('hotels').select('*, city:cities(*)').ilike('name', pattern).limit(10),
      supabase.from('attractions').select('*, city:cities(*)').ilike('name', pattern).limit(10),
    ]);
    if (h.data) setHotels(h.data as unknown as HotelType[]);
    if (a.data) setAttractions(a.data as unknown as Attraction[]);
    setLoading(false);
  };

  useEffect(() => { if (q) doSearch(q); }, [q]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    doSearch(query);
    window.history.replaceState(null, '', `/search?q=${encodeURIComponent(query)}`);
  };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 2rem 4rem' }}>
      <div className="max-w-4xl mx-auto">
        <h1 className="section-title text-center">{t('Search', 'بحث')}</h1>

        <form onSubmit={handleSubmit} className="flex gap-3 mb-10 max-w-xl mx-auto">
          <div className="flex-1 relative">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-text-muted" />
            <input type="text" autoFocus value={query} onChange={e => setQuery(e.target.value)} className="input !pl-11 text-lg" placeholder={t('Search hotels and attractions...', 'ابحث عن فنادق ومعالم...')} />
          </div>
          <button type="submit" className="btn-primary">{t('Search', 'بحث')}</button>
        </form>

        {loading && <p className="text-center text-text-muted">{t('Searching...', 'جاري البحث...')}</p>}

        {!loading && !q && (
          <p className="text-center text-text-muted py-16">{t('Enter a search query to find hotels and attractions.', 'أدخل كلمة للبحث عن فنادق ومعالم.')}</p>
        )}

        {hotels.length > 0 && (
          <div className="mb-10">
            <h2 className="font-bold text-text-dark text-lg mb-4 flex items-center gap-2"><Hotel className="w-5 h-5 text-primary" /> {t('Hotels', 'فنادق')} ({hotels.length})</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {hotels.map(hotel => (
                <Link key={hotel.id} href={`/hotels/${hotel.id}`} className="flex gap-4 p-4 rounded-2xl bg-bg-card border border-border hover:border-primary transition-all no-underline text-inherit">
                  <img src={hotel.image_urls?.[0] || ''} alt="" className="w-20 h-20 rounded-xl object-cover shrink-0" />
                  <div>
                    <div className="flex items-center gap-0.5 mb-1">{Array.from({ length: hotel.star_rating }).map((_, s) => <Star key={s} className="w-3 h-3 text-primary fill-primary" />)}</div>
                    <h3 className="font-bold text-text-dark text-sm">{lang === 'ar' ? (hotel as unknown as {name_ar: string}).name_ar || hotel.name : hotel.name}</h3>
                    <p className="text-xs text-text-muted flex items-center gap-1"><MapPin className="w-3 h-3" />{lang === 'ar' ? (hotel.city as unknown as City)?.name_ar : (hotel.city as unknown as City)?.name}</p>
                    <span className="font-bold text-primary text-sm">${hotel.price_per_night_usd}/night</span>
                    <span className="text-xs text-text-muted ml-1">({toEGP(hotel.price_per_night_usd)} EGP)</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {attractions.length > 0 && (
          <div>
            <h2 className="font-bold text-text-dark text-lg mb-4 flex items-center gap-2"><Compass className="w-5 h-5 text-primary" /> {t('Attractions', 'معالم')} ({attractions.length})</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {attractions.map(attr => (
                <Link key={attr.id} href={`/attractions/${attr.id}`} className="flex gap-4 p-4 rounded-2xl bg-bg-card border border-border hover:border-primary transition-all no-underline text-inherit">
                  <img src={attr.image_url || ''} alt="" className="w-20 h-20 rounded-xl object-cover shrink-0" />
                  <div>
                    <span className="inline-block text-xs font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary mb-1">{attr.category}</span>
                    <h3 className="font-bold text-text-dark text-sm">{lang === 'ar' ? (attr as unknown as {name_ar: string}).name_ar || attr.name : attr.name}</h3>
                    <p className="text-xs text-text-muted flex items-center gap-1"><MapPin className="w-3 h-3" />{lang === 'ar' ? (attr.city as unknown as City)?.name_ar : (attr.city as unknown as City)?.name}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {!loading && q && hotels.length === 0 && attractions.length === 0 && (
          <p className="text-center text-text-muted py-16">{t('No results found.', 'لا توجد نتائج.')}</p>
        )}
      </div>
    </div>
  );
}

export default function SearchPage() {
  return <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-text-muted">Loading...</div>}><SearchContent /></Suspense>;
}
