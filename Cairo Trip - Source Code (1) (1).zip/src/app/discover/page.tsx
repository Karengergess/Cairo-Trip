'use client';

import { useState, useEffect, useCallback } from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { Hotel, Compass, UtensilsCrossed, Pill, Siren, Loader2, MapPin, Star, Clock, ChevronRight, List, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Attraction, Hotel as HotelType, City } from '@/types/database';

const MapView = dynamic(() => import('@/components/MapView'), {
  ssr: false,
  loading: () => (
    <div style={{ width: '100%', height: '100%', background: 'var(--bg-section)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Loader2 className="animate-spin" style={{ width: 32, height: 32, color: 'var(--primary)' }} />
    </div>
  ),
});

interface POI { lat: number; lon: number; name: string; type: string; id?: string; }

const filters = [
  { key: 'our-attractions', label_en: 'Attractions', label_ar: 'معالم', icon: Compass },
  { key: 'our-hotels', label_en: 'Hotels', label_ar: 'فنادق', icon: Hotel },
  { key: 'restaurant', label_en: 'Food', label_ar: 'طعام', icon: UtensilsCrossed, query: '"amenity"="restaurant"' },
  { key: 'pharmacy', label_en: 'Pharmacies', label_ar: 'صيدليات', icon: Pill, query: '"amenity"="pharmacy"' },
  { key: 'hospital', label_en: 'Emergency', label_ar: 'طوارئ', icon: Siren, query: '"amenity"="hospital"' },
];

export default function DiscoverPage() {
  const { t, lang } = useLang();
  const [active, setActive] = useState('our-attractions');
  const [pois, setPois] = useState<POI[]>([]);
  const [loading, setLoading] = useState(false);
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [hotels, setHotels] = useState<HotelType[]>([]);
  const [panelOpen, setPanelOpen] = useState(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const [attrRes, hotelRes] = await Promise.all([
        supabase.from('attractions').select('*, city:cities(*)').order('name'),
        supabase.from('hotels').select('*, city:cities(*)').order('name'),
      ]);
      const attrs = (attrRes.data || []) as unknown as Attraction[];
      const htls = (hotelRes.data || []) as unknown as HotelType[];
      setAttractions(attrs);
      setHotels(htls);
      setPois(attrs.map(a => ({ lat: a.latitude, lon: a.longitude, name: a.name, type: 'attraction', id: a.id })));
      setLoading(false);
    }
    loadData();
  }, []);

  const handleFilter = useCallback(async (filterKey: string) => {
    setActive(filterKey);
    setLoading(true);

    if (filterKey === 'our-attractions') {
      setPois(attractions.map(a => ({ lat: a.latitude, lon: a.longitude, name: a.name, type: 'attraction', id: a.id })));
      setLoading(false);
      return;
    }
    if (filterKey === 'our-hotels') {
      setPois(hotels.map(h => ({ lat: h.latitude, lon: h.longitude, name: h.name, type: 'hotel', id: h.id })));
      setLoading(false);
      return;
    }

    const filter = filters.find(f => f.key === filterKey);
    if (!filter || !('query' in filter)) return;
    try {
      const query = `[out:json];node[${filter.query}](24.0,24.7,31.6,36.9);out body 80;`;
      const res = await fetch('https://overpass-api.de/api/interpreter', {
        method: 'POST',
        body: `data=${encodeURIComponent(query)}`,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      const data = await res.json();
      setPois((data.elements || []).map((el: { lat: number; lon: number; tags?: { name?: string } }) => ({
        lat: el.lat, lon: el.lon, name: el.tags?.name || filterKey, type: filterKey,
      })));
    } catch {
      setPois([]);
    }
    setLoading(false);
  }, [attractions, hotels]);

  const selectedAttractions = active === 'our-attractions' ? attractions : [];
  const selectedHotels = active === 'our-hotels' ? hotels : [];
  const isOwnData = active === 'our-attractions' || active === 'our-hotels';

  return (
    <div className="discover-page" style={{ height: '100vh', display: 'flex', flexDirection: 'column', paddingTop: 70 }}>
      <div style={{
        padding: '0.6rem 1rem',
        background: 'var(--bg-card)',
        borderBottom: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', gap: '0.75rem',
        zIndex: 10, overflow: 'hidden',
      }}>
        <h1 style={{ fontSize: '1.1rem', fontWeight: 900, color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '0.3rem', margin: 0, whiteSpace: 'nowrap', flexShrink: 0 }}>
          <MapPin style={{ width: 18, height: 18, color: 'var(--primary)' }} />
          {t('Discover', 'اكتشف')}
        </h1>
        <div style={{ display: 'flex', gap: '0.35rem', flex: 1, overflowX: 'auto', scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
          {filters.map(f => (
            <button
              key={f.key}
              onClick={() => handleFilter(f.key)}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.3rem',
                padding: '0.4rem 0.85rem', borderRadius: '50px',
                fontSize: '0.78rem', fontWeight: 700, fontFamily: 'Cairo',
                cursor: 'pointer', transition: 'all 0.2s ease', whiteSpace: 'nowrap', flexShrink: 0,
                border: active === f.key ? '2px solid var(--primary)' : '1.5px solid var(--border)',
                background: active === f.key ? 'linear-gradient(135deg, var(--primary), var(--accent))' : 'var(--bg-card)',
                color: active === f.key ? '#fff' : 'var(--text-body)',
              }}
            >
              <f.icon style={{ width: 13, height: 13 }} />
              {t(f.label_en, f.label_ar)}
              {loading && active === f.key && <Loader2 className="animate-spin" style={{ width: 11, height: 11 }} />}
            </button>
          ))}
        </div>
        <button
          onClick={() => setPanelOpen(!panelOpen)}
          style={{
            display: 'flex', alignItems: 'center', gap: '0.25rem',
            padding: '0.4rem 0.65rem', borderRadius: '0.5rem',
            fontSize: '0.75rem', fontWeight: 700, cursor: 'pointer', flexShrink: 0, whiteSpace: 'nowrap',
            border: '1.5px solid var(--border)', background: panelOpen ? 'var(--primary)' : 'var(--bg-section)',
            color: panelOpen ? '#fff' : 'var(--text-body)',
          }}
        >
          {panelOpen ? <X style={{ width: 13, height: 13 }} /> : <List style={{ width: 13, height: 13 }} />}
          {pois.length}
        </button>
      </div>

      <div style={{ flex: 1, display: 'flex', position: 'relative', overflow: 'hidden' }}>
        <div style={{ flex: 1, position: 'relative' }}>
          <MapView pois={pois} />
        </div>

        {panelOpen && isOwnData && (
          <div className="discover-panel" style={{
            width: 340, flexShrink: 0,
            background: 'var(--bg-card)',
            borderInlineStart: '1px solid var(--border)',
            overflowY: 'auto',
            display: 'flex', flexDirection: 'column',
          }}>
            <div style={{ padding: '1rem 1rem 0.5rem', borderBottom: '1px solid var(--border)' }}>
              <h2 style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-dark)', margin: 0 }}>
                {active === 'our-attractions' ? t('All Attractions', 'كل المعالم') : t('All Hotels', 'كل الفنادق')}
              </h2>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: '0.25rem 0 0' }}>
                {t('Click to view details', 'اضغط لعرض التفاصيل')}
              </p>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', padding: '0.5rem' }}>
              {selectedAttractions.map(attr => {
                const city = attr.city as unknown as City;
                return (
                  <Link key={attr.id} href={`/attractions/${attr.id}`} style={{ textDecoration: 'none', color: 'inherit', display: 'block' }}>
                    <div style={{
                      display: 'flex', gap: '0.75rem', padding: '0.65rem',
                      borderRadius: '0.75rem', transition: 'background 0.15s ease', cursor: 'pointer',
                      margin: '0.15rem 0',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-section)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                    >
                      <img
                        src={attr.image_url || '/images/pyramids.jpg'}
                        alt={attr.name}
                        style={{ width: 56, height: 56, borderRadius: '0.6rem', objectFit: 'cover', flexShrink: 0 }}
                        loading="lazy"
                      />
                      <div style={{ minWidth: 0, flex: 1 }}>
                        <h3 style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-dark)', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {lang === 'ar' ? (attr as unknown as { name_ar: string }).name_ar || attr.name : attr.name}
                        </h3>
                        <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.2rem', margin: '0.15rem 0' }}>
                          <MapPin style={{ width: 10, height: 10 }} /> {lang === 'ar' ? city?.name_ar : city?.name}
                        </p>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.72rem' }}>
                          {attr.entry_fee_usd === 0 ? (
                            <span style={{ color: 'var(--success)', fontWeight: 700 }}>{t('Free', 'مجاني')}</span>
                          ) : (
                            <span style={{ color: 'var(--primary)', fontWeight: 700 }}>${attr.entry_fee_usd}</span>
                          )}
                          <span style={{ color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.15rem' }}>
                            <Clock style={{ width: 10, height: 10 }} /> {attr.duration_hours}h
                          </span>
                          <ChevronRight style={{ width: 12, height: 12, color: 'var(--text-muted)', marginInlineStart: 'auto' }} />
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}

              {selectedHotels.map(hotel => {
                const city = hotel.city as unknown as City;
                return (
                  <Link key={hotel.id} href={`/hotels/${hotel.id}`} style={{ textDecoration: 'none', color: 'inherit', display: 'block' }}>
                    <div style={{
                      display: 'flex', gap: '0.75rem', padding: '0.65rem',
                      borderRadius: '0.75rem', transition: 'background 0.15s ease', cursor: 'pointer',
                      margin: '0.15rem 0',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-section)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                    >
                      <img
                        src={hotel.image_urls?.[0] || '/images/hotel.jpg'}
                        alt={hotel.name}
                        style={{ width: 56, height: 56, borderRadius: '0.6rem', objectFit: 'cover', flexShrink: 0 }}
                        loading="lazy"
                      />
                      <div style={{ minWidth: 0, flex: 1 }}>
                        <h3 style={{ fontSize: '0.85rem', fontWeight: 800, color: 'var(--text-dark)', margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {lang === 'ar' ? (hotel as unknown as { name_ar: string }).name_ar || hotel.name : hotel.name}
                        </h3>
                        <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.2rem', margin: '0.15rem 0' }}>
                          <MapPin style={{ width: 10, height: 10 }} /> {lang === 'ar' ? city?.name_ar : city?.name}
                        </p>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.72rem' }}>
                          <span style={{ color: 'var(--primary)', fontWeight: 700 }}>${hotel.price_per_night_usd}<span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>/{t('nt', 'ليلة')}</span></span>
                          <span style={{ display: 'flex', alignItems: 'center', gap: '0.1rem', color: 'var(--primary)' }}>
                            {Array.from({ length: hotel.star_rating }).map((_, i) => <Star key={i} style={{ width: 9, height: 9, fill: 'var(--primary)' }} />)}
                          </span>
                          <ChevronRight style={{ width: 12, height: 12, color: 'var(--text-muted)', marginInlineStart: 'auto' }} />
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}

              {loading && (
                <div style={{ textAlign: 'center', padding: '3rem' }}>
                  <Loader2 className="animate-spin" style={{ width: 24, height: 24, margin: '0 auto', color: 'var(--primary)' }} />
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
