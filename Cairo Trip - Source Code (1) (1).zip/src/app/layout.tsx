import type { Metadata } from 'next';
import './globals.css';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: 'Cairo Trip - Plan your trip to Cairo',
  description: 'Plan your Cairo trip on a budget. Hotels, attractions and restaurants in Cairo and Giza, with real prices.',
  keywords: 'Cairo, Giza, trip planner, Egypt, pyramids, hotels, attractions, budget travel, restaurants',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" dir="ltr" className="h-full antialiased">
      <body className="min-h-full flex flex-col">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
