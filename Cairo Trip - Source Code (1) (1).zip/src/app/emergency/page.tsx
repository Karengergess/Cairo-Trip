'use client';

import { useState, useEffect } from 'react';
import { useLang } from '@/contexts/LanguageContext';
import { Phone, Navigation, Siren, ShieldAlert, Pill, Hospital, Clock, MapPin, Filter } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { EmergencyFacility, City } from '@/types/database';

const emergencyNumbers = [
  { name_en: 'Ambulance', name_ar: 'الإسعاف', number: '123', icon: Siren, color: '#e74c3c', bg: '#e74c3c18' },
  { name_en: 'Police', name_ar: 'الشرطة', number: '122', icon: ShieldAlert, color: '#3498db', bg: '#3498db18' },
  { name_en: 'Fire Department', name_ar: 'المطافئ', number: '180', icon: Siren, color: '#f39c12', bg: '#f39c1218' },
  { name_en: 'Tourist Police', name_ar: 'شرطة السياحة', number: '126', icon: ShieldAlert, color: '#27ae60', bg: '#27ae6018' },
];

const typeIcons: Record<string, React.ElementType> = { hospital: Hospital, police: ShieldAlert, pharmacy: Pill };
const typeColors: Record<string, string> = { hospital: '#e74c3c', police: '#3498db', pharmacy: '#27ae60' };

export default function EmergencyPage() {
  const { t } = useLang();
  const [facilities, setFacilities] = useState<EmergencyFacility[]>([]);
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    supabase.from('emergency_facilities').select('*, city:cities(*)').order('type')
      .then(({ data }) => { if (data) setFacilities(data as unknown as EmergencyFacility[]); });
  }, []);

  const filtered = typeFilter === 'all' ? facilities : facilities.filter(f => f.type === typeFilter);

  return (
    <div style={{ minHeight: '100vh', padding: '100px 2rem 4rem' }}>
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="section-title">{t('Emergency Services', 'خدمات الطوارئ')}</h1>
          <p className="section-subtitle">{t('Quick access to help when you need it', 'وصول سريع للمساعدة عند الحاجة')}</p>
        </div>

        <div className="rounded-2xl p-6 mb-8" style={{ background: 'linear-gradient(135deg, #e74c3c, #c0392b)' }}>
          <h2 className="text-white font-extrabold text-lg mb-4 flex items-center gap-2"><Phone className="w-5 h-5" /> {t('Emergency Numbers', 'أرقام الطوارئ')}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {emergencyNumbers.map(em => (
              <a key={em.number} href={`tel:${em.number}`} className="flex items-center gap-3 p-4 rounded-xl bg-white/15 hover:bg-white/25 transition-all no-underline text-white">
                <em.icon className="w-6 h-6" />
                <div>
                  <div className="font-bold text-sm">{t(em.name_en, em.name_ar)}</div>
                  <div className="text-2xl font-black">{em.number}</div>
                </div>
              </a>
            ))}
          </div>
        </div>

        <div className="flex gap-2 mb-6">
          {['all', 'hospital', 'police', 'pharmacy'].map(type => (
            <button
              key={type}
              onClick={() => setTypeFilter(type)}
              className={`px-4 py-2 rounded-full text-sm font-bold border transition-all cursor-pointer ${
                typeFilter === type ? 'bg-primary text-white border-primary' : 'bg-bg-card text-text-body border-border hover:border-primary'
              }`}
            >
              {type === 'all' ? t('All', 'الكل') : type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map(f => {
            const Icon = typeIcons[f.type] || Hospital;
            const color = typeColors[f.type] || '#888';
            const city = f.city as unknown as City;
            return (
              <div key={f.id} className="bg-bg-card border border-border rounded-2xl p-5 hover:border-primary transition-all">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${color}18`, color }}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-text-dark mb-0.5">{f.name}</h3>
                    <p className="text-xs text-text-muted flex items-center gap-1 mb-2"><MapPin className="w-3 h-3" />{city?.name || ''}</p>
                    <div className="flex flex-wrap gap-2">
                      {f.phone && (
                        <a href={`tel:${f.phone}`} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-bold text-white no-underline" style={{ background: color }}>
                          <Phone className="w-3.5 h-3.5" /> {t('Call', 'اتصل')}
                        </a>
                      )}
                      <a href={`https://www.google.com/maps/dir/?api=1&destination=${f.latitude},${f.longitude}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-bg-section border border-border-light text-sm font-bold text-text-body no-underline hover:border-primary hover:text-primary transition-all">
                        <Navigation className="w-3.5 h-3.5" /> {t('Directions', 'اتجاهات')}
                      </a>
                      {f.is_24h && (
                        <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-success/10 text-success text-sm font-bold">
                          <Clock className="w-3.5 h-3.5" /> 24h
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-text-muted">
            <Hospital className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>{t('No facilities found. Emergency numbers are always available above.', 'لا توجد مرافق. أرقام الطوارئ متاحة دائمًا أعلاه.')}</p>
          </div>
        )}
      </div>
    </div>
  );
}
