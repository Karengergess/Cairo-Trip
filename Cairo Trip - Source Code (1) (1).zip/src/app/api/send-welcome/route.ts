import { NextRequest, NextResponse } from 'next/server';
import { Resend } from 'resend';
import { rateLimit, clientIp, isValidEmail, sanitizeText } from '@/lib/security';

export const runtime = 'edge';

const SITE = 'https://egypt-trip-planner.vercel.app';
const FROM = 'Cairo Trip Concierge <onboarding@resend.dev>';
const SUPPORT = 'hello@cairotrip.com';

function welcomeHtml(name: string) {
  const greeting = name.split(' ')[0] || 'traveler';
  return `<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f1e8;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f1e8;padding:32px 16px">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,0.06)">
      <tr><td style="background:linear-gradient(135deg,#c8860a,#8b5e00);padding:32px;color:#fff;text-align:center">
        <div style="font-size:13px;letter-spacing:0.12em;text-transform:uppercase;opacity:0.9;margin-bottom:6px">Cairo Trip</div>
        <div style="font-size:26px;font-weight:800">Welcome, ${greeting} 👋</div>
      </td></tr>
      <tr><td style="padding:32px">
        <p style="margin:0 0 18px;color:#333;font-size:15px;line-height:1.55">
          Thanks for joining Cairo Trip. Your account is ready and we're glad to help you plan your visit.
        </p>
        <p style="margin:0 0 22px;color:#555;font-size:14px;line-height:1.6">
          Here is what you can do right away:
        </p>

        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin-bottom:24px">
          <tr>
            <td style="padding:14px 16px;background:#fef9f3;border-radius:10px;border:1px solid #ede4d4">
              <strong style="color:#c8860a;font-size:14px">Plan a trip on a budget</strong>
              <div style="color:#555;font-size:13px;margin-top:4px">Enter how much you want to spend and we'll auto-generate a day-by-day plan.</div>
            </td>
          </tr>
          <tr><td style="height:10px"></td></tr>
          <tr>
            <td style="padding:14px 16px;background:#fef9f3;border-radius:10px;border:1px solid #ede4d4">
              <strong style="color:#c8860a;font-size:14px">Book hotels and ticket entries</strong>
              <div style="color:#555;font-size:13px;margin-top:4px">From Mena House by the Pyramids to skip-the-line at the Grand Egyptian Museum.</div>
            </td>
          </tr>
          <tr><td style="height:10px"></td></tr>
          <tr>
            <td style="padding:14px 16px;background:#fef9f3;border-radius:10px;border:1px solid #ede4d4">
              <strong style="color:#c8860a;font-size:14px">Save places to your favorites</strong>
              <div style="color:#555;font-size:13px;margin-top:4px">Tap the heart on any spot. Syncs across your devices.</div>
            </td>
          </tr>
          <tr><td style="height:10px"></td></tr>
          <tr>
            <td style="padding:14px 16px;background:#fef9f3;border-radius:10px;border:1px solid #ede4d4">
              <strong style="color:#c8860a;font-size:14px">Ask the assistant anything</strong>
              <div style="color:#555;font-size:13px;margin-top:4px">Prices, opening hours, what to wear. Use the chat bubble at the bottom of every page.</div>
            </td>
          </tr>
        </table>

        <a href="${SITE}/dashboard" style="display:block;padding:14px;background:linear-gradient(135deg,#c8860a,#8b5e00);color:#fff;text-decoration:none;text-align:center;font-weight:700;font-size:15px;border-radius:10px">Open my dashboard</a>

        <p style="margin:22px 0 0;color:#888;font-size:12px;line-height:1.6">
          Need help? Reply to this email or write to ${SUPPORT}.
        </p>
      </td></tr>
      <tr><td style="background:#1a1a1a;padding:18px 32px;color:rgba(255,255,255,0.6);font-size:11px;text-align:center">
        Cairo Trip - independent travel guide for Cairo and Giza.<br>
        You're receiving this because you created an account at ${SITE}.
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;
}

export async function POST(req: NextRequest) {
  try {
    if (!rateLimit(`welcome:${clientIp(req)}`, 5, 60_000)) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429 });
    }

    const key = process.env.RESEND_API_KEY;
    if (!key) return NextResponse.json({ error: 'Email service not configured' }, { status: 503 });

    const { email, name } = await req.json() as { email?: string; name?: string };
    if (!email || !isValidEmail(email)) return NextResponse.json({ error: 'Invalid email' }, { status: 400 });

    const resend = new Resend(key);
    const { error } = await resend.emails.send({
      from: FROM, to: email, subject: 'Welcome to Cairo Trip', html: welcomeHtml(sanitizeText(name || '', 80)),
    });
    if (error) {
      console.error('Welcome email error', error);
      return NextResponse.json({ error: error.message }, { status: 502 });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error('send-welcome handler', e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
