import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { Resend } from 'resend';
import { refCode } from '@/lib/refcode';
import { rateLimit, clientIp } from '@/lib/security';

export const runtime = 'edge';

const SITE = 'https://egypt-trip-planner.vercel.app';
const FROM = 'Cairo Trip Concierge <onboarding@resend.dev>';
const SUPPORT = 'hello@cairotrip.com';

type Body = { orderId: string; type: 'booking' | 'ticket'; status: 'confirmed' | 'cancelled' };

function fmtDate(d: string) {
  try { return new Date(d).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }); }
  catch { return d; }
}

const statusTheme = {
  confirmed: {
    color: '#16a34a',
    bg: 'linear-gradient(135deg,#16a34a,#15803d)',
    headline_b: 'Your booking is confirmed',
    headline_t: 'Your ticket is confirmed',
    body_b: 'Good news! Your hotel has confirmed your reservation. Show this email or your reference code at check-in.',
    body_t: 'Your ticket is confirmed and ready to use. Show the reference code at the entry gate.',
  },
  cancelled: {
    color: '#dc2626',
    bg: 'linear-gradient(135deg,#dc2626,#991b1b)',
    headline_b: 'Your booking was cancelled',
    headline_t: 'Your ticket was cancelled',
    body_b: 'Your hotel reservation has been cancelled. If you already paid, our team will issue a refund within 5-7 business days. For questions, reply to this email.',
    body_t: 'Your ticket has been cancelled. If you already paid, our team will issue a refund within 5-7 business days. For questions, reply to this email.',
  },
};

function buildEmail(opts: {
  type: 'booking' | 'ticket';
  status: 'confirmed' | 'cancelled';
  refCode: string;
  placeName: string;
  cityName: string;
  date1: string;
  date1Label: string;
  date2?: string;
  date2Label?: string;
  people: number;
  total: number;
  viewUrl: string;
}) {
  const theme = statusTheme[opts.status];
  const headline = opts.type === 'booking' ? theme.headline_b : theme.headline_t;
  const body = opts.type === 'booking' ? theme.body_b : theme.body_t;
  const peopleLabel = opts.type === 'booking' ? 'Guests' : 'Tickets';
  const peopleSuffix = opts.type === 'booking' ? '' : (opts.people === 1 ? ' person' : ' people');

  return `<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f1e8;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f1e8;padding:32px 16px">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,0.06)">
      <tr><td style="background:${theme.bg};padding:28px 32px;color:#fff">
        <div style="font-size:13px;letter-spacing:0.1em;text-transform:uppercase;opacity:0.85;margin-bottom:4px">Cairo Trip</div>
        <div style="font-size:22px;font-weight:800">${headline}</div>
      </td></tr>
      <tr><td style="padding:32px">
        <p style="margin:0 0 22px;color:#333;font-size:15px;line-height:1.55">${body}</p>

        <div style="background:#fef9f3;border:2px dashed ${theme.color};border-radius:12px;padding:20px;text-align:center;margin-bottom:24px">
          <div style="font-size:11px;letter-spacing:0.1em;text-transform:uppercase;color:#666;font-weight:700;margin-bottom:6px">Reference code</div>
          <div style="font-size:28px;font-weight:900;color:${theme.color};letter-spacing:0.08em;font-family:monospace">${opts.refCode}</div>
        </div>

        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">${opts.type === 'booking' ? 'Hotel' : 'Attraction'}</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.placeName}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">City</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.cityName}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">${opts.date1Label}</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${fmtDate(opts.date1)}</td></tr>
          ${opts.date2 ? `
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">${opts.date2Label}</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${fmtDate(opts.date2)}</td></tr>` : ''}
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">${peopleLabel}</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.people}${peopleSuffix}</td></tr>
          <tr><td style="padding:10px 0;color:#666;font-size:13px">Total paid</td>
              <td style="padding:10px 0;color:${theme.color};font-size:18px;font-weight:900;text-align:right">$${opts.total}</td></tr>
        </table>

        ${opts.status === 'confirmed' ? `<a href="${opts.viewUrl}" style="display:block;margin:28px 0 0;padding:14px;background:${theme.bg};color:#fff;text-decoration:none;text-align:center;font-weight:700;font-size:15px;border-radius:10px">View ${opts.type === 'booking' ? 'booking' : 'ticket'} online</a>` : ''}

        <p style="margin:24px 0 0;color:#888;font-size:12px;line-height:1.6">
          Questions or changes? Reply to this email or write to ${SUPPORT}.
        </p>
      </td></tr>
      <tr><td style="background:#1a1a1a;padding:18px 32px;color:rgba(255,255,255,0.6);font-size:11px;text-align:center">
        Cairo Trip - independent travel guide. Reach us at <a href="mailto:${SUPPORT}" style="color:#f4c842;text-decoration:none">${SUPPORT}</a>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;
}

export async function POST(req: NextRequest) {
  try {
    if (!rateLimit(`status:${clientIp(req)}`, 10, 60_000)) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429 });
    }

    const apiKey = process.env.RESEND_API_KEY;
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const svc = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!apiKey || !url || !svc) {
      return NextResponse.json({ error: 'Server misconfigured' }, { status: 500 });
    }

    const body = await req.json() as Body;
    if (!body.orderId || !body.type || !body.status) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    }

    // Admin-only endpoint: verify the caller's session and role.
    const authHeader = req.headers.get('authorization') || '';
    const token = authHeader.toLowerCase().startsWith('bearer ') ? authHeader.slice(7).trim() : '';
    if (!token) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    if (!anon) return NextResponse.json({ error: 'Server error' }, { status: 500 });
    const supaUser = createClient(url, anon, {
      auth: { persistSession: false },
      global: { headers: { Authorization: `Bearer ${token}` } },
    });
    const { data: { user: caller } } = await supaUser.auth.getUser();
    if (!caller) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const { data: prof } = await supaUser.from('profiles').select('role').eq('id', caller.id).maybeSingle();
    if (!prof || (prof as { role?: string }).role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const supa = createClient(url, svc, { auth: { persistSession: false } });
    const resend = new Resend(apiKey);

    let recipient = '';
    let subject = '';
    let html = '';
    let viewUrl = '';

    if (body.type === 'booking') {
      const { data: row, error } = await supa
        .from('bookings')
        .select('id, user_id, check_in, check_out, guests, total_price_usd, guest_email, hotel:hotels(name, city:cities(name))')
        .eq('id', body.orderId)
        .single();
      if (error || !row) return NextResponse.json({ error: 'Booking not found' }, { status: 404 });

      const hotel = row.hotel as unknown as { name: string; city?: { name: string } } | null;
      const code = refCode('HTL', row.id);
      viewUrl = `${SITE}/booking/${row.id}`;
      recipient = row.guest_email || '';
      if (!recipient) {
        const { data: u } = await supa.auth.admin.getUserById(row.user_id);
        recipient = u?.user?.email || '';
      }

      subject = body.status === 'confirmed'
        ? `Confirmed: ${hotel?.name || 'your booking'} (${code})`
        : `Cancelled: ${hotel?.name || 'your booking'} (${code})`;
      html = buildEmail({
        type: 'booking', status: body.status, refCode: code,
        placeName: hotel?.name || 'Hotel', cityName: hotel?.city?.name || 'Cairo',
        date1: row.check_in, date1Label: 'Check-in',
        date2: row.check_out, date2Label: 'Check-out',
        people: row.guests, total: row.total_price_usd, viewUrl,
      });
    } else {
      const { data: row, error } = await supa
        .from('tickets')
        .select('id, user_id, visit_date, num_people, total_price_usd, attraction:attractions(name, city:cities(name))')
        .eq('id', body.orderId)
        .single();
      if (error || !row) return NextResponse.json({ error: 'Ticket not found' }, { status: 404 });

      const attr = row.attraction as unknown as { name: string; city?: { name: string } } | null;
      const code = refCode('TKT', row.id);
      viewUrl = `${SITE}/ticket/${row.id}`;
      const { data: u } = await supa.auth.admin.getUserById(row.user_id);
      recipient = u?.user?.email || '';

      subject = body.status === 'confirmed'
        ? `Confirmed: ${attr?.name || 'your ticket'} (${code})`
        : `Cancelled: ${attr?.name || 'your ticket'} (${code})`;
      html = buildEmail({
        type: 'ticket', status: body.status, refCode: code,
        placeName: attr?.name || 'Attraction', cityName: attr?.city?.name || 'Cairo',
        date1: row.visit_date, date1Label: 'Visit date',
        people: row.num_people, total: row.total_price_usd, viewUrl,
      });
    }

    if (!recipient) return NextResponse.json({ error: 'No email on file' }, { status: 400 });
    const { error: sendErr } = await resend.emails.send({ from: FROM, to: recipient, subject, html });
    if (sendErr) {
      console.error('Resend status email error', sendErr);
      return NextResponse.json({ error: 'Could not send the email' }, { status: 502 });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error('send-status-update handler', e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
