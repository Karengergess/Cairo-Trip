import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { Resend } from 'resend';
import { refCode } from '@/lib/refcode';
import { rateLimit, clientIp } from '@/lib/security';

export const runtime = 'edge';

const SITE = 'https://egypt-trip-planner.vercel.app';
const FROM = 'Cairo Trip Concierge <onboarding@resend.dev>';
const SUPPORT = 'hello@cairotrip.com';

type Body = { orderId: string; type: 'booking' | 'ticket'; email?: string };

function fmtDate(d: string) {
  try { return new Date(d).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }); }
  catch { return d; }
}

function ticketEmailHtml(opts: {
  refCode: string; attractionName: string; cityName: string;
  visitDate: string; numPeople: number; total: number; viewUrl: string;
}) {
  return `<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f1e8;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f1e8;padding:32px 16px">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,0.06)">
      <tr><td style="background:linear-gradient(135deg,#c8860a,#8b5e00);padding:24px 32px;color:#fff">
        <div style="font-size:13px;letter-spacing:0.1em;text-transform:uppercase;opacity:0.85;margin-bottom:4px">Cairo Trip</div>
        <div style="font-size:22px;font-weight:800">Your ticket is confirmed</div>
      </td></tr>
      <tr><td style="padding:32px">
        <p style="margin:0 0 20px;color:#333;font-size:15px;line-height:1.5">
          Thank you for booking with Cairo Trip. Save this email or take a screenshot. Show the reference code at the entry gate.
        </p>

        <div style="background:#fef9f3;border:2px dashed #c8860a;border-radius:12px;padding:20px;text-align:center;margin-bottom:24px">
          <div style="font-size:11px;letter-spacing:0.1em;text-transform:uppercase;color:#666;font-weight:700;margin-bottom:6px">Your reference code</div>
          <div style="font-size:28px;font-weight:900;color:#c8860a;letter-spacing:0.08em;font-family:monospace">${opts.refCode}</div>
        </div>

        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">Attraction</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.attractionName}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">City</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.cityName}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">Visit date</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${fmtDate(opts.visitDate)}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">Tickets</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.numPeople} ${opts.numPeople === 1 ? 'person' : 'people'}</td></tr>
          <tr><td style="padding:10px 0;color:#666;font-size:13px">Total paid</td>
              <td style="padding:10px 0;color:#c8860a;font-size:18px;font-weight:900;text-align:right">$${opts.total}</td></tr>
        </table>

        <a href="${opts.viewUrl}" style="display:block;margin:28px 0 0;padding:14px;background:linear-gradient(135deg,#c8860a,#8b5e00);color:#fff;text-decoration:none;text-align:center;font-weight:700;font-size:15px;border-radius:10px">View ticket online</a>

        <p style="margin:24px 0 0;color:#888;font-size:12px;line-height:1.6">
          Arrive 15 minutes before your visit. Bring photo ID. If your plans change, contact us at ${SUPPORT}.
        </p>
      </td></tr>
      <tr><td style="background:#1a1a1a;padding:18px 32px;color:rgba(255,255,255,0.6);font-size:11px;text-align:center">
        Cairo Trip - independent travel guide. We are not affiliated with the venue.<br>
        Questions? <a href="mailto:${SUPPORT}" style="color:#f4c842;text-decoration:none">${SUPPORT}</a>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;
}

function bookingEmailHtml(opts: {
  refCode: string; hotelName: string; cityName: string;
  checkIn: string; checkOut: string; guests: number; total: number; status: string; viewUrl: string;
}) {
  const isPending = opts.status === 'pending';
  return `<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f5f1e8;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f1e8;padding:32px 16px">
  <tr><td align="center">
    <table width="560" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,0.06)">
      <tr><td style="background:linear-gradient(135deg,#c8860a,#8b5e00);padding:24px 32px;color:#fff">
        <div style="font-size:13px;letter-spacing:0.1em;text-transform:uppercase;opacity:0.85;margin-bottom:4px">Cairo Trip</div>
        <div style="font-size:22px;font-weight:800">${isPending ? 'Reservation received' : 'Booking confirmed'}</div>
      </td></tr>
      <tr><td style="padding:32px">
        <p style="margin:0 0 20px;color:#333;font-size:15px;line-height:1.5">
          ${isPending
            ? 'We received your reservation and your payment. Our team is confirming with the hotel and will email you again within 24 hours.'
            : 'Your room is booked. Show this email or your reference code at check-in.'}
        </p>

        <div style="background:#fef9f3;border:2px dashed #c8860a;border-radius:12px;padding:20px;text-align:center;margin-bottom:24px">
          <div style="font-size:11px;letter-spacing:0.1em;text-transform:uppercase;color:#666;font-weight:700;margin-bottom:6px">Booking reference</div>
          <div style="font-size:28px;font-weight:900;color:#c8860a;letter-spacing:0.08em;font-family:monospace">${opts.refCode}</div>
        </div>

        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">Hotel</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.hotelName}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">City</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.cityName}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">Check-in</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${fmtDate(opts.checkIn)}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">Check-out</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${fmtDate(opts.checkOut)}</td></tr>
          <tr><td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#666;font-size:13px">Guests</td>
              <td style="padding:10px 0;border-bottom:1px solid #ede4d4;color:#1a1a1a;font-size:14px;font-weight:700;text-align:right">${opts.guests}</td></tr>
          <tr><td style="padding:10px 0;color:#666;font-size:13px">Total paid</td>
              <td style="padding:10px 0;color:#c8860a;font-size:18px;font-weight:900;text-align:right">$${opts.total}</td></tr>
        </table>

        <a href="${opts.viewUrl}" style="display:block;margin:28px 0 0;padding:14px;background:linear-gradient(135deg,#c8860a,#8b5e00);color:#fff;text-decoration:none;text-align:center;font-weight:700;font-size:15px;border-radius:10px">View booking online</a>

        <p style="margin:24px 0 0;color:#888;font-size:12px;line-height:1.6">
          Standard check-in is from 14:00 and check-out by 12:00. To change dates or cancel, email ${SUPPORT}.
        </p>
      </td></tr>
      <tr><td style="background:#1a1a1a;padding:18px 32px;color:rgba(255,255,255,0.6);font-size:11px;text-align:center">
        Cairo Trip - independent travel guide. We are not the hotel itself.<br>
        Questions? <a href="mailto:${SUPPORT}" style="color:#f4c842;text-decoration:none">${SUPPORT}</a>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;
}

export async function POST(req: NextRequest) {
  try {
    if (!rateLimit(`confirm:${clientIp(req)}`, 10, 60_000)) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429 });
    }

    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: 'Email service not configured. Order is saved; please contact ' + SUPPORT }, { status: 503 });
    }

    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const svc = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !svc) return NextResponse.json({ error: 'Server misconfigured' }, { status: 500 });

    const body = await req.json() as Body;
    if (!body.orderId || !body.type) return NextResponse.json({ error: 'Missing orderId or type' }, { status: 400 });

    // Require an authenticated caller and verify they own the order.
    const authHeader = req.headers.get('authorization') || '';
    const token = authHeader.toLowerCase().startsWith('bearer ') ? authHeader.slice(7).trim() : '';
    if (!token) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    if (!anon) return NextResponse.json({ error: 'Server error' }, { status: 500 });
    const supaUser = createClient(url, anon, {
      auth: { persistSession: false },
      global: { headers: { Authorization: `Bearer ${token}` } },
    });
    const { data: { user: caller } } = await supaUser.auth.getUser();
    if (!caller) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const supa = createClient(url, svc, { auth: { persistSession: false } });
    const resend = new Resend(apiKey);

    // Recipient is derived from the order owner only. A client-supplied address
    // is ignored so this endpoint cannot be used to send mail to arbitrary inboxes.
    let recipient = '';

    let html = '';
    let subject = '';
    let viewUrl = '';

    if (body.type === 'ticket') {
      const { data: t, error } = await supa
        .from('tickets')
        .select('id, user_id, visit_date, num_people, total_price_usd, attraction:attractions(name, city:cities(name))')
        .eq('id', body.orderId)
        .single();
      if (error || !t) return NextResponse.json({ error: 'Order not found' }, { status: 404 });
      if (t.user_id !== caller.id) return NextResponse.json({ error: 'Not found' }, { status: 404 });

      if (!recipient) {
        const { data: u } = await supa.auth.admin.getUserById(t.user_id);
        recipient = u?.user?.email || '';
      }

      const code = refCode('TKT', t.id);
      viewUrl = `${SITE}/ticket/${t.id}`;
      const a = (t.attraction as unknown as { name: string; city?: { name: string } } | null);

      subject = `Your Cairo Trip ticket: ${a?.name || 'Attraction'} (${code})`;
      html = ticketEmailHtml({
        refCode: code,
        attractionName: a?.name || 'Attraction',
        cityName: a?.city?.name || 'Cairo',
        visitDate: t.visit_date,
        numPeople: t.num_people,
        total: t.total_price_usd,
        viewUrl,
      });
    } else {
      const { data: b, error } = await supa
        .from('bookings')
        .select('id, user_id, check_in, check_out, guests, total_price_usd, status, hotel:hotels(name, city:cities(name))')
        .eq('id', body.orderId)
        .single();
      if (error || !b) return NextResponse.json({ error: 'Order not found' }, { status: 404 });
      if (b.user_id !== caller.id) return NextResponse.json({ error: 'Not found' }, { status: 404 });

      if (!recipient) {
        const { data: u } = await supa.auth.admin.getUserById(b.user_id);
        recipient = u?.user?.email || '';
      }

      const code = refCode('HTL', b.id);
      viewUrl = `${SITE}/booking/${b.id}`;
      const h = (b.hotel as unknown as { name: string; city?: { name: string } } | null);

      subject = `Your Cairo Trip booking: ${h?.name || 'Hotel'} (${code})`;
      html = bookingEmailHtml({
        refCode: code,
        hotelName: h?.name || 'Hotel',
        cityName: h?.city?.name || 'Cairo',
        checkIn: b.check_in,
        checkOut: b.check_out,
        guests: b.guests,
        total: b.total_price_usd,
        status: b.status,
        viewUrl,
      });
    }

    if (!recipient) return NextResponse.json({ error: 'No email on file for this order' }, { status: 400 });
    const { error: sendErr } = await resend.emails.send({ from: FROM, to: recipient, subject, html });
    if (sendErr) {
      console.error('Resend error', sendErr);
      return NextResponse.json({ error: 'Could not send the confirmation email' }, { status: 502 });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error('send-confirmation error', e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
