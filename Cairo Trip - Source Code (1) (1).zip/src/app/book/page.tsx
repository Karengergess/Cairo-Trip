'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useUI } from '@/contexts/UIContext';
import {
  CalendarDays, Users, Mail, Phone, User, ArrowRight, ArrowLeft,
  Loader2, Hotel as HotelIcon, MapPin, CheckCircle2, LogIn,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Hotel } from '@/types/database';
import { toEGP } from '@/lib/egp';
import SmartImage from '@/components/SmartImage';
import PhoneInput from '@/components/PhoneInput';

function BookingForm() {
  const { t, lang } = useLang();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useUI();
  const router = useRouter();
  const searchParams = useSearchParams();
  const hotelId = searchParams.get('hotel');
  const isAr = lang === 'ar';

  const [step, setStep] = useState(1);
  const [hotel, setHotel] = useState<Hotel | null>(null);
  const [loadingHotel, setLoadingHotel] = useState(true);
  const [form, setForm] = useState({
    checkIn: '', checkOut: '', rooms: 1, guests: 2,
    name: '', email: '', phone: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const MAX_ROOMS = 5;
  const GUESTS_PER_ROOM = 4;
  const maxGuests = form.rooms * GUESTS_PER_ROOM;

  useEffect(() => {
    if (user?.email) setForm(p => ({ ...p, email: user.email!, name: p.name }));
  }, [user]);

  useEffect(() => {
    if (!hotelId) { setLoadingHotel(false); return; }
    supabase.from('hotels').select('*, city:cities(*)').eq('id', hotelId).single()
      .then(({ data }) => {
        if (data) setHotel(data as unknown as Hotel);
        setLoadingHotel(false);
      });
  }, [hotelId]);

  const nights = form.checkIn && form.checkOut
    ? Math.max(1, Math.ceil((new Date(form.checkOut).getTime() - new Date(form.checkIn).getTime()) / 86400000))
    : 0;
  const total = hotel ? nights * hotel.price_per_night_usd * form.rooms : 0;

  useEffect(() => {
    if (form.guests > maxGuests) setForm(p => ({ ...p, guests: maxGuests }));
  }, [form.rooms, form.guests, maxGuests]);

  const handleSubmit = async () => {
    if (!user || !hotel) return;
    setSubmitting(true);

    // User-side guard: this user can't have another active booking at the same hotel
    // unless the existing one has already checked out.
    const today = new Date().toISOString().split('T')[0];
    const { data: mine } = await supabase
      .from('bookings')
      .select('id, check_out')
      .eq('user_id', user.id)
      .eq('hotel_id', hotel.id)
      .neq('status', 'cancelled')
      .gte('check_out', today);

    if (mine && mine.length > 0) {
      setSubmitting(false);
      toast({
        message: t(
          'You already have an active booking at this hotel. Cancel it first or wait until check-out.',
          'عندك حجز نشط بالفعل في الفندق ده. الغيه الأول أو استنى موعد الخروج.'
        ),
        type: 'error',
      });
      return;
    }

    // Availability: refuse if any existing non-cancelled booking overlaps these dates.
    // Two ranges overlap when: existing.check_in < new.check_out AND existing.check_out > new.check_in
    const { data: conflicts } = await supabase
      .from('bookings')
      .select('id')
      .eq('hotel_id', hotel.id)
      .neq('status', 'cancelled')
      .lt('check_in', form.checkOut)
      .gt('check_out', form.checkIn);

    if (conflicts && conflicts.length > 0) {
      setSubmitting(false);
      toast({
        message: t(
          'These dates are already booked at this hotel. Pick different dates.',
          'التواريخ دي محجوزة بالفعل في الفندق. اختر تواريخ تانية.'
        ),
        type: 'error',
      });
      setStep(1);
      return;
    }

    const { data, error } = await (supabase.from('bookings') as any).insert({
      user_id: user.id, hotel_id: hotel.id,
      check_in: form.checkIn, check_out: form.checkOut,
      guests: form.guests, total_price_usd: total, status: 'pending',
      guest_name: form.name.trim(),
      guest_email: form.email.trim(),
      guest_phone: form.phone.trim(),
    }).select('id').single();
    setSubmitting(false);
    if (error) {
      toast({ message: error.message, type: 'error' });
      return;
    }
    router.push(`/payment?amount=${total}&currency=USD&order=${data.id}`);
  };

  if (loadingHotel || authLoading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Loader2 className="animate-spin" style={{ width: 32, height: 32, color: 'var(--primary)' }} />
      </div>
    );
  }

  if (!hotelId || !hotel) {
    return (
      <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)', textAlign: 'center' }} dir={isAr ? 'rtl' : 'ltr'}>
        <div style={{ maxWidth: 480, margin: '0 auto', padding: '3rem 2rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.5rem' }}>
          <HotelIcon style={{ width: 56, height: 56, color: 'var(--primary)', opacity: 0.4, margin: '0 auto 1rem' }} />
          <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
            {t('Pick a hotel first', 'اختر فندق أولاً')}
          </h1>
          <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
            {t('Browse our hotels and click "Book Now" on any of them.', 'تصفح الفنادق واضغط "احجز الآن" على أيٍ منها.')}
          </p>
          <Link href="/hotels" className="btn-primary" style={{ textDecoration: 'none', padding: '0.75rem 1.5rem', display: 'inline-flex' }}>
            <HotelIcon style={{ width: 16, height: 16 }} /> {t('Browse Hotels', 'تصفح الفنادق')}
          </Link>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
        <div style={{ maxWidth: 480, margin: '0 auto', padding: '2.5rem 2rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.5rem', textAlign: 'center' }}>
          <div style={{ width: 64, height: 64, margin: '0 auto 1rem', borderRadius: '50%', background: 'rgba(200,134,10,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <LogIn style={{ width: 28, height: 28, color: 'var(--primary)' }} />
          </div>
          <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
            {t('Sign in to book', 'سجّل دخول للحجز')}
          </h1>
          <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
            {t('You need an account to make a reservation. It only takes a moment.', 'تحتاج حساب لتأكيد الحجز. الأمر يستغرق دقيقة.')}
          </p>
          <div style={{ display: 'flex', gap: '0.6rem' }}>
            <Link href={`/auth/login?redirect=/book?hotel=${hotel.id}`} className="btn-primary" style={{ flex: 1, textDecoration: 'none', justifyContent: 'center', padding: '0.75rem' }}>
              {t('Sign In', 'دخول')}
            </Link>
            <Link href={`/auth/signup?redirect=/book?hotel=${hotel.id}`} style={{
              flex: 1, padding: '0.75rem', borderRadius: '0.75rem',
              background: 'var(--bg-section)', border: '1px solid var(--border)',
              color: 'var(--text-body)', fontWeight: 700, fontSize: '0.9rem',
              textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {t('Sign Up', 'حساب جديد')}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const steps = [
    { num: 1, label: t('Dates', 'التواريخ'), icon: CalendarDays },
    { num: 2, label: t('Contact', 'الاتصال'), icon: User },
    { num: 3, label: t('Confirm', 'تأكيد'), icon: CheckCircle2 },
  ];

  const cardStyle: React.CSSProperties = {
    background: 'var(--bg-card)', border: '1px solid var(--border)',
    borderRadius: '1.25rem', padding: '1.5rem',
  };

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 640, margin: '0 auto' }}>

        <div style={{ textAlign: 'center', marginBottom: '1.75rem' }}>
          <h1 style={{ fontSize: '1.85rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Book Your Stay', 'احجز إقامتك')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
            {t('Complete the steps below to reserve your room', 'أكمل الخطوات أدناه لحجز غرفتك')}
          </p>
        </div>

        {/* HOTEL CARD */}
        <div style={{
          ...cardStyle, padding: '1rem', marginBottom: '1.25rem',
          display: 'flex', alignItems: 'center', gap: '1rem',
        }}>
          <div style={{ width: 80, height: 80, borderRadius: '0.75rem', overflow: 'hidden', flexShrink: 0 }}>
            <SmartImage src={hotel.image_urls?.[0]} alt={hotel.name} fallbackName={hotel.name} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3 style={{ fontWeight: 800, color: 'var(--text-dark)', fontSize: '1.05rem', marginBottom: '0.2rem' }}>
              {isAr ? (hotel as unknown as { name_ar: string }).name_ar || hotel.name : hotel.name}
            </h3>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '0.4rem' }}>
              <MapPin style={{ width: 12, height: 12 }} />
              {isAr ? (hotel as unknown as { city?: { name_ar: string } }).city?.name_ar : (hotel as unknown as { city?: { name: string } }).city?.name}
            </p>
            <p style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary)' }}>
              ${hotel.price_per_night_usd}/{t('night', 'ليلة')}
              {nights > 0 && (
                <span style={{ color: 'var(--text-muted)', fontWeight: 500 }}>
                  {' '}· {nights} × {form.rooms > 1 ? `${form.rooms} × ` : ''}= <strong style={{ color: 'var(--primary)' }}>${total}</strong>
                </span>
              )}
            </p>
          </div>
        </div>

        {/* STEP INDICATOR */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
          {steps.map((s, i) => {
            const isActive = step === s.num;
            const isDone = step > s.num;
            return (
              <div key={s.num} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '50%',
                  background: isDone ? '#27ae60' : isActive ? 'linear-gradient(135deg, var(--primary), var(--accent))' : 'var(--bg-section)',
                  color: isDone || isActive ? '#fff' : 'var(--text-muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 800, fontSize: '0.85rem',
                  boxShadow: isActive ? '0 4px 12px rgba(200,134,10,0.35)' : 'none',
                  transition: 'all 0.2s',
                }}>
                  {isDone ? <CheckCircle2 style={{ width: 16, height: 16 }} /> : s.num}
                </div>
                <span style={{
                  fontSize: '0.82rem', fontWeight: 700,
                  color: isActive ? 'var(--primary)' : isDone ? '#27ae60' : 'var(--text-muted)',
                }}>{s.label}</span>
                {i < steps.length - 1 && <div style={{ width: 24, height: 2, background: 'var(--border)' }} />}
              </div>
            );
          })}
        </div>

        {/* STEPS */}
        <div style={cardStyle}>
          {step === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                    <CalendarDays style={{ width: 14, height: 14 }} /> {t('Check In', 'الوصول')}
                  </label>
                  <input type="date" min={todayStr} value={form.checkIn}
                    onChange={e => setForm(p => ({ ...p, checkIn: e.target.value }))} className="input" />
                </div>
                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                    <CalendarDays style={{ width: 14, height: 14 }} /> {t('Check Out', 'المغادرة')}
                  </label>
                  <input type="date" min={form.checkIn || todayStr} value={form.checkOut}
                    onChange={e => setForm(p => ({ ...p, checkOut: e.target.value }))} className="input" />
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                    <HotelIcon style={{ width: 14, height: 14 }} /> {t('Rooms', 'الغرف')}
                  </label>
                  <select value={form.rooms} onChange={e => setForm(p => ({ ...p, rooms: Number(e.target.value) }))} className="input">
                    {Array.from({ length: MAX_ROOMS }, (_, i) => i + 1).map(n => (
                      <option key={n} value={n}>
                        {n} {t(n === 1 ? 'room' : 'rooms', n === 1 ? 'غرفة' : 'غرف')}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                    <Users style={{ width: 14, height: 14 }} /> {t('Guests', 'الضيوف')}
                  </label>
                  <select value={form.guests} onChange={e => setForm(p => ({ ...p, guests: Number(e.target.value) }))} className="input">
                    {Array.from({ length: maxGuests }, (_, i) => i + 1).map(n => (
                      <option key={n} value={n}>
                        {n} {t(n === 1 ? 'guest' : 'guests', n === 1 ? 'ضيف' : 'ضيوف')}
                      </option>
                    ))}
                  </select>
                  <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.3rem' }}>
                    {t(`Up to ${GUESTS_PER_ROOM} guests per room`, `حتى ${GUESTS_PER_ROOM} ضيوف لكل غرفة`)}
                  </p>
                </div>
              </div>
              {nights > 0 && (
                <div style={{
                  padding: '0.85rem 1rem', borderRadius: '0.75rem',
                  background: 'rgba(200,134,10,0.08)', border: '1px solid rgba(200,134,10,0.25)',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                  <span style={{ fontSize: '0.85rem', color: 'var(--text-body)' }}>
                    {nights} {t(nights === 1 ? 'night' : 'nights', nights === 1 ? 'ليلة' : 'ليالٍ')}
                  </span>
                  <span style={{ fontSize: '1.15rem', fontWeight: 900, color: 'var(--primary)' }}>${total}</span>
                </div>
              )}
              <button onClick={() => setStep(2)} disabled={!form.checkIn || !form.checkOut || nights < 1} className="btn-primary"
                style={{ padding: '0.85rem', justifyContent: 'center', opacity: (!form.checkIn || !form.checkOut || nights < 1) ? 0.5 : 1, cursor: (!form.checkIn || !form.checkOut || nights < 1) ? 'not-allowed' : 'pointer' }}>
                {t('Next', 'التالي')} <ArrowRight style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} />
              </button>
            </div>
          )}

          {step === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  <User style={{ width: 14, height: 14 }} /> {t('Full Name', 'الاسم الكامل')}
                </label>
                <input type="text" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  className="input" placeholder={t('John Doe', 'محمد أحمد')} />
              </div>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  <Mail style={{ width: 14, height: 14 }} /> {t('Email', 'البريد الإلكتروني')}
                </label>
                <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} className="input" />
              </div>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  <Phone style={{ width: 14, height: 14 }} /> {t('Phone', 'رقم الهاتف')}
                </label>
                <PhoneInput value={form.phone} onChange={(v) => setForm(p => ({ ...p, phone: v }))} required />
              </div>
              <div style={{ display: 'flex', gap: '0.6rem' }}>
                <button onClick={() => setStep(1)} style={{
                  flex: 1, padding: '0.85rem', borderRadius: '0.75rem',
                  background: 'var(--bg-section)', border: '1px solid var(--border)',
                  color: 'var(--text-body)', fontWeight: 700, fontSize: '0.9rem',
                  cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                  fontFamily: 'inherit',
                }}>
                  <ArrowLeft style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} /> {t('Back', 'رجوع')}
                </button>
                {(() => {
                  const phoneDigits = form.phone.replace(/\D/g, '').length;
                  const isNameValid = /^[\p{L}'\-\.\s]{2,}$/u.test(form.name.trim()) && form.name.trim().split(/\s+/).length >= 2 && form.name.trim().split(/\s+/).every(w => w.length >= 2);
                  const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email);
                  const isPhoneValid = phoneDigits >= 7 && phoneDigits <= 15;
                  const valid = isNameValid && isEmailValid && isPhoneValid;
                  return (
                    <button onClick={() => setStep(3)} disabled={!valid} className="btn-primary"
                      style={{ flex: 1, padding: '0.85rem', justifyContent: 'center', opacity: valid ? 1 : 0.5 }}>
                      {t('Next', 'التالي')} <ArrowRight style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} />
                    </button>
                  );
                })()}
              </div>
            </div>
          )}

          {step === 3 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <h3 style={{ fontWeight: 800, color: 'var(--text-dark)', fontSize: '1.05rem', marginBottom: '0.25rem' }}>
                {t('Review & confirm', 'مراجعة وتأكيد')}
              </h3>
              <div style={{
                padding: '1rem', borderRadius: '0.85rem',
                background: 'var(--bg-section)', border: '1px solid var(--border-light)',
                display: 'flex', flexDirection: 'column', gap: '0.6rem',
              }}>
                {[
                  { label: t('Hotel', 'الفندق'), value: isAr ? (hotel as unknown as { name_ar: string }).name_ar || hotel.name : hotel.name },
                  { label: t('Check In', 'الوصول'), value: form.checkIn },
                  { label: t('Check Out', 'المغادرة'), value: form.checkOut },
                  { label: t('Nights', 'الليالي'), value: String(nights) },
                  { label: t('Rooms', 'الغرف'), value: String(form.rooms) },
                  { label: t('Guests', 'الضيوف'), value: String(form.guests) },
                  { label: t('Guest', 'الضيف'), value: form.name },
                ].map(r => (
                  <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem' }}>
                    <span style={{ color: 'var(--text-muted)' }}>{r.label}</span>
                    <span style={{ fontWeight: 700, color: 'var(--text-dark)' }}>{r.value}</span>
                  </div>
                ))}
              </div>

              <div style={{
                padding: '1rem 1.25rem', borderRadius: '0.85rem',
                background: 'linear-gradient(135deg, var(--primary), var(--accent))', color: '#fff',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <span style={{ fontSize: '0.9rem', opacity: 0.9 }}>{t('Total to pay', 'المبلغ الإجمالي')}</span>
                <div style={{ textAlign: 'end' }}>
                  <div style={{ fontSize: '1.6rem', fontWeight: 900, lineHeight: 1 }}>${total}</div>
                  <div style={{ fontSize: '0.75rem', opacity: 0.85 }}>{toEGP(total)} EGP</div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.6rem' }}>
                <button onClick={() => setStep(2)} style={{
                  flex: 1, padding: '0.85rem', borderRadius: '0.75rem',
                  background: 'var(--bg-section)', border: '1px solid var(--border)',
                  color: 'var(--text-body)', fontWeight: 700, fontSize: '0.9rem',
                  cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                  fontFamily: 'inherit',
                }}>
                  <ArrowLeft style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} /> {t('Back', 'رجوع')}
                </button>
                <button onClick={handleSubmit} disabled={submitting} className="btn-primary"
                  style={{ flex: 1.5, padding: '0.85rem', justifyContent: 'center', opacity: submitting ? 0.7 : 1 }}>
                  {submitting ? <Loader2 className="animate-spin" style={{ width: 16, height: 16 }} /> : <CheckCircle2 style={{ width: 16, height: 16 }} />}
                  {submitting ? t('Booking...', 'جاري الحجز...') : t('Confirm & Pay', 'تأكيد ودفع')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function BookPage() {
  return (
    <Suspense fallback={
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Loader2 className="animate-spin" style={{ width: 32, height: 32, color: 'var(--primary)' }} />
      </div>
    }>
      <BookingForm />
    </Suspense>
  );
}
