'use client';

import { useState } from 'react';
import { useLang } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { MessageSquareHeart, Send, CheckCircle, Star, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { isValidEmail, sanitizeText, sanitizeTextarea } from '@/lib/security';

export default function FeedbackPage() {
  const { t, lang } = useLang();
  const { user } = useAuth();
  const isAr = lang === 'ar';
  const [form, setForm] = useState({ name: '', email: user?.email || '', message: '' });
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const name = sanitizeText(form.name, 80);
    const message = sanitizeTextarea(form.message, 1000);
    if (name.length < 2) { setError(t('Please enter your name.', 'من فضلك أدخل اسمك.')); return; }
    if (form.email.trim() && !isValidEmail(form.email.trim())) {
      setError(t('Please enter a valid email or leave it blank.', 'أدخل بريدًا صحيحًا أو اتركه فارغًا.')); return;
    }
    if (message.length < 4) { setError(t('Please write a little feedback.', 'من فضلك اكتب رأيك.')); return; }

    setLoading(true);
    const { error: insErr } = await (supabase.from('feedback') as unknown as {
      insert: (d: Record<string, unknown>) => Promise<{ error: { message: string } | null }>;
    }).insert({
      name,
      email: form.email.trim() || null,
      rating: rating || null,
      message,
    });
    setLoading(false);
    if (insErr) { setError(t('Could not send your feedback. Please try again.', 'تعذّر إرسال رأيك. حاول مرة أخرى.')); return; }
    setSubmitted(true);
  };

  const card: React.CSSProperties = {
    background: 'var(--bg-card)', border: '1px solid var(--border)',
    borderRadius: '1.5rem', padding: '2rem', boxShadow: '0 14px 40px rgba(0,0,0,0.07)',
  };

  if (submitted) {
    return (
      <div style={{ minHeight: '100vh', padding: '120px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
        <div style={{ maxWidth: 480, margin: '0 auto', ...card, textAlign: 'center' }}>
          <div style={{ width: 80, height: 80, margin: '0 auto 1.25rem', borderRadius: '50%',
            background: 'linear-gradient(135deg,#27ae60,#16a34a)', display: 'flex', alignItems: 'center',
            justifyContent: 'center', boxShadow: '0 10px 26px rgba(39,174,96,0.35)' }}>
            <CheckCircle style={{ width: 42, height: 42, color: '#fff' }} />
          </div>
          <h1 style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
            {t('Thank you!', 'شكرًا لك!')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
            {t('Your feedback was sent. We really appreciate it.', 'تم إرسال رأيك. شكرًا جزيلًا لك.')}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', padding: '120px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 540, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '1.75rem' }}>
          <div style={{ width: 64, height: 64, margin: '0 auto 1rem', borderRadius: '1rem',
            background: 'linear-gradient(135deg, var(--primary), var(--accent))', display: 'flex',
            alignItems: 'center', justifyContent: 'center', boxShadow: '0 8px 22px rgba(200,134,10,0.3)' }}>
            <MessageSquareHeart style={{ width: 30, height: 30, color: '#fff' }} />
          </div>
          <h1 style={{ fontSize: '1.9rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
            {t('Share Your Feedback', 'شاركنا رأيك')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
            {t('Tell us what you think of Cairo Trip. It only takes a moment.', 'قل لنا رأيك في Cairo Trip. الأمر يستغرق لحظات.')}
          </p>
        </div>

        <form onSubmit={handleSubmit} style={card}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                {t('Name', 'الاسم')} <span style={{ color: '#e74c3c' }}>*</span>
              </label>
              <input type="text" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                className="input" placeholder={t('Your name', 'اسمك')} required />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                {t('Email (optional)', 'البريد الإلكتروني (اختياري)')}
              </label>
              <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                className="input" placeholder="you@example.com" />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
                {t('Rating (optional)', 'التقييم (اختياري)')}
              </label>
              <div style={{ display: 'flex', gap: '0.4rem' }}>
                {[1, 2, 3, 4, 5].map(n => (
                  <button type="button" key={n}
                    onClick={() => setRating(n)} onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, lineHeight: 0 }}
                    aria-label={`${n} star`}>
                    <Star style={{ width: 30, height: 30,
                      color: (hover || rating) >= n ? '#f4c842' : 'var(--border)',
                      fill: (hover || rating) >= n ? '#f4c842' : 'transparent', transition: 'all 0.12s' }} />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                {t('Your feedback', 'رأيك')} <span style={{ color: '#e74c3c' }}>*</span>
              </label>
              <textarea value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
                className="input" rows={5} style={{ resize: 'vertical', fontFamily: 'inherit' }}
                placeholder={t('What did you like? What can we improve?', 'إيه اللي عجبك؟ وإيه اللي نقدر نحسنه؟')} required />
            </div>

            {error && (
              <div style={{ padding: '0.75rem 1rem', borderRadius: '0.6rem', background: 'rgba(231,76,60,0.1)',
                border: '1px solid rgba(231,76,60,0.25)', color: '#c0392b', fontSize: '0.85rem' }}>
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary"
              style={{ width: '100%', padding: '0.95rem', justifyContent: 'center', opacity: loading ? 0.7 : 1 }}>
              {loading ? <Loader2 className="animate-spin" style={{ width: 16, height: 16 }} /> : <Send style={{ width: 16, height: 16 }} />}
              {loading ? t('Sending...', 'جاري الإرسال...') : t('Send Feedback', 'إرسال الرأي')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
