'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { Wallet, ArrowRightLeft, Plus, Trash2, Lightbulb, TrendingDown, PieChart, ArrowRight, CalendarDays } from 'lucide-react';

const rates: Record<string, number> = { USD: 1, EGP: 50, EUR: 0.92, GBP: 0.79, SAR: 3.75, AED: 3.67, JPY: 155 };
const currencies = Object.keys(rates);

interface Expense { name: string; amount: number; category: string; }

const tips = [
  { en: 'Street food meal: $2-5', ar: 'وجبة شارع: ٢-٥ دولار' },
  { en: 'Restaurant meal: $8-20', ar: 'وجبة مطعم: ٨-٢٠ دولار' },
  { en: 'Taxi ride (city): $3-10', ar: 'تاكسي (مدينة): ٣-١٠ دولار' },
  { en: 'Museum entry: $5-20', ar: 'دخول متحف: ٥-٢٠ دولار' },
  { en: 'Budget hotel: $20-50/night', ar: 'فندق اقتصادي: ٢٠-٥٠ دولار/ليلة' },
  { en: 'Mid-range hotel: $50-150/night', ar: 'فندق متوسط: ٥٠-١٥٠ دولار/ليلة' },
  { en: 'Uber/Careem airport: $10-25', ar: 'أوبر/كريم من المطار: ١٠-٢٥ دولار' },
  { en: 'Water bottle: $0.30', ar: 'زجاجة مياه: ٠.٣٠ دولار' },
];

const symbols: Record<string, string> = { USD: '$', EGP: 'E£', EUR: '€', GBP: '£', SAR: '﷼', AED: 'د.إ', JPY: '¥' };

export default function BudgetPage() {
  const { t } = useLang();
  const [displayCurr, setDisplayCurr] = useState('USD');
  const [budget, setBudget] = useState(500);
  const [fromCurr, setFromCurr] = useState('USD');
  const [toCurr, setToCurr] = useState('EGP');
  const [convertAmount, setConvertAmount] = useState(100);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [newExp, setNewExp] = useState({ name: '', amount: 0, category: 'food' });

  const totalSpent = expenses.reduce((s, e) => s + e.amount, 0);
  const remaining = budget - totalSpent;
  const sym = symbols[displayCurr] || displayCurr;
  const fmt = (n: number) => `${sym}${Math.round(n).toLocaleString()}`;

  const convert = (amount: number, from: string, to: string) => {
    const usd = from === 'USD' ? amount : amount / rates[from];
    return to === 'USD' ? usd : usd * rates[to];
  };

  const addExpense = () => {
    if (!newExp.name.trim() || newExp.amount <= 0) return;
    setExpenses(prev => [...prev, { ...newExp }]);
    setNewExp({ name: '', amount: 0, category: 'food' });
  };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1rem 3rem', background: 'var(--bg-main)' }}>
      <div style={{ textAlign: 'center', marginBottom: '2rem', maxWidth: 600, marginInline: 'auto' }}>
        <div style={{
          width: 56, height: 56, borderRadius: '1rem', margin: '0 auto 1rem',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'linear-gradient(135deg, var(--primary), var(--accent))',
        }}>
          <PieChart style={{ width: 28, height: 28, color: '#fff' }} />
        </div>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.25rem' }}>
          {t('Budget Planner', 'مخطط الميزانية')}
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
          {t('Track expenses and convert currencies', 'تتبع المصاريف وحول العملات')}
        </p>
      </div>

      <div className="budget-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem', maxWidth: 1000, marginInline: 'auto' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.5rem' }}>
            <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '1rem' }}>
              <Wallet style={{ width: 20, height: 20, color: 'var(--primary)' }} /> {t('Budget Tracker', 'تتبع الميزانية')}
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '0.6rem', marginBottom: '1rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  {t('Total Budget', 'إجمالي الميزانية')}
                </label>
                <input type="number" value={budget} onChange={e => setBudget(Number(e.target.value))} className="input" min={0} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  {t('Currency', 'العملة')}
                </label>
                <select value={displayCurr} onChange={e => setDisplayCurr(e.target.value)} className="input" style={{ fontWeight: 700 }}>
                  {currencies.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
              <div style={{ textAlign: 'center', padding: '0.75rem', borderRadius: '0.75rem', background: 'var(--bg-section)' }}>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: '0.2rem' }}>{t('Budget', 'الميزانية')}</div>
                <div style={{ fontSize: '1.15rem', fontWeight: 900, color: 'var(--primary)' }}>{fmt(budget)}</div>
              </div>
              <div style={{ textAlign: 'center', padding: '0.75rem', borderRadius: '0.75rem', background: 'var(--bg-section)' }}>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: '0.2rem' }}>{t('Spent', 'المصروف')}</div>
                <div style={{ fontSize: '1.15rem', fontWeight: 900, color: 'var(--danger)' }}>{fmt(totalSpent)}</div>
              </div>
              <div style={{ textAlign: 'center', padding: '0.75rem', borderRadius: '0.75rem', background: 'var(--bg-section)' }}>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: '0.2rem' }}>{t('Remaining', 'المتبقي')}</div>
                <div style={{ fontSize: '1.15rem', fontWeight: 900, color: remaining >= 0 ? 'var(--success)' : 'var(--danger)' }}>{fmt(remaining)}</div>
              </div>
            </div>

            <div style={{ height: 10, borderRadius: 999, background: 'var(--bg-section)', overflow: 'hidden' }}>
              <div style={{
                height: '100%', borderRadius: 999, transition: 'width 0.5s ease',
                width: `${budget > 0 ? Math.min((totalSpent / budget) * 100, 100) : 0}%`,
                background: remaining >= 0 ? 'var(--success)' : 'var(--danger)',
              }} />
            </div>

            <Link
              href={`/planner?budget=${displayCurr === 'EGP' ? budget : Math.round(budget * 50)}`}
              className="btn-primary"
              style={{
                marginTop: '1rem', width: '100%', padding: '0.85rem',
                justifyContent: 'center', textDecoration: 'none', fontSize: '0.9rem',
              }}
            >
              <CalendarDays style={{ width: 16, height: 16 }} />
              {t('Plan a Trip with This Budget', 'خطط رحلة بهذه الميزانية')}
              <ArrowRight style={{ width: 16, height: 16 }} />
            </Link>
          </div>

          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.5rem' }}>
            <h3 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.75rem', fontSize: '0.95rem' }}>
              {t('Add Expense', 'أضف مصروف')}
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.6rem', marginBottom: '0.75rem' }}>
              <input type="text" value={newExp.name} onChange={e => setNewExp(prev => ({ ...prev, name: e.target.value }))} className="input" placeholder={t('Name', 'الاسم')} />
              <input type="number" value={newExp.amount || ''} onChange={e => setNewExp(prev => ({ ...prev, amount: Number(e.target.value) }))} className="input" placeholder={`${sym} ${displayCurr}`} min={0} />
              <select value={newExp.category} onChange={e => setNewExp(prev => ({ ...prev, category: e.target.value }))} className="input">
                <option value="food">{t('Food', 'طعام')}</option>
                <option value="transport">{t('Transport', 'مواصلات')}</option>
                <option value="hotel">{t('Hotel', 'فندق')}</option>
                <option value="activity">{t('Activity', 'نشاط')}</option>
                <option value="shopping">{t('Shopping', 'تسوق')}</option>
                <option value="other">{t('Other', 'أخرى')}</option>
              </select>
            </div>
            <button onClick={addExpense} className="btn-primary" style={{ width: '100%', padding: '0.7rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.3rem', fontSize: '0.9rem' }}>
              <Plus style={{ width: 16, height: 16 }} /> {t('Add', 'أضف')}
            </button>
          </div>

          {expenses.length > 0 && (
            <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.5rem' }}>
              <h3 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.75rem', fontSize: '0.95rem' }}>
                {t('Expenses', 'المصروفات')}
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {expenses.map((exp, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '0.75rem', borderRadius: '0.75rem', background: 'var(--bg-section)', border: '1px solid var(--border)',
                  }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '0.85rem', color: 'var(--text-dark)' }}>{exp.name}</div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>{exp.category}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span style={{ fontWeight: 800, color: 'var(--primary)', fontSize: '0.9rem' }}>{fmt(exp.amount)}</span>
                      <button
                        onClick={() => setExpenses(prev => prev.filter((_, j) => j !== i))}
                        style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '0.25rem' }}
                      >
                        <Trash2 style={{ width: 15, height: 15 }} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.5rem' }}>
            <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '1rem' }}>
              <ArrowRightLeft style={{ width: 20, height: 20, color: 'var(--primary)' }} /> {t('Currency Converter', 'محول العملات')}
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '0.35rem' }}>{t('Amount', 'المبلغ')}</label>
                <input type="number" value={convertAmount} onChange={e => setConvertAmount(Number(e.target.value))} className="input" style={{ fontSize: '1.1rem', fontWeight: 700 }} min={0} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.6rem' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '0.35rem' }}>{t('From', 'من')}</label>
                  <select value={fromCurr} onChange={e => setFromCurr(e.target.value)} className="input" style={{ fontWeight: 700 }}>
                    {currencies.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '0.35rem' }}>{t('To', 'إلى')}</label>
                  <select value={toCurr} onChange={e => setToCurr(e.target.value)} className="input" style={{ fontWeight: 700 }}>
                    {currencies.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div style={{
                padding: '1.25rem', borderRadius: '0.75rem', textAlign: 'center',
                background: 'linear-gradient(135deg, var(--primary), var(--accent))',
              }}>
                <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.85rem' }}>{convertAmount} {fromCurr} =</div>
                <div style={{ fontSize: '1.8rem', fontWeight: 900, color: '#fff' }}>{convert(convertAmount, fromCurr, toCurr).toFixed(2)} {toCurr}</div>
              </div>
            </div>
          </div>

          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.5rem' }}>
            <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '1rem' }}>
              <Lightbulb style={{ width: 20, height: 20, color: 'var(--warning)' }} /> {t('Daily Cost Guide', 'دليل التكلفة اليومية')}
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
              {tips.map((tip, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: '0.5rem',
                  padding: '0.6rem 0.75rem', borderRadius: '0.6rem', background: 'var(--bg-section)',
                  fontSize: '0.82rem',
                }}>
                  <TrendingDown style={{ width: 14, height: 14, color: 'var(--primary)', flexShrink: 0 }} />
                  <span style={{ color: 'var(--text-body)' }}>{t(tip.en, tip.ar)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
