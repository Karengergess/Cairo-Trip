'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { useLang } from '@/contexts/LanguageContext';
import { useUI } from '@/contexts/UIContext';
import { supabase } from '@/lib/supabase';
import { toEGP, EGP_RATE } from '@/lib/egp';
import Link from 'next/link';
import { CalendarDays, Plus, Trash2, Share2, MapPin, Wallet, Hotel, Compass, Bus, UtensilsCrossed, Package, ChevronDown, Sparkles, RefreshCw, BookOpen } from 'lucide-react';

interface TripItem { name: string; cost: number; type: 'hotel' | 'attraction' | 'restaurant' | 'transport' | 'food' | 'custom'; ref_id?: string; }
interface TripDay { label: string; items: TripItem[]; }
interface HotelRow { id: string; name: string; name_ar?: string; price_per_night_usd: number; city?: { name: string; name_ar: string }; }
interface AttrRow { id: string; name: string; name_ar?: string; entry_fee_usd: number; city?: { name: string; name_ar: string }; }
interface RestRow { id: string; name: string; name_ar?: string; avg_meal_usd: number; city?: { name: string; name_ar: string }; }

const typeIcons: Record<string, React.ElementType> = { hotel: Hotel, attraction: Compass, restaurant: UtensilsCrossed, transport: Bus, food: UtensilsCrossed, custom: Package };
const typeColors: Record<string, string> = { hotel: '#c8860a', attraction: '#27ae60', restaurant: '#e67e22', transport: '#3498db', food: '#e8933e', custom: '#9b59b6' };

const TRIP_LS_KEY = 'etp_trip_v2';

function loadSavedTrip(): { budget: number; currency: 'EGP' | 'USD'; days: TripDay[] } | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(TRIP_LS_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

function PlannerContent() {
  const { t, lang } = useLang();
  const { confirm, toast } = useUI();
  const searchParams = useSearchParams();
  const budgetParam = searchParams.get('budget');
  const isAr = lang === 'ar';

  const saved = typeof window !== 'undefined' ? loadSavedTrip() : null;

  const [budget, setBudget] = useState(
    budgetParam ? Number(budgetParam) : (saved?.budget ?? 0)
  );
  const [budgetCurrency, setBudgetCurrency] = useState<'EGP' | 'USD'>(
    budgetParam ? 'EGP' : (saved?.currency ?? 'USD')
  );
  const budgetUSD = budgetCurrency === 'EGP' ? Math.round(budget / EGP_RATE) : budget;

  const [days, setDays] = useState<TripDay[]>(
    saved?.days && saved.days.length > 0 ? saved.days : [{ label: `${t('Day', 'اليوم')} 1`, items: [] }]
  );
  const [hotels, setHotels] = useState<HotelRow[]>([]);
  const [attractions, setAttractions] = useState<AttrRow[]>([]);
  const [restaurants, setRestaurants] = useState<RestRow[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [autoPlanned, setAutoPlanned] = useState(false);

  const [newItem, setNewItem] = useState({ dayIdx: 0, name: '', cost: 0, type: 'attraction' as TripItem['type'] });

  const totalUSD = days.reduce((s, d) => s + d.items.reduce((ss, it) => ss + it.cost, 0), 0);
  const remaining = budgetUSD - totalUSD;
  const budgetPct = budgetUSD > 0 ? Math.min((totalUSD / budgetUSD) * 100, 100) : 0;
  const sym = budgetCurrency === 'EGP' ? 'E£' : '$';
  const fmtCost = (usd: number) => budgetCurrency === 'EGP' ? `E£${Math.round(usd * EGP_RATE)}` : `$${usd}`;

  useEffect(() => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(TRIP_LS_KEY, JSON.stringify({ budget, currency: budgetCurrency, days }));
  }, [budget, budgetCurrency, days]);

  useEffect(() => {
    async function load() {
      const [h, a, r] = await Promise.all([
        supabase.from('hotels').select('id, name, name_ar, price_per_night_usd, city:cities(name, name_ar)').order('price_per_night_usd', { ascending: true }).limit(40),
        supabase.from('attractions').select('id, name, name_ar, entry_fee_usd, city:cities(name, name_ar)').order('entry_fee_usd', { ascending: true }).limit(40),
        supabase.from('restaurants').select('id, name, name_ar, avg_meal_usd, city:cities(name, name_ar)').order('avg_meal_usd', { ascending: true }).limit(40),
      ]);
      if (h.data) setHotels(h.data as unknown as HotelRow[]);
      if (a.data) setAttractions(a.data as unknown as AttrRow[]);
      if (r.data) setRestaurants(r.data as unknown as RestRow[]);
    }
    load();
  }, []);

  function buildAutoPlan(numDays = 3): TripDay[] {
    if (budgetUSD < 30 || hotels.length === 0 || attractions.length === 0) return [];

    const sortedHotels = [...hotels].sort((a, b) => a.price_per_night_usd - b.price_per_night_usd);
    const sortedAttrs = [...attractions].sort((a, b) => a.entry_fee_usd - b.entry_fee_usd);
    const sortedRests = [...restaurants].sort((a, b) => a.avg_meal_usd - b.avg_meal_usd);

    // 1. Hotel: pick the most expensive that fits within 50% of budget / numDays.
    //    If none fits, fall back to the cheapest and accept it only if it stays under 70% of budget.
    const hotelMax = (budgetUSD * 0.5) / numDays;
    const affordable = sortedHotels.filter(h => h.price_per_night_usd <= hotelMax);
    const hotel = affordable.length > 0 ? affordable[affordable.length - 1] : sortedHotels[0];
    const hotelCost = hotel.price_per_night_usd * numDays;
    if (hotelCost > budgetUSD * 0.7) return [];
    let spent = hotelCost;

    // 2. Transport: small per-day allowance, capped between $5 and $15.
    const transportPerDay = Math.max(5, Math.min(15, ((budgetUSD - spent) * 0.15) / numDays));
    const transportTotal = transportPerDay * numDays;
    spent += transportTotal;

    // 3. Restaurants: one unique pick per day, prefer middle-priced.
    const restTargetPerDay = ((budgetUSD - spent) * 0.5) / Math.max(1, numDays);
    const seenRestIds = new Set<string>();
    const dayRests: (RestRow | null)[] = [];
    for (let d = 0; d < numDays; d++) {
      const available = sortedRests.filter(r => !seenRestIds.has(r.id) && r.avg_meal_usd <= restTargetPerDay * 1.5);
      const pick = available.length > 0
        ? available[Math.floor(available.length / 2)]
        : sortedRests.find(r => !seenRestIds.has(r.id)) || null;

      if (pick && spent + pick.avg_meal_usd <= budgetUSD) {
        seenRestIds.add(pick.id);
        dayRests.push(pick);
        spent += pick.avg_meal_usd;
      } else {
        dayRests.push(null);
      }
    }

    // 4. Attractions: unique, fits remaining budget, up to 2 per day.
    const seenAttrIds = new Set<string>();
    const picked: AttrRow[] = [];
    for (const a of sortedAttrs) {
      if (seenAttrIds.has(a.id)) continue;
      if (picked.length >= numDays * 2) break;
      if (spent + a.entry_fee_usd <= budgetUSD) {
        picked.push(a);
        seenAttrIds.add(a.id);
        spent += a.entry_fee_usd;
      }
    }

    // 5. Assemble days
    const newDays: TripDay[] = Array.from({ length: numDays }, (_, i) => ({
      label: `${t('Day', 'اليوم')} ${i + 1}`,
      items: [],
    }));

    newDays[0].items.push({
      name: `${hotel.name} (${numDays} ${t('nights', 'ليالٍ')})`,
      cost: hotelCost,
      type: 'hotel',
      ref_id: hotel.id,
    });

    picked.forEach((a, i) => {
      newDays[i % numDays].items.push({
        name: isAr ? (a.name_ar || a.name) : a.name,
        cost: a.entry_fee_usd,
        type: 'attraction',
        ref_id: a.id,
      });
    });

    dayRests.forEach((rest, i) => {
      if (rest) {
        newDays[i].items.push({
          name: isAr ? (rest.name_ar || rest.name) : rest.name,
          cost: rest.avg_meal_usd,
          type: 'restaurant',
        });
      }
    });

    newDays.forEach(d => {
      d.items.push({
        name: t('Local transport', 'مواصلات محلية'),
        cost: Math.round(transportPerDay),
        type: 'transport',
      });
    });

    return newDays;
  }

  useEffect(() => {
    if (!budgetParam || autoPlanned) return;
    if (hotels.length === 0 || attractions.length === 0) return;
    const hasItems = days.some(d => d.items.length > 0);
    if (hasItems) { setAutoPlanned(true); return; }
    const plan = buildAutoPlan(3);
    if (plan.length > 0) {
      setDays(plan);
      setAutoPlanned(true);
    }
  }, [hotels, attractions, budgetParam]);

  const regeneratePlan = () => {
    const plan = buildAutoPlan(days.length || 3);
    if (plan.length > 0) setDays(plan);
  };

  const addDay = () => setDays(prev => [...prev, { label: `${t('Day', 'اليوم')} ${prev.length + 1}`, items: [] }]);

  const addItem = () => {
    if (!newItem.name.trim()) return;
    const costUSD = budgetCurrency === 'EGP' ? Math.round(newItem.cost / EGP_RATE) : newItem.cost;
    setDays(prev => prev.map((d, i) => i === newItem.dayIdx ? { ...d, items: [...d.items, { name: newItem.name, cost: costUSD, type: newItem.type }] } : d));
    setNewItem(prev => ({ ...prev, name: '', cost: 0 }));
  };

  const addSuggestion = (name: string, cost: number, type: TripItem['type'], dayIdx: number) => {
    setDays(prev => prev.map((d, i) => i === dayIdx ? { ...d, items: [...d.items, { name, cost, type }] } : d));
  };

  const removeItem = (dayIdx: number, itemIdx: number) => {
    setDays(prev => prev.map((d, i) => i === dayIdx ? { ...d, items: d.items.filter((_, j) => j !== itemIdx) } : d));
  };

  const removeDay = (dayIdx: number) => {
    if (days.length <= 1) return;
    setDays(prev => prev.filter((_, i) => i !== dayIdx).map((d, i) => ({ ...d, label: `${t('Day', 'اليوم')} ${i + 1}` })));
  };

  const clearAll = async () => {
    const ok = await confirm({
      title: t('Clear the entire trip?', 'مسح الرحلة بالكامل؟'),
      message: t('All your days and activities will be removed. This cannot be undone.', 'هتفقد كل الأيام والأنشطة. الإجراء ده لا يمكن التراجع عنه.'),
      confirmText: t('Yes, clear it', 'نعم، امسح'),
      cancelText: t('Cancel', 'إلغاء'),
      danger: true,
    });
    if (!ok) return;
    setDays([{ label: `${t('Day', 'اليوم')} 1`, items: [] }]);
    toast({ message: t('Trip cleared', 'تم مسح الرحلة'), type: 'success' });
  };

  const share = async () => {
    const text = days.map(d => `${d.label}\n${d.items.map(it => `  - ${it.name}: ${fmtCost(it.cost)}`).join('\n')}`).join('\n\n') + `\n\n${t('Total', 'الإجمالي')}: ${fmtCost(totalUSD)}`;
    if (typeof navigator !== 'undefined' && navigator.share) {
      try { await navigator.share({ title: t('My Cairo Trip', 'رحلتي في القاهرة'), text }); } catch { /* user cancelled */ }
    } else if (typeof navigator !== 'undefined') {
      await navigator.clipboard.writeText(text);
      toast({ message: t('Trip copied to clipboard!', 'تم نسخ الرحلة!'), type: 'success' });
    }
  };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 860, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            <CalendarDays style={{ width: 26, height: 26, display: 'inline', color: 'var(--primary)', marginInlineEnd: '0.4rem', verticalAlign: '-4px' }} />
            {t('Trip Planner', 'مخطط الرحلة')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
            {t('Build your day-by-day itinerary and track your budget', 'أنشئ برنامجك يوم بيوم وتتبع ميزانيتك')}
          </p>
        </div>

        <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.25rem', marginBottom: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.85rem', flexWrap: 'wrap' }}>
            <Wallet style={{ width: 18, height: 18, color: 'var(--primary)' }} />
            <span style={{ fontWeight: 700, color: 'var(--text-dark)', fontSize: '0.95rem' }}>{t('Trip Budget', 'ميزانية الرحلة')}</span>
            <div style={{ display: 'flex', gap: '0.4rem', marginInlineStart: 'auto' }}>
              {(['EGP', 'USD'] as const).map(c => (
                <button key={c} onClick={() => setBudgetCurrency(c)} style={{
                  padding: '0.3rem 0.85rem', borderRadius: '20px', fontSize: '0.78rem', fontWeight: 700,
                  border: budgetCurrency === c ? '2px solid var(--primary)' : '2px solid var(--border)',
                  background: budgetCurrency === c ? 'var(--primary)' : 'transparent',
                  color: budgetCurrency === c ? '#fff' : 'var(--text-muted)', cursor: 'pointer',
                }}>{c}</button>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: '0.6rem', alignItems: 'center', marginBottom: '0.75rem' }}>
            <input type="number" value={budget || ''} onChange={e => setBudget(Number(e.target.value))} min={0} className="input"
              placeholder={budgetCurrency === 'EGP' ? '3000' : '60'}
              style={{ flex: 1, fontSize: '1.1rem', fontWeight: 700 }} />
            <span style={{ fontWeight: 700, color: 'var(--text-muted)', fontSize: '0.9rem' }}>{budgetCurrency}</span>
          </div>

          {budgetUSD > 0 && (
            <>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.4rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                <span style={{ color: 'var(--text-muted)' }}>
                  {t('Spent', 'المصروف')}: <b style={{ color: 'var(--primary)' }}>{fmtCost(totalUSD)}</b>
                </span>
                <span style={{ color: remaining >= 0 ? 'var(--success)' : 'var(--danger)', fontWeight: 700 }}>
                  {t('Remaining', 'المتبقي')}: {fmtCost(Math.abs(remaining))} {remaining < 0 && t('(over)', '(زيادة)')}
                </span>
              </div>
              <div style={{ height: 8, borderRadius: 4, background: 'var(--bg-section)', overflow: 'hidden' }}>
                <div style={{ height: '100%', borderRadius: 4, width: `${budgetPct}%`, background: remaining >= 0 ? 'var(--success)' : 'var(--danger)', transition: 'width 0.5s ease' }} />
              </div>
            </>
          )}

          {budgetParam && hotels.length > 0 && (
            <button onClick={regeneratePlan} style={{
              marginTop: '0.85rem', width: '100%', padding: '0.7rem',
              borderRadius: '0.75rem', border: '1px dashed var(--primary)',
              background: 'transparent', color: 'var(--primary)',
              fontWeight: 700, fontSize: '0.85rem', cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
              fontFamily: 'inherit',
            }}>
              <RefreshCw style={{ width: 14, height: 14 }} />
              {t('Regenerate auto-plan', 'إعادة توليد خطة تلقائية')}
            </button>
          )}
        </div>

        <div style={{ marginBottom: '1rem' }}>
          <button onClick={() => setShowSuggestions(!showSuggestions)} style={{
            display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.7rem 1rem',
            borderRadius: '0.85rem', border: '1px solid var(--border)', background: 'var(--bg-card)',
            fontWeight: 700, fontSize: '0.9rem', color: 'var(--primary)', cursor: 'pointer',
            width: '100%', justifyContent: 'center', fontFamily: 'inherit',
          }}>
            <Sparkles style={{ width: 16, height: 16 }} />
            {t('Browse hotels & attractions', 'تصفح فنادق ومعالم')}
            <ChevronDown style={{ width: 16, height: 16, transform: showSuggestions ? 'rotate(180deg)' : 'none', transition: 'transform 0.3s' }} />
          </button>

          {showSuggestions && (
            <div style={{ marginTop: '0.6rem', maxHeight: 320, overflowY: 'auto', borderRadius: '0.85rem', border: '1px solid var(--border)', background: 'var(--bg-card)' }}>
              {[...hotels.map(h => ({
                key: `h_${h.id}`,
                name: isAr ? (h.name_ar || h.name) : h.name,
                cost: h.price_per_night_usd,
                type: 'hotel' as const,
                city: isAr ? (h.city?.name_ar || h.city?.name || '') : (h.city?.name || ''),
                suffix: ` / ${t('night', 'ليلة')}`,
              })), ...attractions.map(a => ({
                key: `a_${a.id}`,
                name: isAr ? (a.name_ar || a.name) : a.name,
                cost: a.entry_fee_usd,
                type: 'attraction' as const,
                city: isAr ? (a.city?.name_ar || a.city?.name || '') : (a.city?.name || ''),
                suffix: '',
              })), ...restaurants.map(r => ({
                key: `r_${r.id}`,
                name: isAr ? (r.name_ar || r.name) : r.name,
                cost: r.avg_meal_usd,
                type: 'restaurant' as const,
                city: isAr ? (r.city?.name_ar || r.city?.name || '') : (r.city?.name || ''),
                suffix: ` / ${t('meal', 'وجبة')}`,
              }))].map((s) => {
                const Icon = typeIcons[s.type];
                return (
                  <div key={s.key} style={{
                    display: 'flex', alignItems: 'center', gap: '0.6rem',
                    padding: '0.7rem 0.85rem', borderBottom: '1px solid var(--border-light)',
                    flexWrap: 'wrap',
                  }}>
                    <Icon style={{ width: 16, height: 16, color: typeColors[s.type], flexShrink: 0 }} />
                    <div style={{ flex: 1, minWidth: 140 }}>
                      <div style={{ fontWeight: 700, fontSize: '0.85rem', color: 'var(--text-dark)' }}>{s.name}</div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                        <MapPin style={{ width: 11, height: 11, display: 'inline', verticalAlign: '-1px' }} /> {s.city}
                      </div>
                    </div>
                    <span style={{ fontWeight: 800, color: 'var(--primary)', fontSize: '0.85rem', whiteSpace: 'nowrap' }}>
                      {s.cost > 0 ? fmtCost(s.cost) : t('Free', 'مجاني')}{s.suffix}
                    </span>
                    <select onChange={e => { if (e.target.value !== '') { addSuggestion(s.name, s.cost, s.type, Number(e.target.value)); e.target.value = ''; } }}
                      defaultValue="" style={{
                        padding: '0.35rem 0.5rem', borderRadius: '0.5rem',
                        border: '1px solid var(--primary)', color: 'var(--primary)',
                        fontWeight: 700, fontSize: '0.78rem', background: 'transparent',
                        fontFamily: 'inherit', cursor: 'pointer',
                      }}>
                      <option value="">{t('+ Add to...', '+ أضف لـ...')}</option>
                      {days.map((d, di) => <option key={di} value={di}>{d.label}</option>)}
                    </select>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <details style={{ marginBottom: '1rem', borderRadius: '0.85rem', border: '1px solid var(--border)', background: 'var(--bg-card)' }}>
          <summary style={{ padding: '0.75rem 1rem', cursor: 'pointer', fontWeight: 700, fontSize: '0.9rem', color: 'var(--text-dark)' }}>
            {t('Add custom activity', 'إضافة نشاط يدوي')}
          </summary>
          <div style={{ padding: '0 1rem 1rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <select value={newItem.dayIdx} onChange={e => setNewItem(prev => ({ ...prev, dayIdx: Number(e.target.value) }))} className="input">
                {days.map((d, i) => <option key={i} value={i}>{d.label}</option>)}
              </select>
              <select value={newItem.type} onChange={e => setNewItem(prev => ({ ...prev, type: e.target.value as TripItem['type'] }))} className="input">
                <option value="hotel">{t('Hotel', 'فندق')}</option>
                <option value="attraction">{t('Attraction', 'معلم')}</option>
                <option value="restaurant">{t('Restaurant', 'مطعم')}</option>
                <option value="transport">{t('Transport', 'مواصلات')}</option>
                <option value="food">{t('Food', 'طعام')}</option>
                <option value="custom">{t('Custom', 'مخصص')}</option>
              </select>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr auto', gap: '0.5rem' }}>
              <input type="text" value={newItem.name} onChange={e => setNewItem(prev => ({ ...prev, name: e.target.value }))} className="input" placeholder={t('Activity name', 'اسم النشاط')} />
              <input type="number" value={newItem.cost || ''} onChange={e => setNewItem(prev => ({ ...prev, cost: Number(e.target.value) }))} className="input" placeholder={`${sym} ${budgetCurrency}`} min={0} />
              <button onClick={addItem} className="btn-primary" style={{ whiteSpace: 'nowrap', padding: '0 1rem' }}>
                <Plus style={{ width: 14, height: 14 }} /> {t('Add', 'أضف')}
              </button>
            </div>
          </div>
        </details>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
          {days.map((day, dayIdx) => {
            const dayTotal = day.items.reduce((s, it) => s + it.cost, 0);
            return (
              <div key={dayIdx} className="card" style={{ padding: 0, overflow: 'hidden', animation: 'none' }}>
                <div style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '0.85rem 1.15rem',
                  background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                  color: '#fff',
                }}>
                  <h3 style={{ fontWeight: 800, fontSize: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#fff' }}>
                    <CalendarDays style={{ width: 18, height: 18 }} /> {day.label}
                    <span style={{ fontSize: '0.78rem', fontWeight: 600, opacity: 0.85 }}>
                      ({day.items.length} {t('activities', 'نشاط')})
                    </span>
                  </h3>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                    <span style={{ fontWeight: 800, fontSize: '0.9rem' }}>{fmtCost(dayTotal)}</span>
                    {days.length > 1 && (
                      <button onClick={() => removeDay(dayIdx)}
                        style={{ background: 'rgba(255,255,255,0.2)', border: 'none', cursor: 'pointer', color: '#fff', borderRadius: '0.4rem', padding: '0.3rem' }}
                        title={t('Remove day', 'حذف اليوم')}>
                        <Trash2 style={{ width: 14, height: 14 }} />
                      </button>
                    )}
                  </div>
                </div>
                <div style={{ padding: '0.6rem 1rem 1rem' }}>
                  {day.items.length === 0 ? (
                    <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem', padding: '1.2rem 0' }}>
                      {t('No activities yet', 'لا توجد أنشطة')}
                    </p>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                      {day.items.map((item, itemIdx) => {
                        const Icon = typeIcons[item.type];
                        return (
                          <div key={itemIdx} style={{
                            display: 'flex', alignItems: 'center', gap: '0.6rem',
                            padding: '0.55rem 0.7rem', borderRadius: '0.6rem',
                            background: 'var(--bg-section)', border: '1px solid var(--border-light)',
                          }}>
                            <div style={{ width: 4, height: 30, borderRadius: 2, background: typeColors[item.type], flexShrink: 0 }} />
                            <Icon style={{ width: 16, height: 16, color: typeColors[item.type], flexShrink: 0 }} />
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontWeight: 700, fontSize: '0.85rem', color: 'var(--text-dark)' }}>{item.name}</div>
                              <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>
                                {t(item.type, item.type === 'hotel' ? 'فندق' : item.type === 'attraction' ? 'معلم' : item.type === 'restaurant' ? 'مطعم' : item.type === 'transport' ? 'مواصلات' : item.type === 'food' ? 'طعام' : 'مخصص')}
                              </div>
                            </div>
                            <span style={{ fontWeight: 800, color: 'var(--primary)', fontSize: '0.85rem', whiteSpace: 'nowrap' }}>
                              {item.cost > 0 ? fmtCost(item.cost) : t('Free', 'مجاني')}
                            </span>
                            {item.type === 'hotel' && item.ref_id && (
                              <Link href={`/book?hotel=${item.ref_id}`} style={{
                                padding: '0.35rem 0.7rem', borderRadius: '0.5rem',
                                background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                                color: '#fff', fontSize: '0.72rem', fontWeight: 800,
                                textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.25rem',
                                whiteSpace: 'nowrap',
                              }}>
                                <BookOpen style={{ width: 12, height: 12 }} /> {t('Book', 'احجز')}
                              </Link>
                            )}
                            <button onClick={() => removeItem(dayIdx, itemIdx)}
                              style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '0.2rem' }}>
                              <Trash2 style={{ width: 14, height: 14 }} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ display: 'flex', gap: '0.6rem', justifyContent: 'center', marginTop: '1.5rem', flexWrap: 'wrap' }}>
          <button onClick={addDay} className="btn-primary" style={{ padding: '0.7rem 1.25rem' }}>
            <Plus style={{ width: 16, height: 16 }} /> {t('Add Day', 'أضف يوم')}
          </button>
          <button onClick={share} style={{
            padding: '0.7rem 1.25rem', borderRadius: '0.75rem',
            border: '1px solid var(--primary)', background: 'transparent',
            color: 'var(--primary)', fontWeight: 700, fontSize: '0.9rem',
            cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            fontFamily: 'inherit',
          }}>
            <Share2 style={{ width: 16, height: 16 }} /> {t('Share Trip', 'شارك الرحلة')}
          </button>
          <button onClick={clearAll} style={{
            padding: '0.7rem 1.25rem', borderRadius: '0.75rem',
            border: '1px solid var(--danger)', background: 'transparent',
            color: 'var(--danger)', fontWeight: 700, fontSize: '0.9rem',
            cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            fontFamily: 'inherit',
          }}>
            <Trash2 style={{ width: 16, height: 16 }} /> {t('Clear', 'مسح')}
          </button>
        </div>

        {totalUSD > 0 && (
          <div style={{ marginTop: '1.5rem', borderRadius: '1rem', padding: '1.25rem 1.5rem', background: 'linear-gradient(135deg, var(--primary), var(--accent))', color: '#fff', textAlign: 'center' }}>
            <div style={{ fontSize: '0.85rem', opacity: 0.85 }}>{t('Trip Total', 'إجمالي الرحلة')}</div>
            <div style={{ fontSize: '2.2rem', fontWeight: 900, lineHeight: 1.1 }}>{fmtCost(totalUSD)}</div>
            <div style={{ fontSize: '0.85rem', opacity: 0.85, marginTop: '0.25rem' }}>
              {budgetCurrency === 'USD' ? `${toEGP(totalUSD)} EGP` : `$${totalUSD} USD`}
            </div>
            <div style={{ fontSize: '0.78rem', opacity: 0.7, marginTop: '0.4rem' }}>
              {days.length} {t('days', 'أيام')} · {days.reduce((s, d) => s + d.items.length, 0)} {t('activities', 'نشاط')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function PlannerPage() {
  return <Suspense fallback={<div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>Loading...</div>}><PlannerContent /></Suspense>;
}
