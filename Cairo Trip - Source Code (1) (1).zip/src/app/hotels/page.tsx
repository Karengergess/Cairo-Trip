'use client';

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useLang } from '@/contexts/LanguageContext';
import { Star, MapPin, Hotel, Loader2, Navigation } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Hotel as HotelType, City } from '@/types/database';
import { toEGP } from '@/lib/egp';
import FavoriteButton from '@/components/FavoriteButton';
import SmartImage from '@/components/SmartImage';
import { mapsSearchUrl, mapsDirectionsUrl } from '@/lib/maps';

function HotelsContent() {
  const { t, lang } = useLang();
  const searchParams = useSearchParams();
  const [hotels, setHotels] = useState<HotelType[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  const [cityFilter, setCityFilter] = useState(searchParams.get('city') || '');
  const [starFilter, setStarFilter] = useState(0);
  const [maxPrice, setMaxPrice] = useState(1000);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const LIMIT = 12;

  const fetchHotels = async (reset = false) => {
    setLoading(true);
    const offset = reset ? 0 : page * LIMIT;
    let query = supabase.from('hotels').select('*, city:cities(*)', { count: 'exact' })
      .lte('price_per_night_usd', maxPrice)
      .order('price_per_night_usd', { ascending: true })
      .range(offset, offset + LIMIT - 1);

    if (cityFilter) {
      const cityRow = cities.find(c => c.slug === cityFilter);
      if (cityRow) query = query.eq('city_id', cityRow.id);
    }
    if (starFilter > 0) query = query.eq('star_rating', starFilter);

    const { data, count } = await query;
    if (data) {
      if (reset) {
        setHotels(data as unknown as HotelType[]);
        setPage(1);
      } else {
        setHotels(prev => [...prev, ...(data as unknown as HotelType[])]);
        setPage(prev => prev + 1);
      }
      setHasMore((count || 0) > (reset ? LIMIT : (page + 1) * LIMIT));
    }
    setLoading(false);
  };

  useEffect(() => {
    supabase.from('cities').select('*').then(({ data }) => { if (data) setCities(data); });
  }, []);

  useEffect(() => {
    if (cities.length > 0) fetchHotels(true);
  }, [cityFilter, starFilter, maxPrice, cities]);

  return (
    <div style={{ minHeight: '100vh', padding: '100px 2rem 4rem' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div className="text-center" style={{ marginBottom: '2.5rem' }}>
          <h1 style={{ fontSize: '2.2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
            <Hotel className="w-7 h-7 inline" style={{ color: 'var(--primary)', marginInlineEnd: '0.5rem' }} />
            {t('Hotels in Cairo', 'فنادق في القاهرة')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '1rem' }}>{t('Find the perfect place to stay', 'اعثر على المكان المثالي للإقامة')}</p>
        </div>

        <div className="budget-form-card" style={{ maxWidth: '100%', marginBottom: '2rem', padding: '1.5rem' }}>
          <div className="filter-row" style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'end' }}>
            <div style={{ flex: 1, minWidth: 180 }}>
              <label className="form-label">{t('City', 'المدينة')}</label>
              <select value={cityFilter} onChange={(e) => setCityFilter(e.target.value)} className="input">
                <option value="">{t('All Cities', 'كل المدن')}</option>
                {cities.map(c => <option key={c.id} value={c.slug}>{lang === 'ar' ? c.name_ar : c.name}</option>)}
              </select>
            </div>
            <div style={{ minWidth: 150 }}>
              <label className="form-label">{t('Stars', 'النجوم')}</label>
              <select value={starFilter} onChange={(e) => setStarFilter(Number(e.target.value))} className="input">
                <option value={0}>{t('Any', 'الكل')}</option>
                {[5,4,3,2,1].map(s => <option key={s} value={s}>{s} {t('Stars', 'نجوم')}</option>)}
              </select>
            </div>
            <div style={{ minWidth: 180 }}>
              <label className="form-label">{t('Max Price', 'أقصى سعر')}: ${maxPrice}</label>
              <input type="range" min={10} max={1000} value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))} style={{ width: '100%', accentColor: '#c8860a' }} />
            </div>
          </div>
        </div>

        <div className="locations-grid">
          {hotels.map((hotel, i) => (
            <Link
              key={hotel.id}
              href={`/hotels/${hotel.id}`}
              className="card"
              style={{ animationDelay: `${i * 0.1}s`, display: 'block', textDecoration: 'none', color: 'inherit' }}
            >
              <div style={{ height: 160, overflow: 'hidden', position: 'relative' }}>
                <SmartImage src={hotel.image_urls?.[0]} alt={hotel.name} fallbackName={hotel.name} />
                <FavoriteButton type="hotel" id={hotel.id} />
              </div>
              <div style={{ padding: '1.25rem 1.5rem 0.5rem', position: 'relative' }}>
                <span className="card-number">{i + 1}</span>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                  {lang === 'ar' ? (hotel as unknown as {name_ar: string}).name_ar || hotel.name : hotel.name}
                </h3>
                <span style={{
                  display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                  color: 'var(--text-muted)', fontSize: '0.82rem',
                  background: 'var(--bg-section)', padding: '0.25rem 0.65rem', borderRadius: '8px',
                }}>
                  <MapPin className="w-3 h-3" /> {lang === 'ar' ? (hotel.city as unknown as City)?.name_ar : (hotel.city as unknown as City)?.name || ''}
                </span>
              </div>
              <div style={{ padding: '0.75rem 1.5rem 1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                  {Array.from({ length: hotel.star_rating }).map((_, s) => (
                    <Star key={s} className="w-4 h-4" style={{ color: 'var(--primary)', fill: 'var(--primary)' }} />
                  ))}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary)' }}>${hotel.price_per_night_usd}</span>
                  <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>/ {t('night', 'ليلة')}</span>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', background: 'var(--bg-section)', padding: '0.15rem 0.5rem', borderRadius: '6px' }}>{toEGP(hotel.price_per_night_usd)} EGP</span>
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.85rem' }}>
                  {(() => {
                    const cityName = (hotel.city as unknown as City)?.name;
                    const stop = (e: React.MouseEvent) => e.stopPropagation();
                    return (
                      <>
                        <a
                          href={mapsSearchUrl(hotel.name, cityName)}
                          target="_blank" rel="noopener noreferrer" onClick={stop}
                          style={{
                            flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                            padding: '0.55rem 0.75rem', borderRadius: '0.6rem',
                            background: 'var(--bg-section)', border: '1px solid var(--border)',
                            color: 'var(--text-dark)', fontSize: '0.8rem', fontWeight: 700,
                            textDecoration: 'none', transition: 'all 0.2s',
                          }}
                        >
                          <MapPin style={{ width: 14, height: 14, color: 'var(--primary)' }} /> {t('Map', 'خريطة')}
                        </a>
                        <a
                          href={mapsDirectionsUrl(hotel.name, cityName)}
                          target="_blank" rel="noopener noreferrer" onClick={stop}
                          style={{
                            flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                            padding: '0.55rem 0.75rem', borderRadius: '0.6rem',
                            background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                            border: 'none', color: '#fff', fontSize: '0.8rem', fontWeight: 700,
                            textDecoration: 'none', transition: 'all 0.2s',
                          }}
                        >
                          <Navigation style={{ width: 14, height: 14 }} /> {t('Directions', 'الاتجاهات')}
                        </a>
                      </>
                    );
                  })()}
                </div>
              </div>
            </Link>
          ))}
        </div>

        {hotels.length === 0 && !loading && (
          <div style={{ textAlign: 'center', padding: '4rem 2rem' }}>
            <Hotel className="w-16 h-16" style={{ margin: '0 auto 1.5rem', color: 'var(--primary)', opacity: 0.4 }} />
            <h2 style={{ fontSize: '1.4rem', color: 'var(--text-body)', marginBottom: '1rem' }}>{t('No hotels found', 'لا توجد فنادق')}</h2>
          </div>
        )}

        {hasMore && (
          <div style={{ textAlign: 'center', marginTop: '2.5rem' }}>
            <button onClick={() => fetchHotels(false)} disabled={loading} className="btn-back" style={{ opacity: loading ? 0.5 : 1 }}>
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Load More', 'تحميل المزيد')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function HotelsPage() {
  return <Suspense fallback={<div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>Loading...</div>}><HotelsContent /></Suspense>;
}
