'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { Star, MapPin, Navigation, Wifi, Car, Dumbbell, UtensilsCrossed, Waves, Wind, CloudSun, ArrowLeft, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Hotel, City } from '@/types/database';
import { toEGP } from '@/lib/egp';
import FavoriteButton from '@/components/FavoriteButton';
import SmartImage from '@/components/SmartImage';
import { mapsSearchUrl, mapsDirectionsUrl } from '@/lib/maps';

const amenityIcons: Record<string, React.ElementType> = {
  'Free WiFi': Wifi, 'Pool': Waves, 'Gym': Dumbbell, 'Restaurant': UtensilsCrossed,
  'Spa': Wind, 'Parking': Car,
};

export default function HotelDetailPage() {
  const { id } = useParams() as { id: string };
  const { t, lang } = useLang();
  const [hotel, setHotel] = useState<Hotel | null>(null);
  const [weather, setWeather] = useState<{ temp: number; desc: string; icon: string } | null>(null);

  useEffect(() => {
    supabase.from('hotels').select('*, city:cities(*)').eq('id', id).single()
      .then(({ data }) => {
        const item = data as unknown as Hotel | null;
        if (item) {
          setHotel(item);
          const key = process.env.NEXT_PUBLIC_OPENWEATHER_KEY;
          if (key) {
            fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${item.latitude}&lon=${item.longitude}&units=metric&appid=${key}`)
              .then(r => r.json()).then(w => {
                if (w.main) setWeather({ temp: Math.round(w.main.temp), desc: w.weather[0].description, icon: w.weather[0].icon });
              }).catch(() => {});
          }
        }
      });
  }, [id]);

  if (!hotel) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
      {t('Loading...', 'جاري التحميل...')}
    </div>
  );

  const city = hotel.city as unknown as City;
  const mapsUrl = mapsDirectionsUrl(hotel.name, city?.name);
  const mapsViewUrl = mapsSearchUrl(hotel.name, city?.name);
  const isAr = lang === 'ar';

  const cardStyle: React.CSSProperties = {
    background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.25rem',
  };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.5rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <Link href="/hotels" style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
          color: 'var(--primary)', fontWeight: 700, fontSize: '0.92rem',
          textDecoration: 'none', marginBottom: '1.5rem',
        }}>
          <ArrowLeft style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} />
          {t('Back to Hotels', 'العودة للفنادق')}
        </Link>

        <div style={{
          height: 360, borderRadius: '1.25rem', overflow: 'hidden', marginBottom: '1.75rem',
          border: '1px solid var(--border)', position: 'relative',
        }}>
          <SmartImage src={hotel.image_urls?.[0]} alt={hotel.name} fallbackName={hotel.name} loading="eager" />
          <div style={{ position: 'absolute', top: '1rem', insetInlineStart: '1rem', zIndex: 5 }}>
            <FavoriteButton type="hotel" id={hotel.id} variant="inline" size="lg" stopProp={false} />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(280px, 1fr)', gap: '1.5rem' }} className="detail-grid">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', minWidth: 0 }}>
            <div>
              <div style={{ display: 'flex', gap: '0.2rem', marginBottom: '0.6rem' }}>
                {Array.from({ length: hotel.star_rating }).map((_, s) => (
                  <Star key={s} style={{ width: 18, height: 18, color: 'var(--primary)', fill: 'var(--primary)' }} />
                ))}
              </div>
              <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem', lineHeight: 1.2 }}>
                {isAr ? (hotel as unknown as { name_ar?: string }).name_ar || hotel.name : hotel.name}
              </h1>
              <p style={{
                color: 'var(--text-muted)', display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                fontSize: '0.95rem',
              }}>
                <MapPin style={{ width: 16, height: 16 }} /> {isAr ? city?.name_ar : city?.name}
              </p>
            </div>

            {hotel.description && (
              <div style={cardStyle}>
                <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.6rem', fontSize: '1.1rem' }}>
                  {t('About', 'عن الفندق')}
                </h2>
                <p style={{ color: 'var(--text-body)', lineHeight: 1.7, fontSize: '0.95rem' }}>
                  {isAr ? (hotel as unknown as { description_ar?: string }).description_ar || hotel.description : hotel.description}
                </p>
              </div>
            )}

            {hotel.amenities && hotel.amenities.length > 0 && (
              <div>
                <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.75rem', fontSize: '1.1rem' }}>
                  {t('Amenities', 'المرافق')}
                </h2>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                  {hotel.amenities.map((a: string) => {
                    const Icon = amenityIcons[a] || Wifi;
                    return (
                      <span key={a} style={{
                        display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                        padding: '0.5rem 1rem', borderRadius: '0.75rem',
                        background: 'var(--bg-section)', border: '1px solid var(--border)',
                        fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-body)',
                      }}>
                        <Icon style={{ width: 16, height: 16, color: 'var(--primary)' }} />{a}
                      </span>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ ...cardStyle, padding: '1.25rem', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
                <span style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--primary)' }}>${hotel.price_per_night_usd}</span>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}> / {t('night', 'ليلة')}</span>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>
                  {toEGP(hotel.price_per_night_usd)} EGP
                </div>
              </div>
              <Link href={`/book?hotel=${hotel.id}`} className="btn-primary"
                style={{ padding: '0.85rem', justifyContent: 'center', textDecoration: 'none', fontSize: '0.95rem', width: '100%' }}>
                {t('Book Now', 'احجز الآن')}
              </Link>
              {hotel.booking_url && (
                <a href={hotel.booking_url} target="_blank" rel="noopener noreferrer"
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                    padding: '0.75rem', borderRadius: '0.75rem',
                    border: '1px solid var(--primary)', color: 'var(--primary)',
                    textDecoration: 'none', fontSize: '0.85rem', fontWeight: 700,
                    marginTop: '0.5rem', background: 'transparent',
                  }}>
                  <ExternalLink style={{ width: 14, height: 14 }} /> Booking.com
                </a>
              )}
            </div>

            <a href={mapsViewUrl} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.9rem 1rem', borderRadius: '0.9rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                textDecoration: 'none', color: 'inherit',
              }}>
              <MapPin style={{ width: 22, height: 22, color: 'var(--primary)', flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>
                  {t('Open in Google Maps', 'افتح في خرائط جوجل')}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                  {t('View location', 'عرض الموقع')}
                </div>
              </div>
            </a>

            <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.9rem 1rem', borderRadius: '0.9rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                textDecoration: 'none', color: 'inherit',
              }}>
              <Navigation style={{ width: 22, height: 22, color: 'var(--primary)', flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>
                  {t('Get Directions', 'الاتجاهات')}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                  {t('Navigate from your location', 'من موقعك الحالي')}
                </div>
              </div>
            </a>

            {weather && (
              <div style={cardStyle}>
                <h3 style={{
                  fontWeight: 700, fontSize: '0.85rem', marginBottom: '0.5rem',
                  display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-dark)',
                }}>
                  <CloudSun style={{ width: 16, height: 16, color: 'var(--primary)' }} />
                  {t('Current Weather', 'الطقس الحالي')}
                </h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <img src={`https://openweathermap.org/img/wn/${weather.icon}@2x.png`} alt=""
                    style={{ width: 48, height: 48 }} />
                  <div>
                    <div style={{ fontSize: '1.5rem', fontWeight: 900, color: 'var(--text-dark)' }}>{weather.temp}°C</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>{weather.desc}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
