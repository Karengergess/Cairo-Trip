'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { motion } from 'framer-motion';
import { Star, MapPin, Calculator, Zap, Wallet, Route } from 'lucide-react';

const heroImages = [
  '/images/pyramids.jpg',
  '/images/sphinx.jpg',
  '/images/temple.jpg',
];

const galleryImages = [
  '/images/nile.jpg',
  '/images/pyramid-closeup.jpg',
  '/images/cairo.jpg',
  '/images/pyramids.jpg',
  '/images/sphinx.jpg',
];

export default function HomePage() {
  const { t } = useLang();
  const router = useRouter();
  const [budget, setBudget] = useState('');

  const handlePlan = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const n = Number(budget);
    if (!n || n < 1) return;
    router.push(`/planner?budget=${n}`);
  };

  return (
    <>
      <section className="hero">
        <div className="hero-bg-image" />
        <div className="hero-inner">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="hero-text"
          >
            <div className="hero-badge">
              <Star className="w-4 h-4" />
              {t('Your Cairo and Giza guide', 'دليلك في القاهرة والجيزة')}
            </div>

            <h1 className="hero-title">
              {t('Plan Your', 'خطط')} <span>{t('Trip', 'رحلتك')}</span> {t('in', 'في')}<br />
              {t('Cairo & Giza', 'القاهرة والجيزة')}
            </h1>

            <p className="hero-subtitle">
              {t(
                'Enter your budget and discover the best Cairo attractions and historical places that you can visit, from the Pyramids to Khan el-Khalili',
                'أدخل ميزانيتك واكتشف أفضل المعالم السياحية والأماكن التاريخية في القاهرة التي يمكنك زيارتها - من الأهرامات إلى خان الخليلي'
              )}
            </p>

            <div className="budget-form-card">
              <form onSubmit={handlePlan}>
                <div className="form-group">
                  <label className="form-label">
                    <Wallet className="w-4 h-4 inline text-primary" style={{ marginInlineEnd: '0.4rem' }} />
                    {t('What\'s your trip budget?', 'كم ميزانيتك للرحلة؟')}
                  </label>
                  <div className="input-wrapper">
                    <Wallet className="input-icon w-5 h-5" />
                    <input
                      type="number"
                      className="form-input"
                      placeholder={t('e.g. 3000', 'مثال: ٣٠٠٠')}
                      min="1"
                      value={budget}
                      onChange={(e) => setBudget(e.target.value)}
                      required
                      style={{ paddingInlineStart: '3rem', paddingInlineEnd: '4.5rem' }}
                    />
                    <span className="currency-tag">EGP</span>
                  </div>
                </div>

                <button type="submit" className="btn-primary"
                  style={{ width: '100%', padding: '0.95rem', fontSize: '1rem', justifyContent: 'center' }}>
                  <Route style={{ width: 20, height: 20 }} />
                  {t('Discover Your Trip Now', 'اكتشف رحلتك الآن')}
                </button>
              </form>
            </div>
          </motion.div>

              <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="hero-images"
          >
            <div className="hero-img">
              <img src={heroImages[0]} alt={t('Pyramids of Giza', 'أهرامات الجيزة')} />
            </div>
            <div className="hero-img">
              <img src={heroImages[1]} alt={t('Egyptian Museum', 'المتحف المصري')} />
            </div>
            <div className="hero-img">
              <img src={heroImages[2]} alt={t('Islamic Cairo', 'القاهرة الإسلامية')} />
            </div>
          </motion.div>
        </div>
      </section>

      <div className="gallery-strip">
        {galleryImages.map((src, i) => (
          <img key={i} src={src} alt="" />
        ))}
      </div>

      <section className="features-section">
        <div className="features-grid">
          <div className="feature-item">
            <div className="feature-icon">
              <MapPin className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-text-dark mb-1">{t('Real Locations', 'مواقع حقيقية')}</h3>
            <p className="text-sm text-text-muted">{t('Updated prices for famous tourist attractions', 'أسعار محدثة لأشهر المعالم السياحية')}</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon">
              <Calculator className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-text-dark mb-1">{t('Based on Your Budget', 'حسب ميزانيتك')}</h3>
            <p className="text-sm text-text-muted">{t('The system picks the best options automatically', 'النظام يختار لك الأنسب تلقائيًا')}</p>
          </div>
          <div className="feature-item">
            <div className="feature-icon">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-text-dark mb-1">{t('Instant Results', 'نتائج فورية')}</h3>
            <p className="text-sm text-text-muted">{t('Get your trip plan in seconds', 'احصل على خطة رحلتك في ثوانٍ')}</p>
          </div>
        </div>
      </section>
    </>
  );
}
