'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { refCode } from '@/lib/refcode';
import { supabase } from '@/lib/supabase';
import {
  CheckCircle2, Clock3, Hotel as HotelIcon, MapPin, CalendarDays,
  Users, Printer, Loader2, Mail, Star, Moon, Sun,
} from 'lucide-react';

interface BookingRow {
  id: string;
  check_in: string;
  check_out: string;
  guests: number;
  total_price_usd: number;
  status: string;
  payment_method?: string | null;
  paid_at?: string | null;
  created_at: string;
  guest_name?: string | null;
  guest_email?: string | null;
  guest_phone?: string | null;
  hotel?: {
    name: string;
    name_ar?: string;
    star_rating?: number;
    description?: string;
    image_urls?: string[];
    city?: { name: string; name_ar?: string };
  } | null;
}

export default function PublicBookingPage() {
  const { id } = useParams() as { id: string };
  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      if (!token) { setLoading(false); return; }   // not signed in -> shows not-found card
      try {
        const r = await fetch(`/api/booking/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setBooking(r.ok ? await r.json() : null);
      } catch { /* ignore */ }
      setLoading(false);
    })();
  }, [id]);

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0a0a0f' }}>
        <Loader2 className="animate-spin" style={{ width: 28, height: 28, color: '#c8860a' }} />
      </div>
    );
  }

  if (!booking) {
    return (
      <div style={{ minHeight: '100vh', padding: '100px 1.25rem', background: '#0a0a0f', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{
          maxWidth: 440, padding: '3rem 2rem', textAlign: 'center',
          background: 'rgba(255,255,255,0.05)', backdropFilter: 'blur(20px)',
          border: '1px solid rgba(255,255,255,0.1)', borderRadius: '1.5rem',
        }}>
          <HotelIcon style={{ width: 48, height: 48, color: 'rgba(255,255,255,0.4)', margin: '0 auto 1rem' }} />
          <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#fff', marginBottom: '0.5rem' }}>Booking not found</h1>
          <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
            This link may be wrong or the booking was cancelled.
          </p>
          <Link href="/" style={{
            display: 'inline-flex', padding: '0.7rem 1.5rem',
            background: 'linear-gradient(135deg, #c8860a, #8b5e00)',
            color: '#fff', borderRadius: '0.6rem', textDecoration: 'none', fontWeight: 700,
          }}>Back to home</Link>
        </div>
      </div>
    );
  }

  const code = refCode('HTL', booking.id);
  const isConfirmed = booking.status === 'confirmed';
  const isCancelled = booking.status === 'cancelled';
  const fmtDate = (d: string) => new Date(d).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  const fmtDay = (d: string) => new Date(d).toLocaleDateString('en-US', { day: 'numeric' });
  const fmtMonth = (d: string) => new Date(d).toLocaleDateString('en-US', { month: 'short' });
  const nights = Math.max(1, Math.ceil((new Date(booking.check_out).getTime() - new Date(booking.check_in).getTime()) / 86400000));
  const heroImage = booking.hotel?.image_urls?.[0] || '/images/hotel.jpg';

  const statusConfig = isCancelled
    ? { bg: 'linear-gradient(135deg, #dc2626, #991b1b)', icon: Clock3, label: 'Cancelled', sub: 'This booking is no longer active' }
    : isConfirmed
    ? { bg: 'linear-gradient(135deg, #16a34a, #15803d)', icon: CheckCircle2, label: 'Confirmed', sub: 'Your room is reserved · Show this at check-in' }
    : { bg: 'linear-gradient(135deg, #c8860a, #8b5e00)', icon: Clock3, label: 'Pending', sub: 'We are confirming with the hotel · Email within 24h' };

  const StatusIcon = statusConfig.icon;

  return (
    <div style={{
      minHeight: '100vh',
      position: 'relative',
      padding: '100px 1rem 60px',
      background: '#0a0a0f',
      overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `url(${heroImage})`,
        backgroundSize: 'cover', backgroundPosition: 'center',
        filter: 'blur(40px) brightness(0.35)',
        transform: 'scale(1.15)',
        zIndex: 0,
      }} />
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, rgba(10,10,15,0.55) 0%, rgba(10,10,15,0.9) 70%)',
        zIndex: 0,
      }} />

      <div style={{ position: 'relative', zIndex: 1, maxWidth: 420, margin: '0 auto' }}>

        {/* Header tag */}
        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            padding: '0.4rem 0.85rem', borderRadius: 999,
            background: 'rgba(255,255,255,0.08)', backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.12)',
            color: 'rgba(255,255,255,0.85)', fontSize: '0.72rem',
            letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700,
          }}>
            <HotelIcon style={{ width: 12, height: 12 }} />
            Cairo Trip · Hotel Reservation
          </div>
        </div>

        {/* Main glass card */}
        <div style={{
          background: 'rgba(255,255,255,0.06)',
          backdropFilter: 'blur(24px)',
          WebkitBackdropFilter: 'blur(24px)',
          border: '1px solid rgba(255,255,255,0.12)',
          borderRadius: '1.75rem',
          overflow: 'hidden',
          boxShadow: '0 24px 60px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.12)',
        }}>

          {/* Status badge */}
          <div style={{
            padding: '1.75rem 1.75rem 1.5rem', textAlign: 'center',
            background: statusConfig.bg,
            position: 'relative',
          }}>
            <div style={{
              position: 'absolute', inset: 0,
              background: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.18), transparent 60%)',
              pointerEvents: 'none',
            }} />
            <div style={{ position: 'relative' }}>
              <div style={{
                width: 64, height: 64, margin: '0 auto 0.75rem', borderRadius: '50%',
                background: 'rgba(255,255,255,0.22)', backdropFilter: 'blur(12px)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '1px solid rgba(255,255,255,0.3)',
              }}>
                <StatusIcon style={{ width: 32, height: 32, color: '#fff' }} />
              </div>
              <div style={{ fontSize: '1.65rem', fontWeight: 900, color: '#fff', letterSpacing: '-0.02em' }}>
                {statusConfig.label}
              </div>
              <div style={{ fontSize: '0.8rem', opacity: 0.92, color: '#fff', marginTop: '0.35rem', lineHeight: 1.4 }}>
                {statusConfig.sub}
              </div>
            </div>
          </div>

          {/* Reference code */}
          <div style={{ padding: '1.5rem 1.75rem 0' }}>
            <div style={{
              padding: '1.1rem', borderRadius: '1rem',
              background: 'rgba(255,255,255,0.06)',
              border: '1px dashed rgba(200,134,10,0.5)',
              textAlign: 'center',
            }}>
              <div style={{
                fontSize: '0.66rem', letterSpacing: '0.12em', textTransform: 'uppercase',
                color: 'rgba(255,255,255,0.55)', fontWeight: 700, marginBottom: '0.35rem',
              }}>
                Booking Reference
              </div>
              <div style={{
                fontSize: '1.85rem', fontWeight: 900, letterSpacing: '0.1em',
                color: '#f4c842', fontFamily: 'monospace',
              }}>{code}</div>
            </div>
          </div>

          {/* Hotel info */}
          <div style={{ padding: '1.5rem 1.75rem 0' }}>
            <div style={{ display: 'flex', gap: '0.18rem', marginBottom: '0.5rem' }}>
              {Array.from({ length: booking.hotel?.star_rating || 0 }).map((_, i) => (
                <Star key={i} style={{ width: 14, height: 14, color: '#f4c842', fill: '#f4c842' }} />
              ))}
            </div>
            <h1 style={{
              fontSize: '1.45rem', fontWeight: 900, color: '#fff',
              marginBottom: '0.3rem', letterSpacing: '-0.02em', lineHeight: 1.2,
            }}>
              {booking.hotel?.name || 'Hotel'}
            </h1>
            <p style={{
              color: 'rgba(255,255,255,0.65)',
              display: 'inline-flex', alignItems: 'center', gap: '0.35rem',
              fontSize: '0.88rem',
            }}>
              <MapPin style={{ width: 14, height: 14 }} />
              {booking.hotel?.city?.name || 'Cairo'}
            </p>
          </div>

          {/* Date strip */}
          <div style={{ padding: '1.5rem 1.75rem 0' }}>
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '1rem', borderRadius: '1rem',
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.08)',
            }}>
              <div style={{ textAlign: 'center', flex: 1 }}>
                <div style={{ fontSize: '0.66rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.5)', fontWeight: 700, marginBottom: '0.3rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.25rem' }}>
                  <Sun style={{ width: 10, height: 10 }} /> Check-in
                </div>
                <div style={{ fontSize: '1.7rem', fontWeight: 900, color: '#fff', lineHeight: 1 }}>
                  {fmtDay(booking.check_in)}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.6)', marginTop: '0.2rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  {fmtMonth(booking.check_in)} · 14:00
                </div>
              </div>

              <div style={{
                padding: '0.4rem 0.7rem', borderRadius: 999,
                background: 'rgba(244,200,66,0.15)', color: '#f4c842',
                fontSize: '0.7rem', fontWeight: 800, whiteSpace: 'nowrap',
                display: 'flex', alignItems: 'center', gap: '0.3rem',
              }}>
                <Moon style={{ width: 11, height: 11 }} />
                {nights} {nights === 1 ? 'night' : 'nights'}
              </div>

              <div style={{ textAlign: 'center', flex: 1 }}>
                <div style={{ fontSize: '0.66rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.5)', fontWeight: 700, marginBottom: '0.3rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.25rem' }}>
                  <Moon style={{ width: 10, height: 10 }} /> Check-out
                </div>
                <div style={{ fontSize: '1.7rem', fontWeight: 900, color: '#fff', lineHeight: 1 }}>
                  {fmtDay(booking.check_out)}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.6)', marginTop: '0.2rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  {fmtMonth(booking.check_out)} · 12:00
                </div>
              </div>
            </div>
          </div>

          {/* Guest details */}
          <div style={{ padding: '1.25rem 1.75rem 0' }}>
            <div style={{
              padding: '1rem 1.1rem', borderRadius: '0.9rem',
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.06)',
              display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem 1.25rem',
            }}>
              <div>
                <div style={{ fontSize: '0.64rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.45)', fontWeight: 700, marginBottom: '0.18rem' }}>
                  Guest
                </div>
                <div style={{ color: '#fff', fontSize: '0.88rem', fontWeight: 700 }}>{booking.guest_name || '-'}</div>
              </div>
              <div>
                <div style={{ fontSize: '0.64rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.45)', fontWeight: 700, marginBottom: '0.18rem' }}>
                  Guests
                </div>
                <div style={{ color: '#fff', fontSize: '0.88rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                  <Users style={{ width: 12, height: 12, opacity: 0.6 }} /> {booking.guests}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '0.64rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.45)', fontWeight: 700, marginBottom: '0.18rem' }}>
                  Email
                </div>
                <div style={{ color: '#fff', fontSize: '0.78rem', fontWeight: 600, wordBreak: 'break-all' }}>{booking.guest_email || '-'}</div>
              </div>
              <div>
                <div style={{ fontSize: '0.64rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.45)', fontWeight: 700, marginBottom: '0.18rem' }}>
                  Phone
                </div>
                <div style={{ color: '#fff', fontSize: '0.78rem', fontWeight: 600 }}>{booking.guest_phone || '-'}</div>
              </div>
            </div>
          </div>

          {/* Total paid */}
          <div style={{ padding: '1.25rem 1.75rem 0' }}>
            <div style={{
              padding: '1rem 1.1rem', borderRadius: '0.9rem',
              background: 'linear-gradient(135deg, rgba(200,134,10,0.25), rgba(139,94,0,0.18))',
              border: '1px solid rgba(200,134,10,0.35)',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div>
                <div style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.65)', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 700 }}>
                  Total paid
                </div>
                <div style={{ fontSize: '0.66rem', color: 'rgba(255,255,255,0.5)', marginTop: '0.15rem' }}>
                  via {booking.payment_method === 'instapay' ? 'InstaPay' : 'Card'}
                </div>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 900, color: '#fff', letterSpacing: '-0.02em' }}>
                ${booking.total_price_usd}
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div style={{ padding: '1.5rem 1.75rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button onClick={() => window.print()} style={{
              flex: 1, minWidth: 130, padding: '0.8rem',
              borderRadius: '0.7rem',
              background: 'rgba(255,255,255,0.08)',
              border: '1px solid rgba(255,255,255,0.12)',
              backdropFilter: 'blur(8px)',
              color: '#fff', fontWeight: 700, fontSize: '0.85rem',
              cursor: 'pointer', fontFamily: 'inherit',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
            }}>
              <Printer style={{ width: 14, height: 14 }} /> Save as PDF
            </button>
            <a href="mailto:hello@cairotrip.com" style={{
              flex: 1, minWidth: 130, padding: '0.8rem',
              borderRadius: '0.7rem',
              background: 'rgba(255,255,255,0.08)',
              border: '1px solid rgba(255,255,255,0.12)',
              backdropFilter: 'blur(8px)',
              color: '#fff', fontWeight: 700, fontSize: '0.85rem',
              textDecoration: 'none',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
            }}>
              <Mail style={{ width: 14, height: 14 }} /> Contact support
            </a>
          </div>
        </div>

        <p style={{
          textAlign: 'center', fontSize: '0.7rem', color: 'rgba(255,255,255,0.4)',
          marginTop: '1.5rem', letterSpacing: '0.05em',
        }}>
          Cairo Trip · independent travel guide · cairotrip.com
        </p>
      </div>
    </div>
  );
}
