'use client';

import { useState } from 'react';
import { useLang } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { MessageSquareWarning, Send, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import SplitFormLayout from '@/components/SplitFormLayout';
import { isValidEmail, sanitizeText, sanitizeTextarea } from '@/lib/security';

const categories = [
  { en: 'Service', ar: 'خدمة' },
  { en: 'Safety', ar: 'أمان' },
  { en: 'Cleanliness', ar: 'نظافة' },
  { en: 'Pricing', ar: 'أسعار' },
  { en: 'Other', ar: 'أخرى' },
];

export default function ComplaintPage() {
  const { t, lang } = useLang();
  const { user } = useAuth();
  const [form, setForm] = useState({ email: user?.email || '', category: 'Service', subject: '', description: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const email = form.email.trim();
    const subject = sanitizeText(form.subject, 120);
    const description = sanitizeTextarea(form.description, 2000);
    if (!isValidEmail(email)) { setError(t('Please enter a valid email.', 'أدخل بريدًا إلكترونيًا صحيحًا.')); return; }
    if (subject.length < 3) { setError(t('Subject is too short.', 'الموضوع قصير جدًا.')); return; }
    if (description.length < 10) { setError(t('Please describe the issue in a bit more detail.', 'يرجى وصف المشكلة بمزيد من التفصيل.')); return; }

    setLoading(true);
    const res = await (supabase.from('complaints') as unknown as { insert: (data: Record<string, unknown>) => Promise<{ error: { message: string } | null }> }).insert({
      user_id: user?.id || null,
      user_email: email,
      category: form.category,
      subject,
      description,
      status: 'pending',
    });
    if (res.error) { setError(t('Could not submit your complaint. Please try again.', 'تعذّر إرسال الشكوى. حاول مرة أخرى.')); setLoading(false); }
    else { setSubmitted(true); setLoading(false); }
  };

  if (submitted) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '100px 1rem 3rem' }}>
        <div style={{ textAlign: 'center', maxWidth: 400 }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'rgba(39,174,96,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem' }}>
            <CheckCircle style={{ width: 40, height: 40, color: 'var(--success)' }} />
          </div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>{t('Complaint Submitted', 'تم إرسال الشكوى')}</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', lineHeight: 1.6 }}>{t('Our team will review your complaint and take action. You will be contacted via the email you provided.', 'فريقنا سيراجع شكواك ويتخذ الإجراء المناسب. سيتم التواصل معك عبر البريد الإلكتروني.')}</p>
        </div>
      </div>
    );
  }

  return (
    <SplitFormLayout
      gradientColors="linear-gradient(135deg, #e74c3c, #c0392b)"
      icon={<AlertTriangle style={{ width: 48, height: 48, marginBottom: '1.5rem', opacity: 0.9 }} />}
      title={t('We Take Complaints Seriously', 'نأخذ الشكاوى على محمل الجد')}
      subtitle={t(
        'Your feedback helps us improve our service. All complaints are reviewed within 24 hours by our team.',
        'ملاحظاتك تساعدنا على تحسين خدمتنا. يتم مراجعة جميع الشكاوى خلال 24 ساعة.'
      )}
      extraContent={
        <div style={{ marginTop: '2rem', padding: '1rem', background: 'rgba(255,255,255,0.12)', borderRadius: '0.75rem', fontSize: '0.85rem', lineHeight: 1.6, opacity: 0.9 }}>
          <strong>{t('Response Time:', 'وقت الاستجابة:')}</strong><br/>
          {t('We aim to respond within 24 hours', 'نهدف للرد خلال ٢٤ ساعة')}
        </div>
      }
    >
      <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        <div style={{
          width: 56, height: 56, borderRadius: '1rem', margin: '0 auto 1rem',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'rgba(231,76,60,0.1)',
        }}>
          <MessageSquareWarning style={{ width: 28, height: 28, color: '#e74c3c' }} />
        </div>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.25rem' }}>
          {t('Submit a Complaint', 'تقديم شكوى')}
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
          {t('Help us improve your experience', 'ساعدنا نحسن تجربتك')}
        </p>
      </div>

      {error && (
        <div style={{ marginBottom: '1rem', padding: '0.75rem 1rem', borderRadius: '0.75rem', background: '#fef2f2', border: '1px solid #fecaca', color: 'var(--danger)', fontSize: '0.85rem', fontWeight: 600 }}>
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <div>
          <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>{t('Email', 'البريد الإلكتروني')}</label>
          <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} className="input" required />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>{t('Category', 'التصنيف')}</label>
          <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} className="input">
            {categories.map(c => <option key={c.en} value={c.en}>{lang === 'ar' ? c.ar : c.en}</option>)}
          </select>
        </div>
        <div>
          <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>{t('Subject', 'الموضوع')}</label>
          <input type="text" value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} className="input" required />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>{t('Description', 'الوصف')}</label>
          <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="input" style={{ minHeight: 100, resize: 'vertical' }} required />
        </div>
        <button type="submit" disabled={loading} className="btn-primary" style={{ width: '100%', padding: '0.85rem', fontSize: '1rem', opacity: loading ? 0.6 : 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem' }}>
          <Send style={{ width: 16, height: 16 }} /> {loading ? t('Submitting...', 'جاري الإرسال...') : t('Submit Complaint', 'إرسال الشكوى')}
        </button>
      </form>
    </SplitFormLayout>
  );
}
