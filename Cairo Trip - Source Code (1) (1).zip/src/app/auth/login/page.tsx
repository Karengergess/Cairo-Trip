'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LanguageContext';
import { LogIn, Mail, Lock, Eye, EyeOff, MapPin } from 'lucide-react';
import SplitFormLayout from '@/components/SplitFormLayout';

export default function LoginPage() {
  const { signIn } = useAuth();
  const { t } = useLang();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!/^\S+@\S+\.\S+$/.test(email)) { setError(t('Please enter a valid email address', 'يرجى إدخال بريد إلكتروني صحيح')); return; }
    if (password.length < 1) { setError(t('Please enter your password', 'يرجى إدخال كلمة المرور')); return; }
    setLoading(true);
    const { error } = await signIn(email, password);
    if (error) {
      const msg = error.toLowerCase().includes('invalid') ? t('Wrong email or password. Try again.', 'البريد أو كلمة المرور غير صحيحة. حاول مجدداً.')
                : error.toLowerCase().includes('not confirmed') ? t('Please verify your email before signing in.', 'يرجى تأكيد بريدك قبل تسجيل الدخول.')
                : error;
      setError(msg);
      setLoading(false);
    } else {
      router.push('/dashboard');
    }
  };

  return (
    <SplitFormLayout
      gradientColors="linear-gradient(135deg, var(--primary), var(--accent))"
      icon={<MapPin style={{ width: 48, height: 48, marginBottom: '1.5rem', opacity: 0.9 }} />}
      title={t('Explore the Land of the Pharaohs', 'استكشف أرض الفراعنة')}
      subtitle={t(
        'Plan your perfect Cairo adventure with personalized recommendations based on your budget.',
        'خطط لمغامرتك المثالية في القاهرة مع توصيات مخصصة حسب ميزانيتك.'
      )}
      extraContent={
        <div style={{ marginTop: '2rem', display: 'flex', gap: '1.5rem', fontSize: '0.85rem', opacity: 0.8 }}>
          <div><span style={{ fontSize: '1.5rem', fontWeight: 900, display: 'block' }}>6</span>{t('Attractions', 'معلم سياحي')}</div>
          <div><span style={{ fontSize: '1.5rem', fontWeight: 900, display: 'block' }}>4</span>{t('Hotels', 'فندق')}</div>
          <div><span style={{ fontSize: '1.5rem', fontWeight: 900, display: 'block' }}>4</span>{t('Restaurants', 'مطاعم')}</div>
        </div>
      }
    >
      <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <div style={{
          width: 56, height: 56, borderRadius: '1rem', margin: '0 auto 1rem',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'linear-gradient(135deg, var(--primary), var(--accent))',
        }}>
          <LogIn style={{ width: 28, height: 28, color: '#fff' }} />
        </div>
        <h1 style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.25rem' }}>
          {t('Welcome Back', 'مرحبا بعودتك')}
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
          {t('Sign in to your account', 'سجل دخول لحسابك')}
        </p>
      </div>

      {error && (
        <div style={{ marginBottom: '1rem', padding: '0.75rem 1rem', borderRadius: '0.75rem', background: '#fef2f2', border: '1px solid #fecaca', color: 'var(--danger)', fontSize: '0.875rem', fontWeight: 600 }}>
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        <div>
          <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Email', 'البريد الإلكتروني')}
          </label>
          <div style={{ position: 'relative' }}>
            <Mail style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, color: 'var(--text-muted)' }} />
            <input
              type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              className="input" placeholder="you@example.com" required
              style={{ paddingInlineStart: '2.75rem' }}
            />
          </div>
        </div>

        <div>
          <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Password', 'كلمة المرور')}
          </label>
          <div style={{ position: 'relative' }}>
            <Lock style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, color: 'var(--text-muted)' }} />
            <input
              type={showPw ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)}
              className="input" placeholder="********" required
              style={{ paddingInlineStart: '2.75rem', paddingInlineEnd: '2.75rem' }}
            />
            <button type="button" onClick={() => setShowPw(!showPw)} style={{
              position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)',
              background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 0,
            }}>
              {showPw ? <EyeOff style={{ width: 18, height: 18 }} /> : <Eye style={{ width: 18, height: 18 }} />}
            </button>
          </div>
        </div>

        <button type="submit" disabled={loading} className="btn-primary" style={{ width: '100%', padding: '0.85rem', fontSize: '1rem', opacity: loading ? 0.6 : 1 }}>
          {loading ? t('Signing in...', 'جاري الدخول...') : t('Sign In', 'دخول')}
        </button>
      </form>

      <p style={{ textAlign: 'center', fontSize: '0.875rem', color: 'var(--text-muted)', marginTop: '1.5rem' }}>
        {t("Don't have an account?", 'ليس لديك حساب؟')}{' '}
        <Link href="/auth/signup" style={{ color: 'var(--primary)', fontWeight: 700, textDecoration: 'none' }}>{t('Sign Up', 'سجل الآن')}</Link>
      </p>
    </SplitFormLayout>
  );
}
