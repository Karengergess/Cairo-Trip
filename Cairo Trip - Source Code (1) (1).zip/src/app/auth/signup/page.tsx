'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LanguageContext';
import { UserPlus, Mail, Lock, User, Eye, EyeOff, MapPin } from 'lucide-react';
import SplitFormLayout from '@/components/SplitFormLayout';

export default function SignupPage() {
  const { signUp } = useAuth();
  const { t } = useLang();
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const trimmedName = name.trim();
    if (!trimmedName) { setError(t('Please enter your name', 'يرجى إدخال اسمك')); return; }
    if (!/^[\p{L}'\-\.\s]{2,}$/u.test(trimmedName)) {
      setError(t('Use letters only for your name', 'استخدم حروف فقط في الاسم'));
      return;
    }
    const parts = trimmedName.split(/\s+/);
    if (parts.length < 2 || parts.some(w => w.length < 2)) {
      setError(t('Please enter your first and last name', 'برجاء إدخال الاسم الأول والأخير'));
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { setError(t('Please enter a valid email address', 'يرجى إدخال بريد إلكتروني صحيح')); return; }
    if (password.length < 6) { setError(t('Password must be at least 6 characters', 'كلمة المرور يجب أن تكون 6 أحرف على الأقل')); return; }
    setLoading(true);
    const { error } = await signUp(email, password, name);
    if (error) { setError(error); setLoading(false); }
    else { router.push('/dashboard'); }
  };

  return (
    <SplitFormLayout
      gradientColors="linear-gradient(135deg, var(--primary), var(--accent))"
      icon={<MapPin style={{ width: 48, height: 48, marginBottom: '1.5rem', opacity: 0.9 }} />}
      title={t('Start Your Cairo Adventure', 'ابدأ مغامرتك في القاهرة')}
      subtitle={t(
        'Create your account to save favorites, plan trips, and get personalized recommendations.',
        'أنشئ حسابك لحفظ المفضلة وتخطيط الرحلات والحصول على توصيات مخصصة.'
      )}
      extraContent={
        <div style={{ marginTop: '2rem', display: 'flex', gap: '1.5rem', fontSize: '0.85rem', opacity: 0.8 }}>
          <div><span style={{ fontSize: '1.5rem', fontWeight: 900, display: 'block' }}>6</span>{t('Attractions', 'معلم سياحي')}</div>
          <div><span style={{ fontSize: '1.5rem', fontWeight: 900, display: 'block' }}>4</span>{t('Hotels', 'فندق')}</div>
          <div><span style={{ fontSize: '1.5rem', fontWeight: 900, display: 'block' }}>4</span>{t('Restaurants', 'مطاعم')}</div>
        </div>
      }
    >
      <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <div style={{
          width: 56, height: 56, borderRadius: '1rem', margin: '0 auto 1rem',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'linear-gradient(135deg, var(--primary), var(--accent))',
        }}>
          <UserPlus style={{ width: 28, height: 28, color: '#fff' }} />
        </div>
        <h1 style={{ fontSize: '1.6rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.25rem' }}>
          {t('Create Account', 'إنشاء حساب')}
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
          {t('Join Cairo Trip', 'انضم لرحلتك في القاهرة')}
        </p>
      </div>

      {error && (
        <div style={{ marginBottom: '1rem', padding: '0.75rem 1rem', borderRadius: '0.75rem', background: '#fef2f2', border: '1px solid #fecaca', color: 'var(--danger)', fontSize: '0.875rem', fontWeight: 600 }}>
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
        <div>
          <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Full Name', 'الاسم الكامل')}
          </label>
          <div style={{ position: 'relative' }}>
            <User style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, color: 'var(--text-muted)' }} />
            <input
              type="text" value={name} onChange={(e) => setName(e.target.value)}
              className="input" placeholder={t('John Doe', 'محمد أحمد')} required
              style={{ paddingInlineStart: '2.75rem' }}
            />
          </div>
        </div>

        <div>
          <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Email', 'البريد الإلكتروني')}
          </label>
          <div style={{ position: 'relative' }}>
            <Mail style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, color: 'var(--text-muted)' }} />
            <input
              type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              className="input" placeholder="you@example.com" required
              style={{ paddingInlineStart: '2.75rem' }}
            />
          </div>
        </div>

        <div>
          <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Password', 'كلمة المرور')}
          </label>
          <div style={{ position: 'relative' }}>
            <Lock style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, color: 'var(--text-muted)' }} />
            <input
              type={showPw ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)}
              className="input" placeholder="********" required
              style={{ paddingInlineStart: '2.75rem', paddingInlineEnd: '2.75rem' }}
            />
            <button type="button" onClick={() => setShowPw(!showPw)} style={{
              position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)',
              background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 0,
            }}>
              {showPw ? <EyeOff style={{ width: 18, height: 18 }} /> : <Eye style={{ width: 18, height: 18 }} />}
            </button>
          </div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.3rem' }}>
            {t('At least 6 characters', 'على الأقل 6 أحرف')}
          </p>
        </div>

        <button type="submit" disabled={loading} className="btn-primary" style={{ width: '100%', padding: '0.85rem', fontSize: '1rem', opacity: loading ? 0.6 : 1 }}>
          {loading ? t('Creating...', 'جاري الإنشاء...') : t('Create Account', 'إنشاء حساب')}
        </button>
      </form>

      <p style={{ textAlign: 'center', fontSize: '0.875rem', color: 'var(--text-muted)', marginTop: '1.5rem' }}>
        {t('Already have an account?', 'لديك حساب بالفعل؟')}{' '}
        <Link href="/auth/login" style={{ color: 'var(--primary)', fontWeight: 700, textDecoration: 'none' }}>{t('Sign In', 'دخول')}</Link>
      </p>
    </SplitFormLayout>
  );
}
