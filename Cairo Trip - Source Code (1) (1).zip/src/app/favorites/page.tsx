'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useFavorites } from '@/contexts/FavoritesContext';
import { useLang } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Heart, Hotel, Compass, Star, MapPin, UtensilsCrossed } from 'lucide-react';
import FavoriteButton from '@/components/FavoriteButton';
import SmartImage from '@/components/SmartImage';
import type { City } from '@/types/database';

interface AttrRow { id: string; name: string; name_ar?: string; image_url?: string; entry_fee_usd: number; city?: City; }
interface HotelRow { id: string; name: string; name_ar?: string; image_urls?: string[]; price_per_night_usd: number; star_rating: number; city?: City; }
interface RestRow { id: string; name: string; name_ar?: string; image_url?: string; avg_meal_usd: number; cuisine: string; cuisine_ar?: string; city?: City; }

export default function FavoritesPage() {
  const { favorites } = useFavorites();
  const { t, lang } = useLang();
  const { user, loading: authLoading } = useAuth();
  const [attrs, setAttrs] = useState<AttrRow[]>([]);
  const [hotels, setHotels] = useState<HotelRow[]>([]);
  const [rests, setRests] = useState<RestRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const attrIds = favorites.filter(f => f.type === 'attraction').map(f => f.id);
      const hotelIds = favorites.filter(f => f.type === 'hotel').map(f => f.id);
      const restIds = favorites.filter(f => f.type === 'restaurant').map(f => f.id);

      const [a, h, r] = await Promise.all([
        attrIds.length
          ? supabase.from('attractions').select('id, name, name_ar, image_url, entry_fee_usd, city:cities(*)').in('id', attrIds)
          : Promise.resolve({ data: [] }),
        hotelIds.length
          ? supabase.from('hotels').select('id, name, name_ar, image_urls, price_per_night_usd, star_rating, city:cities(*)').in('id', hotelIds)
          : Promise.resolve({ data: [] }),
        restIds.length
          ? supabase.from('restaurants').select('id, name, name_ar, image_url, avg_meal_usd, cuisine, cuisine_ar, city:cities(*)').in('id', restIds)
          : Promise.resolve({ data: [] }),
      ]);
      setAttrs((a.data as unknown as AttrRow[]) || []);
      setHotels((h.data as unknown as HotelRow[]) || []);
      setRests((r.data as unknown as RestRow[]) || []);
      setLoading(false);
    }
    load();
  }, [favorites]);

  const isAr = lang === 'ar';
  const empty = !loading && attrs.length === 0 && hotels.length === 0 && rests.length === 0;

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.5rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: 56, height: 56, borderRadius: '1rem', margin: '0 auto 1rem',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'linear-gradient(135deg, #e74c3c, #c0392b)',
          }}>
            <Heart style={{ width: 28, height: 28, color: '#fff', fill: '#fff' }} />
          </div>
          <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('My Favorites', 'المفضلة')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
            {!authLoading && !user
              ? t('Sign in to sync favorites across devices', 'سجل الدخول لمزامنة المفضلة على كل الأجهزة')
              : t('All your saved places in one spot', 'كل أماكنك المحفوظة في مكان واحد')}
          </p>
        </div>

        {empty && (
          <div style={{ textAlign: 'center', padding: '4rem 2rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem' }}>
            <Heart style={{ width: 56, height: 56, color: 'var(--text-muted)', margin: '0 auto 1rem', opacity: 0.4 }} />
            <h2 style={{ fontSize: '1.2rem', color: 'var(--text-dark)', fontWeight: 800, marginBottom: '0.5rem' }}>
              {t('No favorites yet', 'لا توجد مفضلة بعد')}
            </h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
              {t('Tap the heart on any place to save it here', 'اضغط القلب على أي مكان لحفظه هنا')}
            </p>
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link href="/attractions" className="btn-primary" style={{ textDecoration: 'none', padding: '0.75rem 1.5rem' }}>
                <Compass style={{ width: 16, height: 16 }} /> {t('Browse Attractions', 'تصفح المعالم')}
              </Link>
              <Link href="/hotels" className="btn-back" style={{ textDecoration: 'none', padding: '0.75rem 1.5rem' }}>
                <Hotel style={{ width: 16, height: 16 }} /> {t('Browse Hotels', 'تصفح الفنادق')}
              </Link>
            </div>
          </div>
        )}

        {attrs.length > 0 && (
          <section style={{ marginBottom: '2.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
              <Compass style={{ width: 20, height: 20, color: 'var(--primary)' }} />
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-dark)' }}>
                {t('Saved Attractions', 'المعالم المحفوظة')} ({attrs.length})
              </h2>
            </div>
            <div className="locations-grid">
              {attrs.map((attr) => (
                <Link key={attr.id} href={`/attractions/${attr.id}`} className="card"
                  style={{ display: 'block', textDecoration: 'none', color: 'inherit' }}>
                  <div style={{ height: 160, position: 'relative', overflow: 'hidden' }}>
                    <SmartImage src={attr.image_url} alt={attr.name} fallbackName={attr.name} />
                    <FavoriteButton type="attraction" id={attr.id} />
                  </div>
                  <div style={{ padding: '1rem 1.25rem' }}>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                      {isAr ? (attr.name_ar || attr.name) : attr.name}
                    </h3>
                    <span style={{
                      display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                      color: 'var(--text-muted)', fontSize: '0.78rem',
                      background: 'var(--bg-section)', padding: '0.2rem 0.6rem', borderRadius: '8px',
                    }}>
                      <MapPin style={{ width: 12, height: 12 }} /> {isAr ? attr.city?.name_ar : attr.city?.name}
                    </span>
                    <div style={{ marginTop: '0.6rem', fontSize: '0.95rem', fontWeight: 800, color: 'var(--primary)' }}>
                      {attr.entry_fee_usd > 0 ? `$${attr.entry_fee_usd}` : t('Free', 'مجاني')}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {rests.length > 0 && (
          <section style={{ marginBottom: '2.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
              <UtensilsCrossed style={{ width: 20, height: 20, color: 'var(--primary)' }} />
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-dark)' }}>
                {t('Saved Restaurants', 'المطاعم المحفوظة')} ({rests.length})
              </h2>
            </div>
            <div className="locations-grid">
              {rests.map((r) => (
                <Link key={r.id} href={`/restaurants/${r.id}`} className="card"
                  style={{ display: 'block', textDecoration: 'none', color: 'inherit' }}>
                  <div style={{ height: 160, position: 'relative', overflow: 'hidden' }}>
                    <SmartImage src={r.image_url} alt={r.name} fallbackName={r.name} />
                    <FavoriteButton type="restaurant" id={r.id} />
                  </div>
                  <div style={{ padding: '1rem 1.25rem' }}>
                    <span style={{
                      fontSize: '0.7rem', fontWeight: 700,
                      padding: '0.2rem 0.55rem', borderRadius: '0.5rem',
                      background: 'rgba(200,134,10,0.12)', color: 'var(--primary)',
                      display: 'inline-block', marginBottom: '0.4rem',
                    }}>{isAr ? (r.cuisine_ar || r.cuisine) : r.cuisine}</span>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                      {isAr ? (r.name_ar || r.name) : r.name}
                    </h3>
                    <span style={{
                      display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                      color: 'var(--text-muted)', fontSize: '0.78rem',
                      background: 'var(--bg-section)', padding: '0.2rem 0.6rem', borderRadius: '8px',
                    }}>
                      <MapPin style={{ width: 12, height: 12 }} /> {isAr ? r.city?.name_ar : r.city?.name}
                    </span>
                    <div style={{ marginTop: '0.6rem', fontSize: '0.95rem', fontWeight: 800, color: 'var(--primary)' }}>
                      ~${r.avg_meal_usd}<span style={{ fontWeight: 400, fontSize: '0.78rem', color: 'var(--text-muted)' }}> / {t('meal', 'وجبة')}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {hotels.length > 0 && (
          <section>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
              <Hotel style={{ width: 20, height: 20, color: 'var(--primary)' }} />
              <h2 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-dark)' }}>
                {t('Saved Hotels', 'الفنادق المحفوظة')} ({hotels.length})
              </h2>
            </div>
            <div className="locations-grid">
              {hotels.map((hotel) => (
                <Link key={hotel.id} href={`/hotels/${hotel.id}`} className="card"
                  style={{ display: 'block', textDecoration: 'none', color: 'inherit' }}>
                  <div style={{ height: 160, position: 'relative', overflow: 'hidden' }}>
                    <SmartImage src={hotel.image_urls?.[0]} alt={hotel.name} fallbackName={hotel.name} />
                    <FavoriteButton type="hotel" id={hotel.id} />
                  </div>
                  <div style={{ padding: '1rem 1.25rem' }}>
                    <div style={{ display: 'flex', gap: '0.15rem', marginBottom: '0.4rem' }}>
                      {Array.from({ length: hotel.star_rating }).map((_, s) => (
                        <Star key={s} style={{ width: 14, height: 14, color: 'var(--primary)', fill: 'var(--primary)' }} />
                      ))}
                    </div>
                    <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                      {isAr ? (hotel.name_ar || hotel.name) : hotel.name}
                    </h3>
                    <span style={{
                      display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                      color: 'var(--text-muted)', fontSize: '0.78rem',
                      background: 'var(--bg-section)', padding: '0.2rem 0.6rem', borderRadius: '8px',
                    }}>
                      <MapPin style={{ width: 12, height: 12 }} /> {isAr ? hotel.city?.name_ar : hotel.city?.name}
                    </span>
                    <div style={{ marginTop: '0.6rem', fontSize: '0.95rem', fontWeight: 800, color: 'var(--primary)' }}>
                      ${hotel.price_per_night_usd}<span style={{ fontWeight: 400, fontSize: '0.78rem', color: 'var(--text-muted)' }}> / {t('night', 'ليلة')}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
