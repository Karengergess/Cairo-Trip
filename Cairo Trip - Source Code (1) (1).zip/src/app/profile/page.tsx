'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LanguageContext';
import { useUI } from '@/contexts/UIContext';
import {
  User, Save, Globe, Wallet, Mail, Shield, LogOut, Heart,
  CalendarDays, Hotel, Compass, ChevronRight, Camera, Loader2,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

export default function ProfilePage() {
  const { user, profile, isAdmin, loading: authLoading, signOut } = useAuth();
  const { t, lang, setLang } = useLang();
  const { toast, confirm } = useUI();
  const router = useRouter();
  const [form, setForm] = useState({ full_name: '', avatar_url: '', preferred_language: 'en', preferred_currency: 'USD' });
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState({ saved: 0, bookings: 0 });
  const isAr = lang === 'ar';

  useEffect(() => {
    if (!authLoading && !user) router.push('/auth/login');
  }, [user, authLoading, router]);

  useEffect(() => {
    if (profile) {
      setForm({
        full_name: profile.full_name || '',
        avatar_url: profile.avatar_url || '',
        preferred_language: profile.preferred_language || 'en',
        preferred_currency: profile.preferred_currency || 'USD',
      });
    }
  }, [profile]);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from('saved_places').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
      supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
    ]).then(([s, b]) => setStats({ saved: s.count || 0, bookings: b.count || 0 }));
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await (supabase.from('profiles') as any).update(form).eq('id', user.id);
    setSaving(false);
    if (error) { toast({ message: error.message, type: 'error' }); return; }
    setLang(form.preferred_language as 'en' | 'ar');
    toast({ message: t('Profile updated successfully', 'تم تحديث الملف بنجاح'), type: 'success' });
  };

  const handleSignOut = async () => {
    const ok = await confirm({
      title: t('Sign out?', 'تسجيل الخروج؟'),
      message: t('You will need to sign in again to access your saved places.', 'هتحتاج تسجل دخول تاني عشان توصل لأماكنك المحفوظة.'),
      confirmText: t('Sign out', 'خروج'),
      cancelText: t('Stay', 'البقاء'),
      danger: true,
    });
    if (!ok) return;
    await signOut();
    router.push('/');
  };

  if (authLoading || !user) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Loader2 className="animate-spin" style={{ width: 28, height: 28, color: 'var(--primary)' }} />
    </div>
  );

  const displayName = form.full_name
    || (user.user_metadata as Record<string, string> | undefined)?.full_name
    || user.email?.split('@')[0]
    || t('Traveler', 'مسافر');
  const initials = displayName.trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase()).join('') || 'U';
  const cardStyle: React.CSSProperties = {
    background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.5rem',
  };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 980, margin: '0 auto' }}>

        <div style={{
          background: 'linear-gradient(135deg, var(--primary), var(--accent))',
          borderRadius: '1.5rem', padding: '2.5rem 2rem 4.5rem',
          color: '#fff', position: 'relative', overflow: 'hidden', marginBottom: '-3rem',
        }}>
          <div style={{ position: 'absolute', top: -40, insetInlineEnd: -40, width: 180, height: 180, borderRadius: '50%', background: 'rgba(255,255,255,0.1)' }} />
          <div style={{ position: 'absolute', bottom: -60, insetInlineStart: 40, width: 140, height: 140, borderRadius: '50%', background: 'rgba(255,255,255,0.06)' }} />

          <div style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
            <h1 style={{ fontSize: '1.5rem', fontWeight: 900, marginBottom: '0.25rem' }}>
              {t('My Profile', 'ملفي الشخصي')}
            </h1>
            <p style={{ fontSize: '0.9rem', opacity: 0.85 }}>
              {t('Manage your account & preferences', 'إدارة حسابك وتفضيلاتك')}
            </p>
          </div>
        </div>

        <div style={{
          ...cardStyle, position: 'relative', marginBottom: '1.25rem',
          boxShadow: '0 10px 30px rgba(0,0,0,0.06)', textAlign: 'center', paddingTop: '4rem',
        }}>
          <div style={{
            position: 'absolute', top: -52, insetInlineStart: '50%', transform: 'translateX(-50%)',
            width: 104, height: 104, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--primary), var(--accent))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', fontSize: '2.2rem', fontWeight: 900,
            border: '5px solid var(--bg-card)', overflow: 'hidden',
            boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
          }}>
            {form.avatar_url ? (
              <img src={form.avatar_url} alt={form.full_name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            ) : initials}
          </div>
          <h2 style={{ fontSize: '1.4rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.25rem' }}>
            {displayName}
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
            <Mail style={{ width: 14, height: 14 }} /> {user.email}
          </p>
          {isAdmin && (
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.35rem',
              marginTop: '0.75rem', padding: '0.3rem 0.85rem', borderRadius: 999,
              background: 'rgba(200,134,10,0.12)', color: 'var(--primary)',
              fontWeight: 700, fontSize: '0.78rem',
            }}>
              <Shield style={{ width: 12, height: 12 }} /> {t('Administrator', 'مدير')}
            </div>
          )}

          {/* STATS */}
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0.85rem', marginTop: '1.5rem',
          }}>
            <Link href="/favorites" style={{
              padding: '1rem', borderRadius: '0.85rem', background: 'var(--bg-section)',
              border: '1px solid var(--border)', textDecoration: 'none', color: 'inherit',
              display: 'flex', alignItems: 'center', gap: '0.85rem',
            }}>
              <div style={{ width: 40, height: 40, borderRadius: '0.65rem', background: 'rgba(231,76,60,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Heart style={{ width: 20, height: 20, color: '#e74c3c' }} />
              </div>
              <div style={{ textAlign: 'start', flex: 1 }}>
                <div style={{ fontSize: '1.4rem', fontWeight: 900, color: 'var(--text-dark)', lineHeight: 1 }}>{stats.saved}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{t('Saved places', 'أماكن محفوظة')}</div>
              </div>
              <ChevronRight style={{ width: 16, height: 16, color: 'var(--text-muted)' }} />
            </Link>
            <Link href="/dashboard" style={{
              padding: '1rem', borderRadius: '0.85rem', background: 'var(--bg-section)',
              border: '1px solid var(--border)', textDecoration: 'none', color: 'inherit',
              display: 'flex', alignItems: 'center', gap: '0.85rem',
            }}>
              <div style={{ width: 40, height: 40, borderRadius: '0.65rem', background: 'rgba(200,134,10,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <CalendarDays style={{ width: 20, height: 20, color: 'var(--primary)' }} />
              </div>
              <div style={{ textAlign: 'start', flex: 1 }}>
                <div style={{ fontSize: '1.4rem', fontWeight: 900, color: 'var(--text-dark)', lineHeight: 1 }}>{stats.bookings}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{t('Bookings', 'حجوزات')}</div>
              </div>
              <ChevronRight style={{ width: 16, height: 16, color: 'var(--text-muted)' }} />
            </Link>
          </div>
        </div>

        <div style={{ ...cardStyle, marginBottom: '1.25rem' }}>
          <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <User style={{ width: 18, height: 18, color: 'var(--primary)' }} /> {t('Edit Profile', 'تعديل الملف')}
          </h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                {t('Full Name', 'الاسم الكامل')}
              </label>
              <input type="text" value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} className="input" />
            </div>

            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                <Camera style={{ width: 14, height: 14 }} /> {t('Avatar URL', 'رابط الصورة')}
              </label>
              <input type="url" value={form.avatar_url} onChange={e => setForm(p => ({ ...p, avatar_url: e.target.value }))} className="input" placeholder="https://..." />
              <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.3rem' }}>
                {t('Paste a link to your photo', 'الصق رابط الصورة الخاصة بك')}
              </p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  <Globe style={{ width: 14, height: 14 }} /> {t('Language', 'اللغة')}
                </label>
                <select value={form.preferred_language} onChange={e => setForm(p => ({ ...p, preferred_language: e.target.value }))} className="input">
                  <option value="en">English</option>
                  <option value="ar">العربية</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  <Wallet style={{ width: 14, height: 14 }} /> {t('Currency', 'العملة')}
                </label>
                <select value={form.preferred_currency} onChange={e => setForm(p => ({ ...p, preferred_currency: e.target.value }))} className="input">
                  {['USD', 'EGP', 'EUR', 'GBP', 'SAR', 'AED', 'JPY'].map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>

            <button onClick={handleSave} disabled={saving} className="btn-primary"
              style={{ width: '100%', padding: '0.85rem', fontSize: '0.95rem', justifyContent: 'center', opacity: saving ? 0.7 : 1 }}>
              {saving ? <Loader2 className="animate-spin" style={{ width: 16, height: 16 }} /> : <Save style={{ width: 16, height: 16 }} />}
              {saving ? t('Saving...', 'جاري الحفظ...') : t('Save Changes', 'حفظ التغييرات')}
            </button>
          </div>
        </div>

        <div style={{ ...cardStyle, marginBottom: '1.25rem' }}>
          <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '1rem' }}>
            {t('Quick Access', 'وصول سريع')}
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {[
              { href: '/favorites', icon: Heart, label: t('Saved Places', 'الأماكن المحفوظة'), color: '#e74c3c' },
              { href: '/hotels', icon: Hotel, label: t('Browse Hotels', 'تصفح الفنادق'), color: '#c8860a' },
              { href: '/attractions', icon: Compass, label: t('Browse Attractions', 'تصفح المعالم'), color: '#27ae60' },
              { href: '/planner', icon: CalendarDays, label: t('Trip Planner', 'مخطط الرحلة'), color: '#3498db' },
              ...(isAdmin ? [{ href: '/admin', icon: Shield, label: t('Admin Panel', 'لوحة الإدارة'), color: '#9b59b6' }] : []),
            ].map(item => (
              <Link key={item.href} href={item.href} style={{
                display: 'flex', alignItems: 'center', gap: '0.85rem',
                padding: '0.85rem 1rem', borderRadius: '0.75rem',
                background: 'var(--bg-section)', border: '1px solid var(--border-light)',
                textDecoration: 'none', color: 'inherit', transition: 'all 0.15s',
              }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '0.6rem',
                  background: `${item.color}1a`, color: item.color,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <item.icon style={{ width: 18, height: 18 }} />
                </div>
                <span style={{ flex: 1, fontWeight: 600, color: 'var(--text-dark)', fontSize: '0.9rem' }}>{item.label}</span>
                <ChevronRight style={{ width: 16, height: 16, color: 'var(--text-muted)', transform: isAr ? 'scaleX(-1)' : undefined }} />
              </Link>
            ))}
          </div>
        </div>

        <button onClick={handleSignOut} style={{
          width: '100%', padding: '0.95rem', borderRadius: '0.85rem',
          border: '1px solid #e74c3c', background: 'transparent',
          color: '#e74c3c', fontWeight: 700, fontSize: '0.95rem',
          cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
          fontFamily: 'inherit', transition: 'all 0.15s',
        }}
        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(231,76,60,0.08)'; }}
        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}>
          <LogOut style={{ width: 16, height: 16 }} />
          {t('Sign Out', 'تسجيل الخروج')}
        </button>
      </div>
    </div>
  );
}
