'use client';

import { useLang } from '@/contexts/LanguageContext';
import { Code, Database, Globe, Palette, Map, Mail } from 'lucide-react';

const team = [
  { name: 'Fady Khaled', role_en: 'Full Stack Developer', role_ar: 'مطور متكامل', avatar: 'FK' },
];

const techStack = [
  { name: 'Next.js 15', icon: Code, color: '#000' },
  { name: 'TypeScript', icon: Code, color: '#3178c6' },
  { name: 'Tailwind CSS', icon: Palette, color: '#06b6d4' },
  { name: 'Supabase', icon: Database, color: '#3ecf8e' },
  { name: 'Leaflet', icon: Map, color: '#199900' },
  { name: 'Framer Motion', icon: Globe, color: '#bb4b96' },
];

export default function AboutPage() {
  const { t } = useLang();

  return (
    <div style={{ minHeight: '100vh', paddingTop: '100px' }}>
      <section className="py-20 px-6 text-center" style={{ background: 'linear-gradient(135deg, var(--primary), var(--accent))' }}>
        <img src="/logo-white.svg" alt="" className="w-16 h-16 mx-auto mb-4" />
        <h1 className="text-4xl font-black text-white mb-3">{t('About Cairo Trip', 'عن رحلتك في القاهرة')}</h1>
        <p className="text-white/80 text-lg max-w-2xl mx-auto">{t('Helping travelers discover and plan the perfect Cairo adventure since 2024.', 'نساعد المسافرين في اكتشاف وتخطيط المغامرة المثالية في القاهرة.')}</p>
      </section>

      <section className="py-16 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="section-title">{t('Our Mission', 'مهمتنا')}</h2>
          <p className="text-text-body text-lg leading-relaxed">{t(
            'Cairo is one of the most incredible travel destinations in the world, but planning a trip there can be overwhelming. We built Cairo Trip to simplify the entire process. Enter your budget, browse hotels and attractions, build a day-by-day itinerary, and get emergency help when you need it. Everything a traveler needs, in one place.',
            'القاهرة واحدة من أروع الوجهات السياحية في العالم، لكن التخطيط لرحلة قد يكون مرهقًا. بنينا رحلتك في القاهرة لتبسيط العملية بالكامل. أدخل ميزانيتك، تصفح الفنادق والمعالم، أنشئ برنامجًا يوميًا، واحصل على المساعدة الطارئة عند الحاجة. كل ما يحتاجه المسافر في مكان واحد.'
          )}</p>
        </div>
      </section>

      <section className="py-16 px-6 bg-bg-section">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="section-title">{t('The Team', 'الفريق')}</h2>
          <p className="section-subtitle">{t('The people behind the project', 'الأشخاص وراء المشروع')}</p>
          <div className="flex flex-wrap justify-center gap-6">
            {team.map(member => (
              <div key={member.name} className="bg-bg-card border border-border rounded-2xl p-6 w-64 text-center hover:-translate-y-2 transition-all shadow-sm">
                <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center text-2xl font-black text-white" style={{ background: 'linear-gradient(135deg, var(--primary), var(--accent))' }}>
                  {member.avatar}
                </div>
                <h3 className="font-bold text-text-dark text-lg">{member.name}</h3>
                <p className="text-text-muted text-sm">{t(member.role_en, member.role_ar)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="section-title">{t('Built With', 'بُني بـ')}</h2>
          <div className="flex flex-wrap justify-center gap-4 mt-6">
            {techStack.map(tech => (
              <div key={tech.name} className="flex items-center gap-2 px-5 py-3 rounded-xl border border-border bg-bg-card text-sm font-bold text-text-dark hover:-translate-y-1 transition-all">
                <tech.icon className="w-5 h-5" style={{ color: tech.color }} />
                {tech.name}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6 bg-bg-section">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="section-title">{t('Get in Touch', 'تواصل معنا')}</h2>
          <p className="text-text-body mb-6">{t('Have questions or feedback? We would love to hear from you.', 'عندك أسئلة أو ملاحظات؟ نحب نسمع منك.')}</p>
          <a href="mailto:hello@egypttripplanner.com" className="btn-primary text-lg no-underline"><Mail className="w-5 h-5" /> hello@egypttripplanner.com</a>
        </div>
      </section>
    </div>
  );
}
