'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LanguageContext';
import {
  Hotel, Compass, CalendarDays, Wallet, MessageSquare, Bookmark, Mail,
  Clock, ArrowRight, MapPin, Shield, Loader2, Heart, UtensilsCrossed,
  Settings, Sparkles, Plus, Ticket, Eye, Headphones,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Booking, SavedPlace } from '@/types/database';
import SmartImage from '@/components/SmartImage';

interface TicketRow {
  id: string;
  visit_date: string;
  num_people: number;
  total_price_usd: number;
  status: string;
  created_at: string;
  attraction?: { name: string; image_url?: string } | null;
}

const quickLinks = [
  { href: '/hotels', icon: Hotel, label_en: 'Hotels', label_ar: 'فنادق', desc_en: 'Find & book hotels', desc_ar: 'ابحث واحجز فنادق', color: '#c8860a' },
  { href: '/attractions', icon: Compass, label_en: 'Attractions', label_ar: 'معالم', desc_en: 'Explore Cairo', desc_ar: 'استكشف القاهرة', color: '#27ae60' },
  { href: '/restaurants', icon: UtensilsCrossed, label_en: 'Food', label_ar: 'مطاعم', desc_en: 'Where to eat', desc_ar: 'أين تأكل', color: '#e67e22' },
  { href: '/planner', icon: CalendarDays, label_en: 'Trip Planner', label_ar: 'خطط رحلة', desc_en: 'Day-by-day itinerary', desc_ar: 'برنامج يوم بيوم', color: '#3498db' },
  { href: '/discover', icon: MapPin, label_en: 'Discover', label_ar: 'اكتشف', desc_en: 'Interactive map', desc_ar: 'خريطة تفاعلية', color: '#9b59b6' },
  { href: '/favorites', icon: Heart, label_en: 'Saved', label_ar: 'المفضلة', desc_en: 'Your bookmarks', desc_ar: 'علاماتك', color: '#e74c3c' },
];

export default function DashboardPage() {
  const { user, profile, isAdmin, loading: authLoading } = useAuth();
  const { t, lang } = useLang();
  const router = useRouter();
  const isAr = lang === 'ar';
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [tickets, setTickets] = useState<TicketRow[]>([]);
  const [savedPlaces, setSavedPlaces] = useState<SavedPlace[]>([]);
  const [stats, setStats] = useState({ hotels: 0, attractions: 0, restaurants: 0, cities: 0 });

  useEffect(() => {
    if (!authLoading && !user) router.push('/auth/login');
  }, [user, authLoading, router]);

  useEffect(() => {
    if (user) {
      supabase.from('bookings').select('*, hotel:hotels(name, image_urls)').eq('user_id', user.id).order('created_at', { ascending: false }).limit(10)
        .then(({ data }) => { if (data) setBookings(data as unknown as Booking[]); });
      supabase.from('tickets').select('id, visit_date, num_people, total_price_usd, status, created_at, attraction:attractions(name, image_url)').eq('user_id', user.id).order('created_at', { ascending: false }).limit(10)
        .then(({ data }) => { if (data) setTickets(data as unknown as TicketRow[]); });
      supabase.from('saved_places').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(8)
        .then(({ data }) => { if (data) setSavedPlaces(data); });
    }
    Promise.all([
      supabase.from('hotels').select('id', { count: 'exact', head: true }),
      supabase.from('attractions').select('id', { count: 'exact', head: true }),
      supabase.from('restaurants').select('id', { count: 'exact', head: true }),
      supabase.from('cities').select('id', { count: 'exact', head: true }),
    ]).then(([h, a, r, c]) => {
      setStats({ hotels: h.count || 0, attractions: a.count || 0, restaurants: r.count || 0, cities: c.count || 0 });
    });
  }, [user]);

  if (authLoading || !user) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Loader2 className="animate-spin" style={{ width: 32, height: 32, color: 'var(--primary)' }} />
    </div>
  );

  const greeting = (() => {
    const hour = new Date().getHours();
    if (hour < 12) return t('Good morning', 'صباح الخير');
    if (hour < 18) return t('Good afternoon', 'مساء الخير');
    return t('Good evening', 'مساء الخير');
  })();

  const displayName = profile?.full_name
    || (user.user_metadata as Record<string, string> | undefined)?.full_name
    || user.email?.split('@')[0]
    || t('Traveler', 'مسافر');
  const initials = displayName.trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase()).join('') || 'U';

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>

        <div style={{
          background: 'linear-gradient(135deg, #1a1a1a 0%, #2c1810 50%, #c8860a 150%)',
          borderRadius: '1.5rem', padding: '2rem 2.25rem', marginBottom: '1.5rem',
          color: '#fff', position: 'relative', overflow: 'hidden',
          boxShadow: '0 24px 60px rgba(26,26,26,0.25)',
        }}>
          <div style={{ position: 'absolute', top: -40, insetInlineEnd: -40, width: 220, height: 220, borderRadius: '50%', background: 'radial-gradient(circle, rgba(200,134,10,0.35), transparent 70%)' }} />
          <div style={{ position: 'absolute', bottom: -60, insetInlineStart: 80, width: 180, height: 180, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,0.06), transparent 70%)' }} />

          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%',
                  background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#fff', fontWeight: 900, fontSize: '1.4rem',
                  border: '2px solid rgba(255,255,255,0.25)',
                  overflow: 'hidden',
                }}>
                  {profile?.avatar_url ? (
                    <img src={profile.avatar_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                  ) : initials}
                </div>
                <div>
                  <p style={{ fontSize: '0.82rem', opacity: 0.75, marginBottom: '0.15rem' }}>{greeting}</p>
                  <h1 style={{ fontSize: '1.55rem', fontWeight: 900, lineHeight: 1.1 }}>
                    {displayName}
                  </h1>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                <Link href="/profile" title={t('Edit Profile', 'تعديل الملف')} style={{
                  display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                  padding: '0.55rem 0.85rem', borderRadius: '0.65rem',
                  background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(10px)',
                  color: '#fff', fontSize: '0.82rem', fontWeight: 700,
                  textDecoration: 'none', border: '1px solid rgba(255,255,255,0.15)',
                  transition: 'all 0.2s',
                }}>
                  <Settings style={{ width: 14, height: 14 }} /> {t('Profile', 'الملف')}
                </Link>
                <Link href="/budget" title={t('Budget', 'الميزانية')} style={{
                  display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                  padding: '0.55rem 0.85rem', borderRadius: '0.65rem',
                  background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(10px)',
                  color: '#fff', fontSize: '0.82rem', fontWeight: 700,
                  textDecoration: 'none', border: '1px solid rgba(255,255,255,0.15)',
                }}>
                  <Wallet style={{ width: 14, height: 14 }} /> {t('Budget', 'الميزانية')}
                </Link>
                <Link href="/complaint" title={t('Submit Complaint', 'تقديم شكوى')} style={{
                  display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                  padding: '0.55rem 0.85rem', borderRadius: '0.65rem',
                  background: 'rgba(255,255,255,0.12)', backdropFilter: 'blur(10px)',
                  color: '#fff', fontSize: '0.82rem', fontWeight: 700,
                  textDecoration: 'none', border: '1px solid rgba(255,255,255,0.15)',
                }}>
                  <MessageSquare style={{ width: 14, height: 14 }} /> {t('Help', 'مساعدة')}
                </Link>
                {isAdmin && (
                  <Link href="/admin" title={t('Admin Panel', 'لوحة الإدارة')} style={{
                    display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                    padding: '0.55rem 0.85rem', borderRadius: '0.65rem',
                    background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                    color: '#fff', fontSize: '0.82rem', fontWeight: 700,
                    textDecoration: 'none', border: '1px solid rgba(200,134,10,0.4)',
                    boxShadow: '0 4px 12px rgba(200,134,10,0.4)',
                  }}>
                    <Shield style={{ width: 14, height: 14 }} /> {t('Admin', 'الإدارة')}
                  </Link>
                )}
              </div>
            </div>

            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(110px, 1fr))', gap: '0.85rem',
              padding: '1rem 1.25rem', borderRadius: '1rem',
              background: 'rgba(255,255,255,0.08)', backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255,255,255,0.12)',
            }}>
              {[
                { value: stats.attractions, label: t('Attractions', 'معالم') },
                { value: stats.hotels, label: t('Hotels', 'فنادق') },
                { value: stats.restaurants, label: t('Restaurants', 'مطاعم') },
                { value: stats.cities, label: t('Cities', 'مدن') },
              ].map(s => (
                <div key={s.label} style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '1.65rem', fontWeight: 900, lineHeight: 1, color: '#fff' }}>{s.value}</div>
                  <div style={{ fontSize: '0.72rem', opacity: 0.7, marginTop: '0.15rem' }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.85rem' }}>
            <Sparkles style={{ width: 18, height: 18, color: 'var(--primary)' }} />
            <h2 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)' }}>
              {t('Explore', 'استكشف')}
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(170px, 1fr))', gap: '0.75rem' }}>
            {quickLinks.map(link => (
              <Link key={link.href} href={link.href} style={{
                display: 'flex', flexDirection: 'column', padding: '1.1rem 1rem',
                borderRadius: '1rem', border: '1px solid var(--border)',
                background: 'var(--bg-card)', textDecoration: 'none', color: 'inherit',
                transition: 'all 0.2s ease', position: 'relative', overflow: 'hidden',
              }}
              onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.borderColor = link.color; e.currentTarget.style.boxShadow = `0 8px 24px ${link.color}25`; }}
              onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.boxShadow = ''; }}
              >
                <div style={{
                  width: 42, height: 42, borderRadius: '0.75rem', marginBottom: '0.75rem',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: `linear-gradient(135deg, ${link.color}, ${link.color}cc)`,
                  color: '#fff', boxShadow: `0 6px 16px ${link.color}40`,
                }}>
                  <link.icon style={{ width: 20, height: 20 }} />
                </div>
                <h3 style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.15rem' }}>
                  {t(link.label_en, link.label_ar)}
                </h3>
                <p style={{ fontSize: '0.74rem', color: 'var(--text-muted)' }}>
                  {t(link.desc_en, link.desc_ar)}
                </p>
              </Link>
            ))}
        </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.25rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h2 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Clock style={{ width: 18, height: 18, color: 'var(--primary)' }} />
                {t('Recent Bookings', 'الحجوزات الأخيرة')}
              </h2>
              <Link href="/hotels" style={{
                color: 'var(--primary)', fontSize: '0.78rem', fontWeight: 700,
                textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.2rem',
              }}>
                {t('Book', 'احجز')} <ArrowRight style={{ width: 12, height: 12, transform: isAr ? 'scaleX(-1)' : undefined }} />
              </Link>
            </div>
            {bookings.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '2.25rem 1rem' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%', margin: '0 auto 0.85rem',
                  background: 'rgba(200,134,10,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Hotel style={{ width: 24, height: 24, color: 'var(--primary)', opacity: 0.5 }} />
                </div>
                <p style={{ fontSize: '0.92rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  {t('No bookings yet', 'لا توجد حجوزات بعد')}
                </p>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                  {t('Browse hotels to make your first booking', 'تصفح الفنادق لحجزك الأول')}
                </p>
                <Link href="/hotels" className="btn-primary" style={{ padding: '0.55rem 1.25rem', fontSize: '0.85rem', textDecoration: 'none' }}>
                  <Plus style={{ width: 14, height: 14 }} /> {t('Browse Hotels', 'تصفح الفنادق')}
                </Link>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {bookings.map(b => {
                  const hotel = b.hotel as unknown as { name: string; image_urls: string[] } | undefined;
                  return (
                    <Link key={b.id} href={`/booking/${b.id}`} style={{
                      display: 'flex', alignItems: 'center', gap: '0.75rem',
                      padding: '0.7rem', borderRadius: '0.7rem',
                      background: 'var(--bg-section)', border: '1px solid var(--border-light)',
                      textDecoration: 'none', color: 'inherit', transition: 'all 0.15s',
                    }}>
                      <div style={{ width: 48, height: 48, borderRadius: '0.5rem', overflow: 'hidden', flexShrink: 0 }}>
                        <SmartImage src={hotel?.image_urls?.[0]} alt={hotel?.name || ''} fallbackName={hotel?.name} />
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{hotel?.name}</div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{b.check_in} → {b.check_out} · ${b.total_price_usd}</div>
                      </div>
                      <span style={{
                        fontSize: '0.68rem', fontWeight: 700, padding: '0.25rem 0.6rem', borderRadius: 999,
                        background: b.status === 'confirmed' ? 'rgba(39,174,96,0.12)' : b.status === 'cancelled' ? 'rgba(231,76,60,0.12)' : 'rgba(243,156,18,0.12)',
                        color: b.status === 'confirmed' ? '#27ae60' : b.status === 'cancelled' ? '#e74c3c' : '#f39c12',
                        textTransform: 'uppercase', letterSpacing: '0.04em',
                      }}>
                        {b.status}
                      </span>
                      <Eye style={{ width: 14, height: 14, color: 'var(--primary)' }} />
                    </Link>
                  );
                })}
              </div>
            )}
          </div>

          {/* TICKETS */}
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.25rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h2 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Ticket style={{ width: 18, height: 18, color: '#9b59b6' }} />
                {t('My Tickets', 'تذاكري')}
              </h2>
              <Link href="/attractions" style={{
                color: 'var(--primary)', fontSize: '0.78rem', fontWeight: 700,
                textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.2rem',
              }}>
                {t('Book', 'احجز')} <ArrowRight style={{ width: 12, height: 12, transform: isAr ? 'scaleX(-1)' : undefined }} />
              </Link>
            </div>
            {tickets.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '2.25rem 1rem' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%', margin: '0 auto 0.85rem',
                  background: 'rgba(155,89,182,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Ticket style={{ width: 24, height: 24, color: '#9b59b6', opacity: 0.5 }} />
                </div>
                <p style={{ fontSize: '0.92rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  {t('No tickets yet', 'لا توجد تذاكر بعد')}
                </p>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                  {t('Book attraction tickets ahead of time', 'احجز تذاكر المعالم قبل الزيارة')}
                </p>
                <Link href="/attractions" className="btn-primary" style={{ padding: '0.55rem 1.25rem', fontSize: '0.85rem', textDecoration: 'none' }}>
                  <Compass style={{ width: 14, height: 14 }} /> {t('Browse Attractions', 'تصفح المعالم')}
                </Link>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {tickets.map(tk => (
                  <Link key={tk.id} href={`/ticket/${tk.id}`} style={{
                    display: 'flex', alignItems: 'center', gap: '0.75rem',
                    padding: '0.7rem', borderRadius: '0.7rem',
                    background: 'var(--bg-section)', border: '1px solid var(--border-light)',
                    textDecoration: 'none', color: 'inherit',
                  }}>
                    <div style={{ width: 48, height: 48, borderRadius: '0.5rem', overflow: 'hidden', flexShrink: 0 }}>
                      <SmartImage src={tk.attraction?.image_url} alt={tk.attraction?.name || ''} fallbackName={tk.attraction?.name} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tk.attraction?.name}</div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{tk.visit_date} · {tk.num_people} {t('people', 'أشخاص')} · ${tk.total_price_usd}</div>
                    </div>
                    <span style={{
                      fontSize: '0.68rem', fontWeight: 700, padding: '0.25rem 0.6rem', borderRadius: 999,
                      background: tk.status === 'confirmed' ? 'rgba(39,174,96,0.12)' : tk.status === 'cancelled' ? 'rgba(231,76,60,0.12)' : 'rgba(243,156,18,0.12)',
                      color: tk.status === 'confirmed' ? '#27ae60' : tk.status === 'cancelled' ? '#e74c3c' : '#f39c12',
                      textTransform: 'uppercase', letterSpacing: '0.04em',
                    }}>
                      {tk.status}
                    </span>
                    <Eye style={{ width: 14, height: 14, color: 'var(--primary)' }} />
                  </Link>
                ))}
              </div>
            )}
          </div>

          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.25rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h2 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Heart style={{ width: 18, height: 18, color: '#e74c3c' }} />
                {t('Saved Places', 'الأماكن المحفوظة')}
              </h2>
              <Link href="/favorites" style={{
                color: 'var(--primary)', fontSize: '0.78rem', fontWeight: 700,
                textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.2rem',
              }}>
                {t('View all', 'عرض الكل')} <ArrowRight style={{ width: 12, height: 12, transform: isAr ? 'scaleX(-1)' : undefined }} />
              </Link>
            </div>
            {savedPlaces.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '2.25rem 1rem' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%', margin: '0 auto 0.85rem',
                  background: 'rgba(231,76,60,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Bookmark style={{ width: 24, height: 24, color: '#e74c3c', opacity: 0.5 }} />
                </div>
                <p style={{ fontSize: '0.92rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  {t('Nothing saved yet', 'لا يوجد محفوظ بعد')}
                </p>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                  {t('Tap the heart on any place to save it', 'اضغط القلب على أي مكان لحفظه')}
                </p>
                <Link href="/attractions" className="btn-primary" style={{ padding: '0.55rem 1.25rem', fontSize: '0.85rem', textDecoration: 'none' }}>
                  <Compass style={{ width: 14, height: 14 }} /> {t('Explore', 'استكشف')}
                </Link>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {savedPlaces.map(sp => {
                  const Icon = sp.place_type === 'hotel' ? Hotel : sp.place_type === 'restaurant' ? UtensilsCrossed : Compass;
                  const color = sp.place_type === 'hotel' ? '#c8860a' : sp.place_type === 'restaurant' ? '#e67e22' : '#27ae60';
                  return (
                    <Link key={sp.id} href={`/${sp.place_type}s/${sp.place_id}`} style={{
                      display: 'flex', alignItems: 'center', gap: '0.75rem',
                      padding: '0.7rem', borderRadius: '0.7rem',
                      background: 'var(--bg-section)', border: '1px solid var(--border-light)',
                      textDecoration: 'none', color: 'inherit', transition: 'all 0.15s',
                    }}>
                      <div style={{
                        width: 38, height: 38, borderRadius: '0.55rem', flexShrink: 0,
                        background: `${color}1f`, color,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        <Icon style={{ width: 18, height: 18 }} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-dark)', textTransform: 'capitalize' }}>{sp.place_type}</div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{new Date(sp.created_at).toLocaleDateString()}</div>
                      </div>
                      <ArrowRight style={{ width: 14, height: 14, color: 'var(--text-muted)', transform: isAr ? 'scaleX(-1)' : undefined }} />
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* SUPPORT CTA */}
        <div style={{
          marginTop: '1.5rem',
          background: 'linear-gradient(135deg, #1a1a1a, #2c1810)',
          borderRadius: '1.25rem', padding: '1.5rem 1.75rem',
          color: '#fff',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.25rem' }}>
            <div style={{
              width: 48, height: 48, borderRadius: '50%',
              background: 'linear-gradient(135deg, var(--primary), var(--accent))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Headphones style={{ width: 22, height: 22, color: '#fff' }} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '0.2rem' }}>
                {t('Need help with anything?', 'محتاج مساعدة؟')}
              </h3>
              <p style={{ fontSize: '0.85rem', opacity: 0.75, lineHeight: 1.4 }}>
                {t('Reach our team anytime, we usually reply within 1 hour.', 'تواصل مع فريقنا في أي وقت، عادةً نرد خلال ساعة.')}
              </p>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '0.6rem' }}>
            <a href="https://wa.me/201090000000?text=Hi%20Cairo%20Trip%2C%20I%20need%20help%20with..." target="_blank" rel="noopener" style={{
              padding: '0.85rem 1rem', borderRadius: '0.7rem',
              background: '#25D366', color: '#fff',
              fontWeight: 700, fontSize: '0.9rem', textDecoration: 'none',
              display: 'flex', alignItems: 'center', gap: '0.5rem',
            }}>
              <MessageSquare style={{ width: 16, height: 16 }} />
              <span>WhatsApp · +20 109 000 0000</span>
            </a>
            <a href="mailto:hello@cairotrip.com" style={{
              padding: '0.85rem 1rem', borderRadius: '0.7rem',
              background: 'rgba(255,255,255,0.12)', color: '#fff',
              fontWeight: 700, fontSize: '0.9rem', textDecoration: 'none',
              display: 'flex', alignItems: 'center', gap: '0.5rem',
              border: '1px solid rgba(255,255,255,0.15)',
            }}>
              <Mail style={{ width: 16, height: 16 }} />
              <span>hello@cairotrip.com</span>
            </a>
            <Link href="/complaint" style={{
              padding: '0.85rem 1rem', borderRadius: '0.7rem',
              background: '#fff', color: '#1a1a1a',
              fontWeight: 800, fontSize: '0.9rem', textDecoration: 'none',
              display: 'flex', alignItems: 'center', gap: '0.5rem',
            }}>
              <MessageSquare style={{ width: 16, height: 16 }} />
              <span>{t('Submit a ticket', 'تقديم تذكرة')}</span>
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
