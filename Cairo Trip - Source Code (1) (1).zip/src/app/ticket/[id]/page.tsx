'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { refCode } from '@/lib/refcode';
import { supabase } from '@/lib/supabase';
import {
  CheckCircle2, Clock3, Ticket as TicketIcon, MapPin, CalendarDays,
  Users, Printer, Loader2, Mail, Clock,
} from 'lucide-react';

interface TicketRow {
  id: string;
  visit_date: string;
  num_people: number;
  total_price_usd: number;
  status: string;
  payment_method?: string | null;
  paid_at?: string | null;
  created_at: string;
  attraction?: {
    name: string;
    name_ar?: string;
    description?: string;
    image_url?: string;
    duration_hours?: number;
    opening_hours?: Record<string, string>;
    city?: { name: string; name_ar?: string };
  } | null;
}

export default function PublicTicketPage() {
  const { id } = useParams() as { id: string };
  const [ticket, setTicket] = useState<TicketRow | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      if (!token) { setLoading(false); return; }   // not signed in -> shows not-found card
      try {
        const r = await fetch(`/api/ticket/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setTicket(r.ok ? await r.json() : null);
      } catch { /* ignore */ }
      setLoading(false);
    })();
  }, [id]);

  if (loading) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0a0a0f' }}>
      <Loader2 className="animate-spin" style={{ width: 28, height: 28, color: '#c8860a' }} />
    </div>
  );

  if (!ticket) return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem', background: '#0a0a0f', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{
        maxWidth: 440, padding: '3rem 2rem', textAlign: 'center',
        background: 'rgba(255,255,255,0.05)', backdropFilter: 'blur(20px)',
        border: '1px solid rgba(255,255,255,0.1)', borderRadius: '1.5rem',
      }}>
        <TicketIcon style={{ width: 48, height: 48, color: 'rgba(255,255,255,0.4)', margin: '0 auto 1rem' }} />
        <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#fff', marginBottom: '0.5rem' }}>Ticket not found</h1>
        <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
          This link may be wrong or the ticket was cancelled.
        </p>
        <Link href="/" style={{
          display: 'inline-flex', padding: '0.7rem 1.5rem',
          background: 'linear-gradient(135deg, #c8860a, #8b5e00)',
          color: '#fff', borderRadius: '0.6rem', textDecoration: 'none', fontWeight: 700,
        }}>Back to home</Link>
      </div>
    </div>
  );

  const code = refCode('TKT', ticket.id);
  const isConfirmed = ticket.status === 'confirmed';
  const isCancelled = ticket.status === 'cancelled';
  const fmtDay = (d: string) => new Date(d).toLocaleDateString('en-US', { day: 'numeric' });
  const fmtMonth = (d: string) => new Date(d).toLocaleDateString('en-US', { month: 'short' });
  const fmtWeekday = (d: string) => new Date(d).toLocaleDateString('en-US', { weekday: 'long' });
  const heroImage = ticket.attraction?.image_url || '/images/pyramids.jpg';

  const statusConfig = isCancelled
    ? { bg: 'linear-gradient(135deg, #dc2626, #991b1b)', icon: Clock3, label: 'Cancelled', sub: 'This ticket is no longer valid' }
    : isConfirmed
    ? { bg: 'linear-gradient(135deg, #16a34a, #15803d)', icon: CheckCircle2, label: 'Confirmed', sub: 'Show this ticket at the gate' }
    : { bg: 'linear-gradient(135deg, #c8860a, #8b5e00)', icon: Clock3, label: 'Pending', sub: 'Awaiting payment verification · 24h' };

  const StatusIcon = statusConfig.icon;

  return (
    <div style={{
      minHeight: '100vh',
      position: 'relative',
      padding: '100px 1rem 60px',
      background: '#0a0a0f',
      overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `url(${heroImage})`,
        backgroundSize: 'cover', backgroundPosition: 'center',
        filter: 'blur(40px) brightness(0.35)',
        transform: 'scale(1.15)',
        zIndex: 0,
      }} />
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, rgba(10,10,15,0.55) 0%, rgba(10,10,15,0.9) 70%)',
        zIndex: 0,
      }} />

      <div style={{ position: 'relative', zIndex: 1, maxWidth: 420, margin: '0 auto' }}>

        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
            padding: '0.4rem 0.85rem', borderRadius: 999,
            background: 'rgba(255,255,255,0.08)', backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255,255,255,0.12)',
            color: 'rgba(255,255,255,0.85)', fontSize: '0.72rem',
            letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700,
          }}>
            <TicketIcon style={{ width: 12, height: 12 }} />
            Cairo Trip · Entry Ticket
          </div>
        </div>

        <div style={{
          background: 'rgba(255,255,255,0.06)',
          backdropFilter: 'blur(24px)',
          WebkitBackdropFilter: 'blur(24px)',
          border: '1px solid rgba(255,255,255,0.12)',
          borderRadius: '1.75rem',
          overflow: 'hidden',
          boxShadow: '0 24px 60px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.12)',
        }}>

          <div style={{
            padding: '1.75rem 1.75rem 1.5rem', textAlign: 'center',
            background: statusConfig.bg,
            position: 'relative',
          }}>
            <div style={{
              position: 'absolute', inset: 0,
              background: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.18), transparent 60%)',
              pointerEvents: 'none',
            }} />
            <div style={{ position: 'relative' }}>
              <div style={{
                width: 64, height: 64, margin: '0 auto 0.75rem', borderRadius: '50%',
                background: 'rgba(255,255,255,0.22)', backdropFilter: 'blur(12px)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '1px solid rgba(255,255,255,0.3)',
              }}>
                <StatusIcon style={{ width: 32, height: 32, color: '#fff' }} />
              </div>
              <div style={{ fontSize: '1.65rem', fontWeight: 900, color: '#fff', letterSpacing: '-0.02em' }}>
                {statusConfig.label}
              </div>
              <div style={{ fontSize: '0.8rem', opacity: 0.92, color: '#fff', marginTop: '0.35rem', lineHeight: 1.4 }}>
                {statusConfig.sub}
              </div>
            </div>
          </div>

          <div style={{ padding: '1.5rem 1.75rem 0' }}>
            <div style={{
              padding: '1.1rem', borderRadius: '1rem',
              background: 'rgba(255,255,255,0.06)',
              border: '1px dashed rgba(200,134,10,0.5)',
              textAlign: 'center',
            }}>
              <div style={{
                fontSize: '0.66rem', letterSpacing: '0.12em', textTransform: 'uppercase',
                color: 'rgba(255,255,255,0.55)', fontWeight: 700, marginBottom: '0.35rem',
              }}>
                Ticket Code · Show at gate
              </div>
              <div style={{
                fontSize: '1.85rem', fontWeight: 900, letterSpacing: '0.1em',
                color: '#f4c842', fontFamily: 'monospace',
              }}>{code}</div>
            </div>
          </div>

          <div style={{ padding: '1.5rem 1.75rem 0' }}>
            <h1 style={{
              fontSize: '1.45rem', fontWeight: 900, color: '#fff',
              marginBottom: '0.3rem', letterSpacing: '-0.02em', lineHeight: 1.2,
            }}>
              {ticket.attraction?.name || 'Attraction'}
            </h1>
            <p style={{
              color: 'rgba(255,255,255,0.65)',
              display: 'inline-flex', alignItems: 'center', gap: '0.35rem',
              fontSize: '0.88rem',
            }}>
              <MapPin style={{ width: 14, height: 14 }} />
              {ticket.attraction?.city?.name || 'Cairo'}
              {ticket.attraction?.duration_hours && (
                <>
                  <span style={{ margin: '0 0.3rem', opacity: 0.4 }}>·</span>
                  <Clock style={{ width: 12, height: 12 }} /> ~{ticket.attraction.duration_hours}h
                </>
              )}
            </p>
          </div>

          <div style={{ padding: '1.5rem 1.75rem 0' }}>
            <div style={{
              padding: '1.1rem', borderRadius: '1rem',
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.08)',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
                <div style={{
                  background: 'rgba(244,200,66,0.18)', border: '1px solid rgba(244,200,66,0.35)',
                  padding: '0.4rem 0.7rem', borderRadius: '0.6rem', textAlign: 'center',
                  minWidth: 56,
                }}>
                  <div style={{ fontSize: '0.62rem', color: '#f4c842', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                    {fmtMonth(ticket.visit_date)}
                  </div>
                  <div style={{ fontSize: '1.4rem', fontWeight: 900, color: '#fff', lineHeight: 1 }}>
                    {fmtDay(ticket.visit_date)}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '0.66rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.5)', fontWeight: 700 }}>
                    Visit Date
                  </div>
                  <div style={{ color: '#fff', fontSize: '0.88rem', fontWeight: 700, marginTop: '0.15rem' }}>
                    {fmtWeekday(ticket.visit_date)}
                  </div>
                </div>
              </div>

              <div style={{ textAlign: 'end' }}>
                <div style={{ fontSize: '0.66rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.5)', fontWeight: 700 }}>
                  Tickets
                </div>
                <div style={{
                  fontSize: '1.4rem', fontWeight: 900, color: '#fff', lineHeight: 1, marginTop: '0.15rem',
                  display: 'flex', alignItems: 'center', gap: '0.25rem', justifyContent: 'flex-end',
                }}>
                  <Users style={{ width: 16, height: 16, opacity: 0.6 }} /> {ticket.num_people}
                </div>
                <div style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.5)', marginTop: '0.15rem' }}>
                  {ticket.num_people === 1 ? 'person' : 'people'}
                </div>
              </div>
            </div>
          </div>

          <div style={{ padding: '1.25rem 1.75rem 0' }}>
            <div style={{
              padding: '1rem 1.1rem', borderRadius: '0.9rem',
              background: 'linear-gradient(135deg, rgba(200,134,10,0.25), rgba(139,94,0,0.18))',
              border: '1px solid rgba(200,134,10,0.35)',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div>
                <div style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.65)', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 700 }}>
                  Total paid
                </div>
                {ticket.payment_method && (
                  <div style={{ fontSize: '0.66rem', color: 'rgba(255,255,255,0.5)', marginTop: '0.15rem' }}>
                    via {ticket.payment_method === 'instapay' ? 'InstaPay' : 'Card'}
                  </div>
                )}
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 900, color: '#fff', letterSpacing: '-0.02em' }}>
                ${ticket.total_price_usd}
              </div>
            </div>
          </div>

          <div style={{ padding: '1rem 1.75rem 0' }}>
            <div style={{
              padding: '0.85rem 1rem', borderRadius: '0.7rem',
              background: 'rgba(52,152,219,0.1)', border: '1px solid rgba(52,152,219,0.25)',
              fontSize: '0.78rem', color: 'rgba(255,255,255,0.8)', lineHeight: 1.5,
            }}>
              <strong style={{ color: '#fff' }}>Tip:</strong> Arrive 15 min early, bring photo ID,
              dress modestly for religious sites.
            </div>
          </div>

          <div style={{ padding: '1.25rem 1.75rem 1.5rem', display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button onClick={() => window.print()} style={{
              flex: 1, minWidth: 130, padding: '0.8rem',
              borderRadius: '0.7rem',
              background: 'rgba(255,255,255,0.08)',
              border: '1px solid rgba(255,255,255,0.12)',
              backdropFilter: 'blur(8px)',
              color: '#fff', fontWeight: 700, fontSize: '0.85rem',
              cursor: 'pointer', fontFamily: 'inherit',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
            }}>
              <Printer style={{ width: 14, height: 14 }} /> Save as PDF
            </button>
            <a href="mailto:hello@cairotrip.com" style={{
              flex: 1, minWidth: 130, padding: '0.8rem',
              borderRadius: '0.7rem',
              background: 'rgba(255,255,255,0.08)',
              border: '1px solid rgba(255,255,255,0.12)',
              backdropFilter: 'blur(8px)',
              color: '#fff', fontWeight: 700, fontSize: '0.85rem',
              textDecoration: 'none',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
            }}>
              <Mail style={{ width: 14, height: 14 }} /> Contact support
            </a>
          </div>
        </div>

        <p style={{
          textAlign: 'center', fontSize: '0.7rem', color: 'rgba(255,255,255,0.4)',
          marginTop: '1.5rem', letterSpacing: '0.05em',
        }}>
          Cairo Trip · independent travel guide · cairotrip.com
        </p>
      </div>
    </div>
  );
}
