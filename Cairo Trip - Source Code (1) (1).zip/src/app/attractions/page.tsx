'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { MapPin, Compass, Clock, Users, Loader2, Gift, Star, Navigation } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Attraction, City } from '@/types/database';
import { toEGP } from '@/lib/egp';
import FavoriteButton from '@/components/FavoriteButton';
import SmartImage from '@/components/SmartImage';
import { mapsSearchUrl, mapsDirectionsUrl } from '@/lib/maps';

const allCategories = ['All', 'Ancient', 'Museum', 'Religious', 'Nature', 'Beach', 'Market', 'Entertainment', 'Cultural', 'Historical', 'Landmark'];
const categoryAr: Record<string, string> = {
  All: 'الكل', Ancient: 'قديم', Museum: 'متحف', Religious: 'ديني', Nature: 'طبيعة',
  Beach: 'شاطئ', Market: 'سوق', Entertainment: 'ترفيه', Cultural: 'ثقافي', Historical: 'تاريخي', Landmark: 'معلم',
};

function getCrowdLevel(): { label: string; color: string } {
  const hour = new Date().getHours();
  const day = new Date().getDay();
  const isWeekend = day === 5 || day === 6;
  if (hour < 8 || hour > 20) return { label: 'Low', color: '#27ae60' };
  if (isWeekend && hour >= 10 && hour <= 16) return { label: 'Very Busy', color: '#e74c3c' };
  if (hour >= 10 && hour <= 15) return { label: 'Busy', color: '#f39c12' };
  return { label: 'Moderate', color: '#3498db' };
}

export default function AttractionsPage() {
  const { t, lang } = useLang();
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('All');
  const crowd = getCrowdLevel();

  useEffect(() => {
    async function load() {
      setLoading(true);
      let query = supabase.from('attractions').select('*, city:cities(*)').order('name');
      if (category !== 'All') query = query.eq('category', category);
      const { data } = await query;
      if (data) setAttractions(data as unknown as Attraction[]);
      setLoading(false);
    }
    load();
  }, [category]);

  return (
    <div style={{ minHeight: '100vh', padding: '100px 2rem 4rem' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div className="text-center" style={{ marginBottom: '2.5rem' }}>
          <h1 style={{ fontSize: '2.2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
            <Compass className="w-7 h-7 inline" style={{ color: 'var(--primary)', marginInlineEnd: '0.5rem' }} />
            {t('Attractions in Cairo', 'معالم سياحية في القاهرة')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '1rem' }}>
            {t('Pyramids, museums, mosques and more', 'الأهرامات، المتاحف، المساجد وأكثر')}
          </p>
        </div>

        <div className="filter-chips" style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', justifyContent: 'center', marginBottom: '2rem' }}>
          {allCategories.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              style={{
                padding: '0.5rem 1.25rem',
                borderRadius: '50px',
                fontSize: '0.9rem',
                fontWeight: 700,
                fontFamily: 'Cairo',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                border: category === cat ? '2px solid var(--primary)' : '2px solid var(--border)',
                background: category === cat ? 'linear-gradient(135deg, var(--primary), var(--accent))' : 'var(--bg-card)',
                color: category === cat ? '#fff' : 'var(--text-body)',
              }}
            >
              {lang === 'ar' ? categoryAr[cat] || cat : cat}
            </button>
          ))}
        </div>

        <div className="locations-grid">
          {attractions.map((attr, i) => (
            <Link
              key={attr.id}
              href={`/attractions/${attr.id}`}
              className="card"
              style={{ animationDelay: `${i * 0.1}s`, display: 'block', textDecoration: 'none', color: 'inherit' }}
            >
              <div style={{ height: 160, overflow: 'hidden', position: 'relative' }}>
                <SmartImage src={attr.image_url} alt={attr.name} fallbackName={attr.name} />
                <FavoriteButton type="attraction" id={attr.id} />
                <div style={{
                  position: 'absolute', top: '0.75rem', insetInlineEnd: '0.75rem',
                  padding: '0.25rem 0.65rem', borderRadius: '50px',
                  fontSize: '0.75rem', fontWeight: 700, color: '#fff',
                  background: crowd.color, display: 'flex', alignItems: 'center', gap: '0.3rem',
                }}>
                  <Users className="w-3 h-3" /> {crowd.label}
                </div>
              </div>
              <div style={{ padding: '1.25rem 1.5rem 0.5rem', position: 'relative' }}>
                <span className="card-number">{i + 1}</span>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                  {lang === 'ar' ? (attr as unknown as {name_ar: string}).name_ar || attr.name : attr.name}
                  {(attr as unknown as { is_must_visit?: boolean }).is_must_visit && (
                    <Star className="w-4 h-4 inline" style={{ color: 'var(--primary)', marginInlineStart: '0.3rem' }} />
                  )}
                </h3>
                <span style={{
                  display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                  color: 'var(--text-muted)', fontSize: '0.82rem',
                  background: 'var(--bg-section)', padding: '0.25rem 0.65rem', borderRadius: '8px',
                }}>
                  <MapPin className="w-3 h-3" /> {lang === 'ar' ? (attr.city as unknown as City)?.name_ar : (attr.city as unknown as City)?.name || ''}
                </span>
              </div>
              <div style={{ padding: '0.75rem 1.5rem 1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                  {attr.entry_fee_usd === 0 ? (
                    <span style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--success)' }}>
                      <Gift className="w-4 h-4 inline" style={{ marginInlineEnd: '0.3rem' }} />
                      {t('Free', 'مجاني')}
                    </span>
                  ) : (
                    <>
                      <span style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary)' }}>${attr.entry_fee_usd}</span>
                      <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{t('entry', 'دخول')}</span>
                      <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', background: 'var(--bg-section)', padding: '0.1rem 0.4rem', borderRadius: '6px' }}>{toEGP(attr.entry_fee_usd)} EGP</span>
                    </>
                  )}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                  <Clock className="w-3 h-3" /> {attr.duration_hours} {t('hours', 'ساعات')}
                </div>
                {attr.description && (
                  <div className="card-notes" style={{ marginTop: '0.75rem' }}>
                    {(() => { const desc = lang === 'ar' ? (attr as unknown as {description_ar?: string}).description_ar || attr.description : attr.description; return desc ? (desc.slice(0, 100) + (desc.length > 100 ? '...' : '')) : ''; })()}
                  </div>
                )}
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.85rem' }}>
                  {(() => {
                    const cityName = (attr.city as unknown as City)?.name;
                    const stop = (e: React.MouseEvent) => e.stopPropagation();
                    return (
                      <>
                        <a
                          href={mapsSearchUrl(attr.name, cityName)}
                          target="_blank" rel="noopener noreferrer" onClick={stop}
                          style={{
                            flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                            padding: '0.55rem 0.75rem', borderRadius: '0.6rem',
                            background: 'var(--bg-section)', border: '1px solid var(--border)',
                            color: 'var(--text-dark)', fontSize: '0.8rem', fontWeight: 700,
                            textDecoration: 'none', transition: 'all 0.2s',
                          }}
                        >
                          <MapPin style={{ width: 14, height: 14, color: 'var(--primary)' }} /> {t('Map', 'خريطة')}
                        </a>
                        <a
                          href={mapsDirectionsUrl(attr.name, cityName)}
                          target="_blank" rel="noopener noreferrer" onClick={stop}
                          style={{
                            flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                            padding: '0.55rem 0.75rem', borderRadius: '0.6rem',
                            background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                            border: 'none', color: '#fff', fontSize: '0.8rem', fontWeight: 700,
                            textDecoration: 'none', transition: 'all 0.2s',
                          }}
                        >
                          <Navigation style={{ width: 14, height: 14 }} /> {t('Directions', 'الاتجاهات')}
                        </a>
                      </>
                    );
                  })()}
                </div>
              </div>
            </Link>
          ))}
        </div>

        {attractions.length === 0 && !loading && (
          <div style={{ textAlign: 'center', padding: '4rem 2rem' }}>
            <Compass className="w-16 h-16" style={{ margin: '0 auto 1.5rem', color: 'var(--primary)', opacity: 0.4 }} />
            <h2 style={{ fontSize: '1.4rem', color: 'var(--text-body)' }}>{t('No attractions found', 'لا توجد معالم')}</h2>
          </div>
        )}

        {loading && (
          <div style={{ textAlign: 'center', padding: '4rem' }}>
            <Loader2 className="w-8 h-8 animate-spin" style={{ margin: '0 auto', color: 'var(--primary)' }} />
          </div>
        )}
      </div>
    </div>
  );
}
