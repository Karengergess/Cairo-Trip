'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { MapPin, Navigation, Clock, DollarSign, Users, CloudSun, ArrowLeft, Ticket } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Attraction, City } from '@/types/database';
import { toEGP } from '@/lib/egp';
import FavoriteButton from '@/components/FavoriteButton';
import SmartImage from '@/components/SmartImage';
import { mapsSearchUrl, mapsDirectionsUrl } from '@/lib/maps';

function getCrowdLevel(): { label: string; color: string; desc: string } {
  const hour = new Date().getHours();
  const day = new Date().getDay();
  const isWeekend = day === 5 || day === 6;
  if (hour < 8 || hour > 20) return { label: 'Low', color: '#27ae60', desc: 'Few visitors right now' };
  if (isWeekend && hour >= 10 && hour <= 16) return { label: 'Very Busy', color: '#e74c3c', desc: 'Peak hours on weekend' };
  if (hour >= 10 && hour <= 15) return { label: 'Busy', color: '#f39c12', desc: 'Moderate to high traffic' };
  return { label: 'Moderate', color: '#3498db', desc: 'Average visitor count' };
}

export default function AttractionDetailPage() {
  const { id } = useParams() as { id: string };
  const { t, lang } = useLang();
  const [attr, setAttr] = useState<Attraction | null>(null);
  const [weather, setWeather] = useState<{ temp: number; desc: string; icon: string } | null>(null);
  const crowd = getCrowdLevel();

  useEffect(() => {
    supabase.from('attractions').select('*, city:cities(*)').eq('id', id).single()
      .then(({ data }) => {
        const item = data as unknown as Attraction | null;
        if (item) {
          setAttr(item);
          const key = process.env.NEXT_PUBLIC_OPENWEATHER_KEY;
          if (key) {
            fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${item.latitude}&lon=${item.longitude}&units=metric&appid=${key}`)
              .then(r => r.json()).then(w => {
                if (w.main) setWeather({ temp: Math.round(w.main.temp), desc: w.weather[0].description, icon: w.weather[0].icon });
              }).catch(() => {});
          }
        }
      });
  }, [id]);

  if (!attr) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
      {t('Loading...', 'جاري التحميل...')}
    </div>
  );

  const city = attr.city as unknown as City;
  const mapsUrl = mapsDirectionsUrl(attr.name, city?.name);
  const mapsViewUrl = mapsSearchUrl(attr.name, city?.name);
  const ticketUrl = `/tickets/${attr.id}`;
  const isPaidEntry = attr.entry_fee_usd > 0;
  const isAr = lang === 'ar';

  const cardStyle: React.CSSProperties = {
    background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.25rem',
  };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.5rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <Link href="/attractions" style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
          color: 'var(--primary)', fontWeight: 700, fontSize: '0.92rem',
          textDecoration: 'none', marginBottom: '1.5rem',
        }}>
          <ArrowLeft style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} />
          {t('Back to Attractions', 'العودة للمعالم')}
        </Link>

        <div style={{
          height: 360, borderRadius: '1.25rem', overflow: 'hidden', marginBottom: '1.75rem',
          position: 'relative', border: '1px solid var(--border)',
        }}>
          <SmartImage src={attr.image_url} alt={attr.name} fallbackName={attr.name} loading="eager" />
          <div style={{ position: 'absolute', top: '1rem', insetInlineStart: '1rem', zIndex: 5 }}>
            <FavoriteButton type="attraction" id={attr.id} variant="inline" size="lg" stopProp={false} />
          </div>
          <div style={{
            position: 'absolute', top: '1rem', insetInlineEnd: '1rem',
            padding: '0.4rem 0.85rem', borderRadius: 999, color: '#fff',
            fontSize: '0.85rem', fontWeight: 700, background: crowd.color,
            display: 'flex', alignItems: 'center', gap: '0.4rem',
            boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
          }}>
            <Users style={{ width: 16, height: 16 }} /> {crowd.label}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(280px, 1fr)', gap: '1.5rem' }} className="detail-grid">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', minWidth: 0 }}>
            <div>
              <span style={{
                display: 'inline-block', fontSize: '0.78rem', fontWeight: 700,
                padding: '0.3rem 0.75rem', borderRadius: 999,
                background: 'rgba(200, 134, 10, 0.12)', color: 'var(--primary)',
                marginBottom: '0.75rem',
              }}>{attr.category}</span>
              <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem', lineHeight: 1.2 }}>
                {isAr ? (attr as unknown as { name_ar?: string }).name_ar || attr.name : attr.name}
              </h1>
              <p style={{
                color: 'var(--text-muted)', display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                fontSize: '0.95rem',
              }}>
                <MapPin style={{ width: 16, height: 16 }} /> {isAr ? city?.name_ar : city?.name}
              </p>
            </div>

            {attr.description && (
              <div style={cardStyle}>
                <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.6rem', fontSize: '1.1rem' }}>
                  {t('About', 'عن المكان')}
                </h2>
                <p style={{ color: 'var(--text-body)', lineHeight: 1.7, fontSize: '0.95rem' }}>
                  {isAr ? (attr as unknown as { description_ar?: string }).description_ar || attr.description : attr.description}
                </p>
              </div>
            )}

            <div className="info-grid" style={{
              display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.75rem',
            }}>
              <div style={{ ...cardStyle, padding: '1rem', textAlign: 'center' }}>
                <DollarSign style={{ width: 22, height: 22, color: 'var(--primary)', margin: '0 auto 0.4rem' }} />
                <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-dark)' }}>
                  {attr.entry_fee_usd > 0 ? `$${attr.entry_fee_usd}` : t('Free', 'مجاني')}
                </div>
                {attr.entry_fee_usd > 0 && (
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{toEGP(attr.entry_fee_usd)} EGP</div>
                )}
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                  {t('Entry Fee', 'رسم الدخول')}
                </div>
              </div>
              <div style={{ ...cardStyle, padding: '1rem', textAlign: 'center' }}>
                <Clock style={{ width: 22, height: 22, color: 'var(--primary)', margin: '0 auto 0.4rem' }} />
                <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-dark)' }}>{attr.duration_hours}h</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                  {t('Duration', 'المدة')}
                </div>
              </div>
              <div style={{ ...cardStyle, padding: '1rem', textAlign: 'center' }}>
                <Users style={{ width: 22, height: 22, color: crowd.color, margin: '0 auto 0.4rem' }} />
                <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-dark)' }}>{crowd.label}</div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                  {t('Crowd Now', 'الازدحام')}
                </div>
              </div>
              <div style={{ ...cardStyle, padding: '1rem', textAlign: 'center' }}>
                <MapPin style={{ width: 22, height: 22, color: 'var(--primary)', margin: '0 auto 0.4rem' }} />
                <div style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-dark)' }}>
                  {isAr ? city?.name_ar : city?.name}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                  {t('City', 'المدينة')}
                </div>
              </div>
            </div>

            {attr.opening_hours && (
              <div style={cardStyle}>
                <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.75rem', fontSize: '1.05rem' }}>
                  {t('Opening Hours', 'مواعيد العمل')}
                </h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                  {Object.entries(attr.opening_hours).map(([day, hours]) => (
                    <div key={day} style={{
                      display: 'flex', justifyContent: 'space-between',
                      background: 'var(--bg-section)', borderRadius: '0.6rem',
                      padding: '0.5rem 0.85rem', fontSize: '0.88rem',
                    }}>
                      <span style={{ fontWeight: 700, color: 'var(--text-dark)', textTransform: 'capitalize' }}>{day}</span>
                      <span style={{ color: 'var(--text-muted)' }}>{hours as string}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {isPaidEntry ? (
              <Link href={ticketUrl} className="btn-primary"
                style={{ padding: '0.9rem 1rem', justifyContent: 'center', textDecoration: 'none', fontSize: '0.95rem' }}>
                <Ticket style={{ width: 18, height: 18 }} /> {t('Book Tickets', 'احجز تذاكر')}
              </Link>
            ) : (
              <div style={{
                padding: '0.85rem 1rem', borderRadius: '0.85rem',
                background: 'rgba(39,174,96,0.1)', border: '1px solid rgba(39,174,96,0.3)',
                color: 'var(--success)', textAlign: 'center', fontWeight: 700, fontSize: '0.9rem',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
              }}>
                <Ticket style={{ width: 18, height: 18 }} /> {t('Free entry, no booking needed', 'دخول مجاني، مفيش حاجة للحجز')}
              </div>
            )}

            <a href={mapsViewUrl} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.9rem 1rem', borderRadius: '0.9rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                textDecoration: 'none', color: 'inherit', transition: 'all 0.2s',
              }}>
              <MapPin style={{ width: 22, height: 22, color: 'var(--primary)', flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>
                  {t('Open in Google Maps', 'افتح في خرائط جوجل')}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                  {t('View location', 'عرض الموقع')}
                </div>
              </div>
            </a>

            <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.9rem 1rem', borderRadius: '0.9rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                textDecoration: 'none', color: 'inherit', transition: 'all 0.2s',
              }}>
              <Navigation style={{ width: 22, height: 22, color: 'var(--primary)', flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>
                  {t('Get Directions', 'الاتجاهات')}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                  {t('Navigate from your location', 'من موقعك الحالي')}
                </div>
              </div>
            </a>

            {weather && (
              <div style={cardStyle}>
                <h3 style={{
                  fontWeight: 700, fontSize: '0.85rem', marginBottom: '0.5rem',
                  display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-dark)',
                }}>
                  <CloudSun style={{ width: 16, height: 16, color: 'var(--primary)' }} />
                  {t('Current Weather', 'الطقس الحالي')}
                </h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <img src={`https://openweathermap.org/img/wn/${weather.icon}@2x.png`} alt=""
                    style={{ width: 48, height: 48 }} />
                  <div>
                    <div style={{ fontSize: '1.5rem', fontWeight: 900, color: 'var(--text-dark)' }}>{weather.temp}°C</div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>{weather.desc}</div>
                  </div>
                </div>
              </div>
            )}

            <div style={{
              padding: '1rem', borderRadius: '0.9rem',
              border: '1px solid var(--border)',
              background: `${crowd.color}1a`,
            }}>
              <h3 style={{ fontWeight: 700, fontSize: '0.85rem', marginBottom: '0.3rem', color: crowd.color }}>
                {t('Crowd Estimate', 'تقدير الازدحام')}
              </h3>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-body)', lineHeight: 1.5 }}>{crowd.desc}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
