'use client';

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useLang } from '@/contexts/LanguageContext';
import { UtensilsCrossed, MapPin, Star, Loader2, Navigation } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Restaurant, City } from '@/types/database';
import FavoriteButton from '@/components/FavoriteButton';
import SmartImage from '@/components/SmartImage';
import { mapsSearchUrl, mapsDirectionsUrl } from '@/lib/maps';

const cuisines = ['All', 'Egyptian', 'Seafood', 'Italian', 'Street Food', 'Mediterranean', 'Fine Dining', 'Thai', 'Nubian'];
const cuisineAr: Record<string, string> = {
  All: 'الكل', Egyptian: 'مصري', Seafood: 'مأكولات بحرية', Italian: 'إيطالي',
  'Street Food': 'أكل شعبي', Mediterranean: 'متوسطي', 'Fine Dining': 'مطبخ راقي',
  Thai: 'تايلاندي', Nubian: 'نوبي',
};

function priceLabel(level: number) {
  return '$'.repeat(level) + (level < 4 ? ' '.repeat((4 - level) * 2) : '');
}

function RestaurantsContent() {
  const { t, lang } = useLang();
  const searchParams = useSearchParams();
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  const [cuisine, setCuisine] = useState('All');
  const [cityFilter, setCityFilter] = useState(searchParams.get('city') || '');
  const [maxPrice, setMaxPrice] = useState(4);

  useEffect(() => {
    supabase.from('cities').select('*').then(({ data }) => { if (data) setCities(data); });
  }, []);

  useEffect(() => {
    async function load() {
      setLoading(true);
      let query = supabase.from('restaurants').select('*, city:cities(*)').lte('price_range', maxPrice).order('rating', { ascending: false });
      if (cuisine !== 'All') query = query.eq('cuisine', cuisine);
      if (cityFilter) {
        const cityRow = cities.find(c => c.slug === cityFilter);
        if (cityRow) query = query.eq('city_id', cityRow.id);
      }
      const { data } = await query;
      if (data) setRestaurants(data as unknown as Restaurant[]);
      setLoading(false);
    }
    if (cities.length > 0 || cityFilter === '') load();
  }, [cuisine, cityFilter, maxPrice, cities]);

  const isAr = lang === 'ar';

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.5rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: 56, height: 56, borderRadius: '1rem', margin: '0 auto 1rem',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'linear-gradient(135deg, var(--primary), var(--accent))',
          }}>
            <UtensilsCrossed style={{ width: 28, height: 28, color: '#fff' }} />
          </div>
          <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Restaurants in Cairo', 'مطاعم في القاهرة')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
            {t('Find authentic flavors and unforgettable meals', 'اكتشف أطعم النكهات الأصيلة')}
          </p>
        </div>

        <div className="budget-form-card" style={{ maxWidth: '100%', marginBottom: '1.25rem', padding: '1.25rem' }}>
          <div className="filter-row" style={{ display: 'flex', flexWrap: 'wrap', gap: '0.85rem', alignItems: 'end' }}>
            <div style={{ flex: 1, minWidth: 160 }}>
              <label className="form-label">{t('City', 'المدينة')}</label>
              <select value={cityFilter} onChange={e => setCityFilter(e.target.value)} className="input">
                <option value="">{t('All Cities', 'كل المدن')}</option>
                {cities.map(c => <option key={c.id} value={c.slug}>{isAr ? c.name_ar : c.name}</option>)}
              </select>
            </div>
            <div style={{ minWidth: 150 }}>
              <label className="form-label">{t('Max Price', 'أقصى سعر')}</label>
              <select value={maxPrice} onChange={e => setMaxPrice(Number(e.target.value))} className="input">
                <option value={1}>$ - {t('Cheap', 'رخيص')}</option>
                <option value={2}>$$ - {t('Affordable', 'مناسب')}</option>
                <option value={3}>$$$ - {t('Upscale', 'راقي')}</option>
                <option value={4}>$$$$ - {t('All', 'الكل')}</option>
              </select>
            </div>
          </div>
        </div>

        <div className="filter-chips" style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', justifyContent: 'center', marginBottom: '2rem' }}>
          {cuisines.map(c => (
            <button key={c} onClick={() => setCuisine(c)}
              style={{
                padding: '0.5rem 1.1rem', borderRadius: '50px',
                fontSize: '0.85rem', fontWeight: 700, fontFamily: 'inherit',
                cursor: 'pointer', transition: 'all 0.2s',
                border: cuisine === c ? '2px solid var(--primary)' : '2px solid var(--border)',
                background: cuisine === c ? 'linear-gradient(135deg, var(--primary), var(--accent))' : 'var(--bg-card)',
                color: cuisine === c ? '#fff' : 'var(--text-body)',
              }}>
              {isAr ? (cuisineAr[c] || c) : c}
            </button>
          ))}
        </div>

        {loading && (
          <div style={{ textAlign: 'center', padding: '4rem' }}>
            <Loader2 className="animate-spin" style={{ width: 32, height: 32, color: 'var(--primary)', margin: '0 auto' }} />
          </div>
        )}

        {!loading && restaurants.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem 2rem', background: 'var(--bg-card)', borderRadius: '1.25rem', border: '1px solid var(--border)' }}>
            <UtensilsCrossed style={{ width: 56, height: 56, color: 'var(--primary)', opacity: 0.4, margin: '0 auto 1rem' }} />
            <h2 style={{ fontSize: '1.2rem', color: 'var(--text-dark)', fontWeight: 800 }}>
              {t('No restaurants found', 'لا توجد مطاعم')}
            </h2>
          </div>
        )}

        <div className="locations-grid">
          {restaurants.map((r, i) => {
            const city = r.city;
            const stop = (e: React.MouseEvent) => e.stopPropagation();
            const mapsUrl = mapsSearchUrl(r.name, city?.name);
            const dirUrl = mapsDirectionsUrl(r.name, city?.name);
            return (
              <Link key={r.id} href={`/restaurants/${r.id}`} className="card"
                style={{ animationDelay: `${i * 0.08}s`, display: 'block', textDecoration: 'none', color: 'inherit' }}>
                <div style={{ height: 160, overflow: 'hidden', position: 'relative' }}>
                  <SmartImage src={r.image_url} alt={r.name} fallbackName={r.name} />
                  <FavoriteButton type="restaurant" id={r.id} />
                  <div style={{
                    position: 'absolute', top: '0.75rem', insetInlineEnd: '0.75rem',
                    padding: '0.3rem 0.7rem', borderRadius: '50px', fontSize: '0.7rem',
                    fontWeight: 800, color: '#fff', background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)',
                  }}>
                    {priceLabel(r.price_range).trim()}
                  </div>
                </div>
                <div style={{ padding: '1rem 1.25rem 0.5rem', position: 'relative' }}>
                  <span className="card-number">{i + 1}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
                    <span style={{
                      fontSize: '0.7rem', fontWeight: 700,
                      padding: '0.18rem 0.55rem', borderRadius: '0.5rem',
                      background: 'rgba(200,134,10,0.12)', color: 'var(--primary)',
                    }}>{isAr ? (r.cuisine_ar || r.cuisine) : r.cuisine}</span>
                    {r.rating && (
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.2rem', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                        <Star style={{ width: 12, height: 12, color: 'var(--primary)', fill: 'var(--primary)' }} /> {r.rating}
                      </span>
                    )}
                  </div>
                  <h3 style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                    {isAr ? (r.name_ar || r.name) : r.name}
                  </h3>
                  <span style={{
                    display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                    color: 'var(--text-muted)', fontSize: '0.78rem',
                    background: 'var(--bg-section)', padding: '0.2rem 0.6rem', borderRadius: '8px',
                  }}>
                    <MapPin style={{ width: 11, height: 11 }} /> {isAr ? city?.name_ar : city?.name}
                  </span>
                </div>
                <div style={{ padding: '0.75rem 1.25rem 1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', marginBottom: '0.7rem' }}>
                    <span style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--primary)' }}>~${r.avg_meal_usd}</span>
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{t('avg meal', 'متوسط الوجبة')}</span>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <a href={mapsUrl} target="_blank" rel="noopener noreferrer" onClick={stop} style={{
                      flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                      padding: '0.55rem 0.75rem', borderRadius: '0.6rem',
                      background: 'var(--bg-section)', border: '1px solid var(--border)',
                      color: 'var(--text-dark)', fontSize: '0.78rem', fontWeight: 700, textDecoration: 'none',
                    }}>
                      <MapPin style={{ width: 13, height: 13, color: 'var(--primary)' }} /> {t('Map', 'خريطة')}
                    </a>
                    <a href={dirUrl} target="_blank" rel="noopener noreferrer" onClick={stop} style={{
                      flex: 1, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                      padding: '0.55rem 0.75rem', borderRadius: '0.6rem',
                      background: 'linear-gradient(135deg, var(--primary), var(--accent))',
                      color: '#fff', fontSize: '0.78rem', fontWeight: 700, textDecoration: 'none',
                    }}>
                      <Navigation style={{ width: 13, height: 13 }} /> {t('Directions', 'الاتجاهات')}
                    </a>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default function RestaurantsPage() {
  return <Suspense fallback={<div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>Loading...</div>}><RestaurantsContent /></Suspense>;
}
