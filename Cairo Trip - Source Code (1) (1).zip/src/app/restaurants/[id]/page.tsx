'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { MapPin, Navigation, Star, ArrowLeft, ExternalLink, Phone, UtensilsCrossed, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Restaurant, City } from '@/types/database';
import FavoriteButton from '@/components/FavoriteButton';
import SmartImage from '@/components/SmartImage';
import { mapsSearchUrl, mapsDirectionsUrl } from '@/lib/maps';

export default function RestaurantDetailPage() {
  const { id } = useParams() as { id: string };
  const { t, lang } = useLang();
  const [r, setR] = useState<Restaurant | null>(null);

  useEffect(() => {
    supabase.from('restaurants').select('*, city:cities(*)').eq('id', id).single()
      .then(({ data }) => { if (data) setR(data as unknown as Restaurant); });
  }, [id]);

  if (!r) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
      {t('Loading...', 'جاري التحميل...')}
    </div>
  );

  const city = r.city as unknown as City;
  const isAr = lang === 'ar';
  const mapsUrl = mapsDirectionsUrl(r.name, city?.name);
  const mapsViewUrl = mapsSearchUrl(r.name, city?.name);
  const cardStyle: React.CSSProperties = { background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.25rem', padding: '1.25rem' };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.5rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <Link href="/restaurants" style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
          color: 'var(--primary)', fontWeight: 700, fontSize: '0.92rem',
          textDecoration: 'none', marginBottom: '1.5rem',
        }}>
          <ArrowLeft style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} />
          {t('Back to Restaurants', 'العودة للمطاعم')}
        </Link>

        <div style={{
          height: 360, borderRadius: '1.25rem', overflow: 'hidden', marginBottom: '1.75rem',
          border: '1px solid var(--border)', position: 'relative',
        }}>
          <SmartImage src={r.image_url} alt={r.name} fallbackName={r.name} loading="eager" />
          <div style={{ position: 'absolute', top: '1rem', insetInlineStart: '1rem', zIndex: 5 }}>
            <FavoriteButton type="restaurant" id={r.id} variant="inline" size="lg" stopProp={false} />
          </div>
          <div style={{
            position: 'absolute', top: '1rem', insetInlineEnd: '1rem',
            padding: '0.4rem 0.85rem', borderRadius: 999, color: '#fff',
            fontSize: '0.85rem', fontWeight: 800, background: 'rgba(0,0,0,0.6)',
            backdropFilter: 'blur(8px)',
          }}>
            {'$'.repeat(r.price_range)}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(280px, 1fr)', gap: '1.5rem' }} className="detail-grid">
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', minWidth: 0 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.75rem', flexWrap: 'wrap' }}>
                <span style={{
                  display: 'inline-block', fontSize: '0.78rem', fontWeight: 700,
                  padding: '0.3rem 0.75rem', borderRadius: 999,
                  background: 'rgba(200, 134, 10, 0.12)', color: 'var(--primary)',
                }}>{isAr ? (r.cuisine_ar || r.cuisine) : r.cuisine}</span>
                {r.rating && (
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: 'var(--text-dark)', fontWeight: 700, fontSize: '0.85rem' }}>
                    <Star style={{ width: 16, height: 16, color: 'var(--primary)', fill: 'var(--primary)' }} /> {r.rating}/5
                  </span>
                )}
              </div>
              <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem', lineHeight: 1.2 }}>
                {isAr ? (r.name_ar || r.name) : r.name}
              </h1>
              <p style={{ color: 'var(--text-muted)', display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.95rem' }}>
                <MapPin style={{ width: 16, height: 16 }} /> {isAr ? city?.name_ar : city?.name}
              </p>
            </div>

            {r.description && (
              <div style={cardStyle}>
                <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.6rem', fontSize: '1.1rem' }}>
                  {t('About', 'عن المطعم')}
                </h2>
                <p style={{ color: 'var(--text-body)', lineHeight: 1.7, fontSize: '0.95rem' }}>
                  {isAr ? (r.description_ar || r.description) : r.description}
                </p>
              </div>
            )}

            {r.popular_dishes && r.popular_dishes.length > 0 && (
              <div>
                <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.75rem', fontSize: '1.1rem' }}>
                  {t('Must-Try Dishes', 'أطباق لازم تجربها')}
                </h2>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                  {r.popular_dishes.map((d) => (
                    <span key={d} style={{
                      display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                      padding: '0.55rem 1rem', borderRadius: '0.75rem',
                      background: 'var(--bg-section)', border: '1px solid var(--border)',
                      fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-body)',
                    }}>
                      <UtensilsCrossed style={{ width: 14, height: 14, color: 'var(--primary)' }} />{d}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {r.opening_hours && (
              <div style={cardStyle}>
                <h2 style={{ fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.75rem', fontSize: '1.05rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Clock style={{ width: 16, height: 16, color: 'var(--primary)' }} />
                  {t('Opening Hours', 'مواعيد العمل')}
                </h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                  {Object.entries(r.opening_hours).map(([day, hours]) => (
                    <div key={day} style={{
                      display: 'flex', justifyContent: 'space-between',
                      background: 'var(--bg-section)', borderRadius: '0.6rem',
                      padding: '0.5rem 0.85rem', fontSize: '0.88rem',
                    }}>
                      <span style={{ fontWeight: 700, color: 'var(--text-dark)', textTransform: 'capitalize' }}>{day}</span>
                      <span style={{ color: 'var(--text-muted)' }}>{hours as string}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div style={{ ...cardStyle, padding: '1.25rem', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
                <span style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--primary)' }}>~${r.avg_meal_usd}</span>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{t('avg meal per person', 'متوسط الوجبة للشخص')}</div>
              </div>
              {r.booking_url && (
                <a href={r.booking_url} target="_blank" rel="noopener noreferrer" className="btn-primary"
                  style={{ padding: '0.85rem', justifyContent: 'center', textDecoration: 'none', fontSize: '0.92rem', width: '100%' }}>
                  <ExternalLink style={{ width: 14, height: 14 }} /> {t('Reserve', 'احجز')}
                </a>
              )}
            </div>

            <a href={mapsViewUrl} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.9rem 1rem', borderRadius: '0.9rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                textDecoration: 'none', color: 'inherit',
              }}>
              <MapPin style={{ width: 22, height: 22, color: 'var(--primary)', flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>
                  {t('Open in Google Maps', 'افتح في خرائط جوجل')}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{t('View location', 'عرض الموقع')}</div>
              </div>
            </a>

            <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.9rem 1rem', borderRadius: '0.9rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                textDecoration: 'none', color: 'inherit',
              }}>
              <Navigation style={{ width: 22, height: 22, color: 'var(--primary)', flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>
                  {t('Get Directions', 'الاتجاهات')}
                </div>
                <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{t('From your location', 'من موقعك')}</div>
              </div>
            </a>

            {r.phone && (
              <a href={`tel:${r.phone}`} style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.9rem 1rem', borderRadius: '0.9rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                textDecoration: 'none', color: 'inherit',
              }}>
                <Phone style={{ width: 22, height: 22, color: 'var(--primary)', flexShrink: 0 }} />
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>{t('Call', 'اتصل')}</div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{r.phone}</div>
                </div>
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
