'use client';

import { ReactNode } from 'react';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { FavoritesProvider } from '@/contexts/FavoritesContext';
import { UIProvider } from '@/contexts/UIContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import EmergencyFAB from '@/components/EmergencyFAB';
import ChatBot from '@/components/ChatBot';

export function Providers({ children }: { children: ReactNode }) {
  return (
    <LanguageProvider>
      <UIProvider>
        <AuthProvider>
          <FavoritesProvider>
            <Navbar />
            <main>{children}</main>
            <Footer />
            <EmergencyFAB />
            <ChatBot />
          </FavoritesProvider>
        </AuthProvider>
      </UIProvider>
    </LanguageProvider>
  );
}
