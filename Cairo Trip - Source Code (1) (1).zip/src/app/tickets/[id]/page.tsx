'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useUI } from '@/contexts/UIContext';
import {
  CalendarDays, Users, ArrowLeft, Loader2, MapPin, CheckCircle2, Ticket as TicketIcon,
  Clock, LogIn, Plus, Minus,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Attraction, City } from '@/types/database';
import { toEGP } from '@/lib/egp';
import SmartImage from '@/components/SmartImage';

export default function BookTicketPage() {
  const { id } = useParams() as { id: string };
  const { t, lang } = useLang();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useUI();
  const router = useRouter();
  const isAr = lang === 'ar';

  const [attr, setAttr] = useState<Attraction | null>(null);
  const [loading, setLoading] = useState(true);
  const [visitDate, setVisitDate] = useState('');
  const [people, setPeople] = useState(1);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    supabase.from('attractions').select('*, city:cities(*)').eq('id', id).single()
      .then(({ data }) => {
        if (data) setAttr(data as unknown as Attraction);
        setLoading(false);
      });
  }, [id]);

  if (loading || authLoading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Loader2 className="animate-spin" style={{ width: 32, height: 32, color: 'var(--primary)' }} />
      </div>
    );
  }

  if (!attr) {
    return (
      <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', textAlign: 'center' }} dir={isAr ? 'rtl' : 'ltr'}>
        <div style={{ maxWidth: 480, margin: '0 auto', padding: '3rem 2rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.5rem' }}>
          <TicketIcon style={{ width: 56, height: 56, color: 'var(--primary)', opacity: 0.4, margin: '0 auto 1rem' }} />
          <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
            {t('Attraction not found', 'المعلم غير موجود')}
          </h1>
          <Link href="/attractions" className="btn-primary" style={{ textDecoration: 'none', padding: '0.75rem 1.5rem', display: 'inline-flex' }}>
            {t('Browse Attractions', 'تصفح المعالم')}
          </Link>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem' }} dir={isAr ? 'rtl' : 'ltr'}>
        <div style={{ maxWidth: 480, margin: '0 auto', padding: '2.5rem 2rem', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '1.5rem', textAlign: 'center' }}>
          <div style={{ width: 64, height: 64, margin: '0 auto 1rem', borderRadius: '50%', background: 'rgba(200,134,10,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <LogIn style={{ width: 28, height: 28, color: 'var(--primary)' }} />
          </div>
          <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
            {t('Sign in to book tickets', 'سجّل دخول للحجز')}
          </h1>
          <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
            {t('Create a free account to book entry tickets and keep them in your dashboard.', 'أنشئ حساب مجاني لحجز التذاكر والاحتفاظ بها في لوحة التحكم.')}
          </p>
          <div style={{ display: 'flex', gap: '0.6rem' }}>
            <Link href={`/auth/login?redirect=/tickets/${attr.id}`} className="btn-primary" style={{ flex: 1, textDecoration: 'none', justifyContent: 'center', padding: '0.75rem' }}>
              {t('Sign In', 'دخول')}
            </Link>
            <Link href={`/auth/signup?redirect=/tickets/${attr.id}`} style={{
              flex: 1, padding: '0.75rem', borderRadius: '0.75rem',
              background: 'var(--bg-section)', border: '1px solid var(--border)',
              color: 'var(--text-body)', fontWeight: 700, fontSize: '0.9rem',
              textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {t('Sign Up', 'حساب جديد')}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const city = attr.city as unknown as City;
  const pricePerTicket = attr.entry_fee_usd;
  const total = people * pricePerTicket;
  const todayStr = new Date().toISOString().split('T')[0];

  const handleSubmit = async () => {
    if (!visitDate) {
      toast({ message: t('Pick a visit date', 'اختر تاريخ الزيارة'), type: 'error' });
      return;
    }
    if (people < 1) {
      toast({ message: t('At least 1 person', 'شخص واحد على الأقل'), type: 'error' });
      return;
    }
    setSubmitting(true);
    const { data, error } = await (supabase.from('tickets') as any).insert({
      user_id: user.id, attraction_id: attr.id,
      visit_date: visitDate, num_people: people,
      total_price_usd: total, status: 'pending',
    }).select('id').single();
    setSubmitting(false);

    if (error) {
      toast({ message: error.message, type: 'error' });
      return;
    }
    toast({ message: t('Ticket reserved!', 'تم حجز التذكرة!'), type: 'success' });
    router.push(`/payment?amount=${total}&currency=USD&order=${data.id}&type=ticket`);
  };

  const cardStyle: React.CSSProperties = {
    background: 'var(--bg-card)', border: '1px solid var(--border)',
    borderRadius: '1.25rem', padding: '1.5rem',
  };

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 640, margin: '0 auto' }}>
        <Link href={`/attractions/${attr.id}`} style={{
          display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
          color: 'var(--primary)', fontWeight: 700, fontSize: '0.92rem',
          textDecoration: 'none', marginBottom: '1.25rem',
        }}>
          <ArrowLeft style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} />
          {t('Back to attraction', 'العودة للمعلم')}
        </Link>

        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <div style={{
            width: 56, height: 56, margin: '0 auto 0.75rem', borderRadius: '1rem',
            background: 'linear-gradient(135deg, var(--primary), var(--accent))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 8px 20px rgba(200,134,10,0.35)',
          }}>
            <TicketIcon style={{ width: 28, height: 28, color: '#fff' }} />
          </div>
          <h1 style={{ fontSize: '1.85rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Book Your Tickets', 'احجز تذاكرك')}
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
            {t('Skip the queue at the gate.', 'وفر وقت الانتظار على البوابة.')}
          </p>
        </div>

        <div style={{ ...cardStyle, padding: '1rem', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{ width: 80, height: 80, borderRadius: '0.75rem', overflow: 'hidden', flexShrink: 0 }}>
            <SmartImage src={attr.image_url} alt={attr.name} fallbackName={attr.name} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3 style={{ fontWeight: 800, color: 'var(--text-dark)', fontSize: '1.05rem', marginBottom: '0.2rem' }}>
              {isAr ? (attr as unknown as { name_ar?: string }).name_ar || attr.name : attr.name}
            </h3>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem', marginBottom: '0.4rem' }}>
              <MapPin style={{ width: 12, height: 12 }} /> {isAr ? city?.name_ar : city?.name}
              <span style={{ marginInlineStart: '0.5rem' }}>·</span>
              <Clock style={{ width: 12, height: 12 }} /> ~{attr.duration_hours}h
            </p>
            <p style={{ fontSize: '0.95rem', fontWeight: 800, color: 'var(--primary)' }}>
              {pricePerTicket > 0 ? `$${pricePerTicket}` : t('Free entry', 'دخول مجاني')}
              <span style={{ color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.78rem' }}> / {t('person', 'شخص')}</span>
            </p>
          </div>
        </div>

        <div style={cardStyle}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                <CalendarDays style={{ width: 14, height: 14 }} /> {t('Visit date', 'تاريخ الزيارة')}
              </label>
              <input type="date" min={todayStr} value={visitDate}
                onChange={e => setVisitDate(e.target.value)} className="input" />
              <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.3rem' }}>
                {t('Tickets are timed for the date you choose.', 'التذكرة صالحة للتاريخ اللي اخترته.')}
              </p>
            </div>

            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
                <Users style={{ width: 14, height: 14 }} /> {t('Number of people', 'عدد الأشخاص')}
              </label>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <button type="button" onClick={() => setPeople(p => Math.max(1, p - 1))}
                  style={{
                    width: 40, height: 40, borderRadius: '0.6rem',
                    background: 'var(--bg-section)', border: '1px solid var(--border)',
                    color: 'var(--text-dark)', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                  <Minus style={{ width: 16, height: 16 }} />
                </button>
                <div style={{
                  flex: 1, padding: '0.65rem', borderRadius: '0.6rem',
                  background: 'var(--bg-section)', border: '1px solid var(--border)',
                  textAlign: 'center', fontWeight: 800, fontSize: '1.1rem', color: 'var(--text-dark)',
                }}>{people}</div>
                <button type="button" onClick={() => setPeople(p => Math.min(20, p + 1))}
                  style={{
                    width: 40, height: 40, borderRadius: '0.6rem',
                    background: 'var(--bg-section)', border: '1px solid var(--border)',
                    color: 'var(--text-dark)', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                  <Plus style={{ width: 16, height: 16 }} />
                </button>
              </div>
            </div>

            <div style={{
              padding: '1rem 1.25rem', borderRadius: '0.85rem',
              background: 'linear-gradient(135deg, var(--primary), var(--accent))',
              color: '#fff', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div>
                <div style={{ fontSize: '0.85rem', opacity: 0.9 }}>
                  {t('Total', 'الإجمالي')}
                </div>
                <div style={{ fontSize: '0.72rem', opacity: 0.75 }}>
                  {people} × ${pricePerTicket}
                </div>
              </div>
              <div style={{ textAlign: 'end' }}>
                <div style={{ fontSize: '1.75rem', fontWeight: 900, lineHeight: 1 }}>${total}</div>
                <div style={{ fontSize: '0.75rem', opacity: 0.85 }}>{toEGP(total)} EGP</div>
              </div>
            </div>

            <button onClick={handleSubmit} disabled={submitting || !visitDate} className="btn-primary"
              style={{ padding: '0.95rem', justifyContent: 'center', fontSize: '0.95rem', opacity: submitting || !visitDate ? 0.6 : 1 }}>
              {submitting ? <Loader2 className="animate-spin" style={{ width: 16, height: 16 }} /> : <CheckCircle2 style={{ width: 16, height: 16 }} />}
              {submitting ? t('Reserving...', 'جاري الحجز...') : t('Reserve & Pay', 'احجز وادفع')}
            </button>

            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textAlign: 'center', lineHeight: 1.5 }}>
              {t(
                'After payment, your ticket is emailed and saved to your dashboard. Show it at the gate.',
                'بعد الدفع، التذكرة بتتبعت بالإيميل وتتحفظ في لوحة التحكم. اعرضها على البوابة.'
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
