'use client';

import { useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLang } from '@/contexts/LanguageContext';
import { useUI } from '@/contexts/UIContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import {
  CreditCard, CheckCircle2, Smartphone, Lock, Copy, Info, Shield,
  Calendar, Hash, User, ArrowLeft, Loader2, Upload, Image as ImageIcon, X,
} from 'lucide-react';

function formatCardNumber(v: string) {
  return v.replace(/\D/g, '').slice(0, 19).replace(/(.{4})/g, '$1 ').trim();
}
function formatExpiry(v: string) {
  const digits = v.replace(/\D/g, '').slice(0, 4);
  if (digits.length <= 2) return digits;
  return digits.slice(0, 2) + '/' + digits.slice(2);
}
function detectBrand(num: string): string {
  const n = num.replace(/\s/g, '');
  if (/^4/.test(n)) return 'Visa';
  if (/^5[1-5]/.test(n) || /^2[2-7]/.test(n)) return 'Mastercard';
  if (/^3[47]/.test(n)) return 'Amex';
  if (/^6(?:011|5)/.test(n)) return 'Discover';
  if (/^9(?:0[3-9]|1)/.test(n)) return 'Meeza';
  return '';
}

const INSTAPAY_HANDLE = 'egypttrip.savekho2';
const INSTAPAY_NAME = 'Cairo Trip';

function PaymentContent() {
  const { t, lang } = useLang();
  const { toast } = useUI();
  const { user } = useAuth();
  const searchParams = useSearchParams();
  const router = useRouter();
  const isAr = lang === 'ar';
  const amount = Number(searchParams.get('amount')) || 0;
  const currency = searchParams.get('currency') || 'USD';
  const orderId = searchParams.get('order') || '';
  const orderType = searchParams.get('type') === 'ticket' ? 'tickets' : 'bookings';

  const [method, setMethod] = useState<'card' | 'instapay'>('card');
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState(false);
  const [card, setCard] = useState({ number: '', expiry: '', cvv: '', name: '' });
  const brand = detectBrand(card.number);

  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofPreview, setProofPreview] = useState<string | null>(null);
  const [txnId, setTxnId] = useState('');
  const [uploading, setUploading] = useState(false);

  const updateBookingPayment = async (paymentMethod: string, proofUrl: string | null, transactionId?: string) => {
    if (!orderId) return;
    // Orders stay 'pending' after payment. Confirmation is an admin action only
    // (enforced server-side); the client can never self-confirm an order.
    await (supabase.from(orderType) as any).update({
      payment_method: paymentMethod,
      payment_proof_url: proofUrl,
      payment_transaction_id: transactionId || null,
      paid_at: new Date().toISOString(),
      status: 'pending',
    }).eq('id', orderId);

    // Fire-and-forget email confirmation (authenticated; server verifies ownership).
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      await fetch('/api/send-confirmation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          orderId,
          type: orderType === 'tickets' ? 'ticket' : 'booking',
        }),
      });
    } catch { /* ignore */ }
  };

  const handleCardSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (card.number.replace(/\s/g, '').length < 13) {
      toast({ message: t('Invalid card number', 'رقم بطاقة غير صحيح'), type: 'error' });
      return;
    }
    if (!/^\d{2}\/\d{2}$/.test(card.expiry)) {
      toast({ message: t('Invalid expiry date', 'تاريخ صلاحية غير صحيح'), type: 'error' });
      return;
    }
    {
      const [mm, yy] = card.expiry.split('/').map(n => parseInt(n, 10));
      if (mm < 1 || mm > 12) {
        toast({ message: t('Invalid expiry month', 'الشهر غير صحيح'), type: 'error' });
        return;
      }
      const now = new Date();
      const currentYY = now.getFullYear() % 100;
      const currentMM = now.getMonth() + 1;
      const expired = yy < currentYY || (yy === currentYY && mm < currentMM);
      if (expired) {
        toast({ message: t('This card is expired', 'البطاقة دي منتهية'), type: 'error' });
        return;
      }
      if (yy > currentYY + 20) {
        toast({ message: t('Expiry year is too far in the future', 'سنة الانتهاء بعيدة جداً'), type: 'error' });
        return;
      }
    }
    if (!card.name.trim() || card.name.trim().length < 3) {
      toast({ message: t('Enter the cardholder name', 'أدخل اسم صاحب البطاقة'), type: 'error' });
      return;
    }
    if (!/^\d{3,4}$/.test(card.cvv)) {
      toast({ message: t('Invalid CVV', 'CVV غير صحيح'), type: 'error' });
      return;
    }
    // Luhn check on the number to catch obvious fakes like "1111 1111 1111 1111"
    {
      const num = card.number.replace(/\s/g, '');
      let sum = 0, dbl = false;
      for (let i = num.length - 1; i >= 0; i--) {
        let d = parseInt(num[i], 10);
        if (dbl) { d *= 2; if (d > 9) d -= 9; }
        sum += d; dbl = !dbl;
      }
      if (sum % 10 !== 0) {
        toast({ message: t('Card number looks invalid', 'رقم البطاقة غير صحيح'), type: 'error' });
        return;
      }
    }
    setProcessing(true);
    await new Promise(r => setTimeout(r, 1500));
    await updateBookingPayment('card', null);
    setProcessing(false);
    setDone(true);
    if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' });
    toast({ message: t('Payment received', 'تم استلام الدفع'), type: 'success' });
  };

  const [dragOver, setDragOver] = useState(false);

  const acceptFile = (f: File) => {
    if (!f.type.startsWith('image/')) {
      toast({ message: t('Please upload an image file', 'يرجى رفع صورة'), type: 'error' });
      return;
    }
    if (f.size > 5 * 1024 * 1024) {
      toast({ message: t('Image must be under 5MB', 'الصورة لازم أقل من ٥ ميجا'), type: 'error' });
      return;
    }
    setProofFile(f);
    const reader = new FileReader();
    reader.onload = (ev) => setProofPreview(ev.target?.result as string);
    reader.readAsDataURL(f);
  };

  const onPickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) acceptFile(f);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) acceptFile(f);
  };

  const handleInstaPaySubmit = async () => {
    if (!txnId.trim()) {
      toast({ message: t('Enter the InstaPay transaction ID', 'أدخل رقم العملية من إنستاباي'), type: 'error' });
      return;
    }
    if (!proofFile) {
      toast({ message: t('Please upload your payment screenshot', 'ارفع صورة إيصال الدفع'), type: 'error' });
      return;
    }
    if (!user) {
      toast({ message: t('Please sign in to confirm payment', 'سجّل دخول لتأكيد الدفع'), type: 'error' });
      return;
    }
    setUploading(true);
    const ext = proofFile.name.split('.').pop() || 'jpg';
    const filePath = `${user.id}/${orderId || Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from('payment-proofs').upload(filePath, proofFile, { upsert: true });
    if (upErr) {
      toast({ message: upErr.message, type: 'error' });
      setUploading(false);
      return;
    }
    const { data: { publicUrl } } = supabase.storage.from('payment-proofs').getPublicUrl(filePath);
    await updateBookingPayment('instapay', publicUrl, txnId.trim());
    setUploading(false);
    setDone(true);
    if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' });
    toast({ message: t('Payment proof uploaded! We will verify it shortly.', 'تم رفع الإيصال! سنقوم بمراجعته قريباً.'), type: 'success' });
  };

  const copyHandle = async () => {
    try {
      await navigator.clipboard.writeText(INSTAPAY_HANDLE);
      toast({ message: t('Handle copied!', 'تم نسخ الكود!'), type: 'success' });
    } catch { /* ignore */ }
  };

  const fmtAmount = `${currency === 'EGP' ? 'E£' : '$'}${amount.toLocaleString()}`;

  if (done) {
    return (
      <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
        <div style={{ maxWidth: 480, margin: '0 auto' }}>
          <div style={{
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            borderRadius: '1.5rem', padding: '3rem 2rem', textAlign: 'center',
            boxShadow: '0 20px 50px rgba(0,0,0,0.08)',
          }}>
            <div style={{
              width: 84, height: 84, margin: '0 auto 1.5rem',
              borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'linear-gradient(135deg, #27ae60, #16a34a)',
              boxShadow: '0 12px 28px rgba(39,174,96,0.35)',
            }}>
              <CheckCircle2 style={{ width: 44, height: 44, color: '#fff' }} />
            </div>
            <h1 style={{ fontSize: '1.75rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
              {t('Payment Received!', 'تم استلام الدفع!')}
            </h1>
            <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem' }}>
              {orderType === 'bookings'
                ? t(`You paid ${fmtAmount}. We are confirming with the hotel and will email you within 24 hours.`, `دفعت ${fmtAmount}. بنأكد الحجز مع الفندق ونبعتلك إيميل خلال ٢٤ ساعة.`)
                : t(`You paid ${fmtAmount}. Our team is verifying your ticket and will email you within 24 hours.`, `دفعت ${fmtAmount}. فريقنا بيراجع التذكرة ونبعتلك إيميل خلال ٢٤ ساعة.`)}
            </p>
            {orderId && (
              <div style={{
                background: 'rgba(39,174,96,0.08)', border: '1px solid rgba(39,174,96,0.25)',
                borderRadius: '0.75rem', padding: '0.85rem 1rem', marginBottom: '1.25rem',
                fontSize: '0.85rem', color: 'var(--text-body)', lineHeight: 1.5,
              }}>
                ✉️ {t('Confirmation email sent to your inbox.', 'تم إرسال إيصال للبريد الإلكتروني.')}{' '}
                {t('Check spam if you do not see it within 2 minutes.', 'افحص الـsspam لو متلقتش الرسالة خلال دقيقتين.')}
              </div>
            )}
            <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
              {orderId && (
                <Link href={`/${orderType === 'tickets' ? 'ticket' : 'booking'}/${orderId}`}
                  className="btn-primary"
                  style={{ flex: 1, minWidth: 160, justifyContent: 'center', textDecoration: 'none', padding: '0.75rem' }}>
                  {orderType === 'tickets' ? t('View my ticket', 'عرض التذكرة') : t('View my booking', 'عرض الحجز')}
                </Link>
              )}
              <Link href="/dashboard" style={{
                flex: 1, minWidth: 140, padding: '0.75rem', borderRadius: '0.75rem',
                background: 'var(--bg-section)', border: '1px solid var(--border)',
                color: 'var(--text-body)', fontWeight: 700, fontSize: '0.9rem',
                textDecoration: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {t('Dashboard', 'لوحة التحكم')}
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 540, margin: '0 auto' }}>

        <button onClick={() => router.back()} style={{
          background: 'none', border: 'none', color: 'var(--primary)',
          fontWeight: 700, fontSize: '0.92rem', cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
          marginBottom: '1.5rem', padding: 0, fontFamily: 'inherit',
        }}>
          <ArrowLeft style={{ width: 16, height: 16, transform: isAr ? 'scaleX(-1)' : undefined }} />
          {t('Back', 'رجوع')}
        </button>

        <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
          <h1 style={{ fontSize: '1.75rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.4rem' }}>
            {t('Complete Payment', 'إتمام الدفع')}
          </h1>
          {amount > 0 ? (
            <div style={{
              display: 'inline-flex', alignItems: 'baseline', gap: '0.25rem',
              padding: '0.5rem 1.25rem', borderRadius: 999,
              background: 'rgba(200,134,10,0.1)', color: 'var(--primary)',
            }}>
              <span style={{ fontSize: '0.78rem', fontWeight: 700 }}>{t('Amount', 'المبلغ')}:</span>
              <span style={{ fontSize: '1.5rem', fontWeight: 900 }}>{fmtAmount}</span>
            </div>
          ) : (
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
              {t('Choose a payment method', 'اختر طريقة الدفع')}
            </p>
          )}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.6rem', marginBottom: '1rem' }}>
          {([
            { key: 'card', icon: CreditCard, label: t('Credit / Debit Card', 'بطاقة ائتمان') },
            { key: 'instapay', icon: Smartphone, label: 'InstaPay' },
          ] as const).map(m => (
            <button key={m.key} onClick={() => setMethod(m.key)} style={{
              padding: '1rem', borderRadius: '0.85rem',
              border: method === m.key ? '2px solid var(--primary)' : '2px solid var(--border)',
              background: method === m.key ? 'rgba(200,134,10,0.06)' : 'var(--bg-card)',
              cursor: 'pointer', fontFamily: 'inherit', textAlign: 'center',
              transition: 'all 0.15s',
            }}>
              <m.icon style={{ width: 24, height: 24, color: method === m.key ? 'var(--primary)' : 'var(--text-muted)', margin: '0 auto 0.4rem' }} />
              <div style={{ fontWeight: 800, fontSize: '0.85rem', color: method === m.key ? 'var(--primary)' : 'var(--text-body)' }}>
                {m.label}
              </div>
            </button>
          ))}
        </div>

        {method === 'card' && (
          <form onSubmit={handleCardSubmit} style={{
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            borderRadius: '1.25rem', padding: '1.5rem',
            boxShadow: '0 8px 24px rgba(0,0,0,0.05)',
          }}>
            <div style={{
              background: 'linear-gradient(135deg, #1a1a1a, #2c2c2c)',
              borderRadius: '0.85rem', padding: '1.5rem', marginBottom: '1.25rem',
              color: '#fff', position: 'relative', overflow: 'hidden',
              minHeight: 160,
            }}>
              <div style={{ position: 'absolute', top: -30, insetInlineEnd: -30, width: 120, height: 120, borderRadius: '50%', background: 'rgba(200,134,10,0.18)' }} />
              <div style={{ position: 'absolute', bottom: -50, insetInlineStart: -20, width: 140, height: 140, borderRadius: '50%', background: 'rgba(200,134,10,0.08)' }} />

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', position: 'relative' }}>
                <div style={{
                  width: 40, height: 30, borderRadius: '0.4rem',
                  background: 'linear-gradient(135deg, #d4ac0d, #c8860a)',
                }} />
                <div style={{ fontSize: '0.85rem', fontWeight: 800, opacity: 0.95 }}>{brand || 'CARD'}</div>
              </div>

              <div style={{ marginTop: '1.5rem', fontSize: '1.15rem', fontWeight: 700, letterSpacing: '0.1em', fontFamily: 'monospace', position: 'relative' }}>
                {card.number || '•••• •••• •••• ••••'}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem', fontSize: '0.75rem', position: 'relative' }}>
                <div>
                  <div style={{ opacity: 0.6, marginBottom: '0.15rem' }}>{t('Cardholder', 'صاحب البطاقة')}</div>
                  <div style={{ fontWeight: 700, textTransform: 'uppercase' }}>{card.name || '-'}</div>
                </div>
                <div>
                  <div style={{ opacity: 0.6, marginBottom: '0.15rem' }}>{t('Expires', 'الصلاحية')}</div>
                  <div style={{ fontWeight: 700 }}>{card.expiry || 'MM/YY'}</div>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  <Hash style={{ width: 14, height: 14 }} /> {t('Card Number', 'رقم البطاقة')}
                </label>
                <input
                  type="text" inputMode="numeric"
                  value={card.number}
                  onChange={e => setCard(p => ({ ...p, number: formatCardNumber(e.target.value) }))}
                  placeholder="1234 5678 9012 3456"
                  className="input"
                  required
                />
              </div>

              <div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                  <User style={{ width: 14, height: 14 }} /> {t('Cardholder Name', 'اسم صاحب البطاقة')}
                </label>
                <input
                  type="text"
                  value={card.name}
                  onChange={e => setCard(p => ({ ...p, name: e.target.value }))}
                  placeholder={t('Full name on card', 'الاسم على البطاقة')}
                  className="input"
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.6rem' }}>
                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                    <Calendar style={{ width: 14, height: 14 }} /> {t('Expiry', 'الصلاحية')}
                  </label>
                  <input
                    type="text" inputMode="numeric"
                    value={card.expiry}
                    onChange={e => setCard(p => ({ ...p, expiry: formatExpiry(e.target.value) }))}
                    placeholder="MM/YY"
                    className="input"
                    maxLength={5}
                    required
                  />
                </div>
                <div>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '0.35rem' }}>
                    <Lock style={{ width: 14, height: 14 }} /> CVV
                  </label>
                  <input
                    type="password" inputMode="numeric"
                    value={card.cvv}
                    onChange={e => setCard(p => ({ ...p, cvv: e.target.value.replace(/\D/g, '').slice(0, 4) }))}
                    placeholder="•••"
                    className="input"
                    maxLength={4}
                    required
                  />
                </div>
              </div>

              <button type="submit" disabled={processing} className="btn-primary"
                style={{ width: '100%', padding: '0.95rem', fontSize: '0.95rem', justifyContent: 'center', opacity: processing ? 0.7 : 1, marginTop: '0.5rem' }}>
                {processing ? <Loader2 className="animate-spin" style={{ width: 16, height: 16 }} /> : <Lock style={{ width: 16, height: 16 }} />}
                {processing ? t('Processing...', 'جاري المعالجة...') : t(`Pay ${fmtAmount || 'Securely'}`, `ادفع ${fmtAmount || 'بأمان'}`)}
              </button>

              <div style={{
                display: 'flex', alignItems: 'center', gap: '0.5rem',
                padding: '0.75rem', borderRadius: '0.6rem',
                background: 'rgba(52,152,219,0.06)', border: '1px solid rgba(52,152,219,0.2)',
                color: '#2874a6', fontSize: '0.78rem', lineHeight: 1.5,
              }}>
                <Info style={{ width: 14, height: 14, flexShrink: 0, marginTop: '0.15rem' }} />
                <div>
                  <strong>{t('Demo mode:', 'وضع تجريبي:')}</strong>{' '}
                  {t('No card is charged. Connect Paymob, Fawry or Stripe for live payments.', 'لا يتم خصم بطاقة. اربط Paymob أو Fawry أو Stripe للمدفوعات الحقيقية.')}
                </div>
              </div>
            </div>
          </form>
        )}

        {method === 'instapay' && (
          <div style={{
            background: 'var(--bg-card)', border: '1px solid var(--border)',
            borderRadius: '1.25rem', padding: '1.75rem', textAlign: 'center',
          }}>
            <div style={{
              width: 72, height: 72, margin: '0 auto 1rem',
              borderRadius: '1rem',
              background: 'linear-gradient(135deg, #6c5ce7, #4834d4)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 8px 24px rgba(108,92,231,0.3)',
            }}>
              <Smartphone style={{ width: 32, height: 32, color: '#fff' }} />
            </div>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 900, color: 'var(--text-dark)', marginBottom: '0.5rem' }}>
              {t('Pay with InstaPay', 'ادفع عبر إنستاباي')}
            </h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginBottom: '1.5rem' }}>
              {t('Open your InstaPay app and send to:', 'افتح تطبيق إنستاباي وحوّل إلى:')}
            </p>

            <div style={{
              padding: '1rem', borderRadius: '0.85rem',
              background: 'var(--bg-section)', border: '2px dashed var(--primary)',
              marginBottom: '0.75rem',
            }}>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.3rem', textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.05em' }}>
                {t('Payment Address', 'عنوان الدفع')}
              </div>
              <div style={{ fontSize: '1.4rem', fontWeight: 900, color: 'var(--primary)', wordBreak: 'break-all', marginBottom: '0.4rem' }}>
                {INSTAPAY_HANDLE}
              </div>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                {t('Recipient', 'المستلم')}: <strong style={{ color: 'var(--text-dark)' }}>{INSTAPAY_NAME}</strong>
              </div>
            </div>

            <button onClick={copyHandle} style={{
              padding: '0.7rem 1.25rem', borderRadius: '0.6rem',
              background: 'var(--bg-section)', border: '1px solid var(--border)',
              color: 'var(--text-dark)', fontWeight: 700, fontSize: '0.85rem',
              cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
              fontFamily: 'inherit', marginBottom: '1.5rem',
            }}>
              <Copy style={{ width: 14, height: 14 }} /> {t('Copy address', 'نسخ العنوان')}
            </button>

            {amount > 0 && (
              <div style={{
                padding: '0.85rem', borderRadius: '0.75rem',
                background: 'rgba(200,134,10,0.08)', marginBottom: '1.5rem',
              }}>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                  {t('Amount to send', 'المبلغ المطلوب تحويله')}
                </div>
                <div style={{ fontSize: '1.5rem', fontWeight: 900, color: 'var(--primary)' }}>{fmtAmount}</div>
              </div>
            )}

            <ol style={{
              textAlign: 'start', fontSize: '0.85rem', color: 'var(--text-body)',
              lineHeight: 1.7, paddingInlineStart: '1.25rem', marginBottom: '1.5rem',
            }}>
              <li>{t('Open the InstaPay app on your phone', 'افتح تطبيق إنستاباي')}</li>
              <li>{t('Tap "Send Money" then enter the address above', 'اضغط "تحويل" وأدخل العنوان أعلاه')}</li>
              <li>{t('Send the exact amount and confirm', 'أرسل المبلغ بالضبط وأكد')}</li>
              <li>{t('Take a screenshot of the success page', 'خد سكرين شوت لصفحة نجاح التحويل')}</li>
              <li>{t('Upload the screenshot below', 'ارفع السكرين شوت بالأسفل')}</li>
            </ol>

            <div style={{ textAlign: 'start', marginBottom: '1rem' }}>
              <label style={{
                display: 'flex', alignItems: 'center', gap: '0.4rem',
                fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)',
                marginBottom: '0.5rem',
              }}>
                <Hash style={{ width: 14, height: 14 }} />
                {t('Transaction ID (required)', 'رقم العملية (مطلوب)')}
              </label>
              <input
                type="text" value={txnId} onChange={e => setTxnId(e.target.value)}
                placeholder={t('e.g. 8273645012', 'مثال: ٨٢٧٣٦٤٥٠١٢')}
                className="input"
              />
              <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.3rem' }}>
                {t('Find it on the InstaPay confirmation page after sending.', 'هتلاقيه على صفحة تأكيد التحويل في إنستاباي.')}
              </p>
            </div>

            <div style={{ textAlign: 'start', marginBottom: '1rem' }}>
              <label style={{
                display: 'flex', alignItems: 'center', gap: '0.4rem',
                fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-dark)',
                marginBottom: '0.5rem',
              }}>
                <ImageIcon style={{ width: 14, height: 14 }} />
                {t('Payment screenshot (required)', 'صورة إيصال الدفع (مطلوب)')}
              </label>

              {!proofPreview ? (
                <label
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={onDrop}
                  style={{
                    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                    padding: '2rem 1rem', borderRadius: '0.85rem',
                    border: `2px dashed ${dragOver ? 'var(--primary)' : 'var(--border)'}`,
                    background: dragOver ? 'rgba(200,134,10,0.08)' : 'var(--bg-section)',
                    cursor: 'pointer', transition: 'all 0.15s',
                  }}>
                  <Upload style={{ width: 28, height: 28, color: 'var(--primary)', marginBottom: '0.5rem' }} />
                  <span style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text-dark)' }}>
                    {dragOver
                      ? t('Drop image to upload', 'اسحب الصورة هنا')
                      : t('Drag image here, or click to choose', 'اسحب الصورة هنا أو اضغط للاختيار')}
                  </span>
                  <span style={{ fontSize: '0.74rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                    {t('JPG or PNG, up to 5MB', 'JPG أو PNG، حتى ٥ ميجا')}
                  </span>
                  <input type="file" accept="image/*" onChange={onPickFile} style={{ display: 'none' }} />
                </label>
              ) : (
                <div style={{ position: 'relative', borderRadius: '0.85rem', overflow: 'hidden', border: '1px solid var(--border)' }}>
                  <img src={proofPreview} alt="proof" style={{ width: '100%', maxHeight: 280, objectFit: 'contain', background: '#000' }} />
                  <button type="button" onClick={() => { setProofFile(null); setProofPreview(null); }} style={{
                    position: 'absolute', top: 8, insetInlineEnd: 8,
                    width: 32, height: 32, borderRadius: '50%',
                    background: 'rgba(0,0,0,0.7)', border: 'none', cursor: 'pointer',
                    color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <X style={{ width: 16, height: 16 }} />
                  </button>
                </div>
              )}
            </div>

            <button onClick={handleInstaPaySubmit}
              disabled={uploading || !proofFile || !txnId.trim()} className="btn-primary"
              style={{ width: '100%', padding: '0.9rem', justifyContent: 'center', opacity: (uploading || !proofFile || !txnId.trim()) ? 0.6 : 1 }}>
              {uploading ? <Loader2 className="animate-spin" style={{ width: 16, height: 16 }} /> : <CheckCircle2 style={{ width: 16, height: 16 }} />}
              {uploading ? t('Uploading...', 'جاري الرفع...') : t('Submit payment proof', 'إرسال الإيصال')}
            </button>

            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.6rem', textAlign: 'center' }}>
              {t('We verify InstaPay payments within 24 hours.', 'نراجع تحويلات إنستاباي خلال ٢٤ ساعة.')}
            </p>
          </div>
        )}

        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
          marginTop: '1.5rem', color: 'var(--text-muted)', fontSize: '0.78rem',
        }}>
          <Shield style={{ width: 14, height: 14 }} /> {t('Secure SSL encrypted', 'تشفير SSL آمن')}
        </div>
      </div>
    </div>
  );
}

export default function PaymentPage() {
  return <Suspense fallback={<div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>Loading...</div>}><PaymentContent /></Suspense>;
}
