'use client';

import { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { useLang } from '@/contexts/LanguageContext';
import { useUI } from '@/contexts/UIContext';
import {
  Hotel, Compass, MapPin, Users, MessageSquare, CalendarDays, Plus, Pencil, Trash2,
  X, Ban, Check, ChevronDown, ChevronUp, UtensilsCrossed, Loader2, Search,
  ShieldAlert, Star, Activity, Database,
} from 'lucide-react';
import ImageUploader from '@/components/ImageUploader';
import { refCode } from '@/lib/refcode';
import { supabase } from '@/lib/supabase';

type Tab = 'hotels' | 'attractions' | 'restaurants' | 'cities' | 'users' | 'complaints' | 'bookings';
type Row = Record<string, unknown>;

export default function AdminPage() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const { t, lang } = useLang();
  const { confirm, toast } = useUI();
  const router = useRouter();
  const isAr = lang === 'ar';
  const [tab, setTab] = useState<Tab>('hotels');
  const [data, setData] = useState<Row[]>([]);
  const [cities, setCities] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [modal, setModal] = useState<{ open: boolean; editing: Row | null }>({ open: false, editing: null });
  const [form, setForm] = useState<Row>({});
  const [expandedComplaint, setExpandedComplaint] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [proofImage, setProofImage] = useState<string | null>(null);
  const [globalStats, setGlobalStats] = useState({ users: 0, bookings: 0, complaints: 0, revenue: 0 });

  useEffect(() => {
    if (!authLoading && (!user || !isAdmin)) router.push('/');
  }, [user, isAdmin, authLoading, router]);

  useEffect(() => {
    supabase.from('cities').select('*').then(({ data }) => { if (data) setCities(data); });
    Promise.all([
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('bookings').select('id', { count: 'exact', head: true }),
      supabase.from('complaints').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('bookings').select('total_price_usd').eq('status', 'confirmed'),
    ]).then(([u, b, c, rev]) => {
      const revenue = (rev.data || []).reduce((s: number, r: { total_price_usd?: number }) => s + (r.total_price_usd || 0), 0);
      setGlobalStats({ users: u.count || 0, bookings: b.count || 0, complaints: c.count || 0, revenue });
    });
  }, []);

  useEffect(() => { setSearch(''); loadData(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [tab]);

  const loadData = async () => {
    setLoading(true);
    let result;
    switch (tab) {
      case 'hotels': result = await supabase.from('hotels').select('*, city:cities(name)').order('name'); break;
      case 'attractions': result = await supabase.from('attractions').select('*, city:cities(name)').order('name'); break;
      case 'restaurants': result = await supabase.from('restaurants').select('*, city:cities(name)').order('name'); break;
      case 'cities': result = await supabase.from('cities').select('*').order('name'); break;
      case 'users': result = await supabase.from('profiles').select('*').order('created_at', { ascending: false }); break;
      case 'complaints': result = await supabase.from('complaints').select('*').order('created_at', { ascending: false }); break;
      case 'bookings': result = await supabase.from('bookings').select('*, hotel:hotels(name)').order('created_at', { ascending: false }); break;
    }
    if (result?.data) setData(result.data);
    setLoading(false);
  };

  const filtered = useMemo(() => {
    if (!search.trim()) return data;
    const q = search.toLowerCase();
    return data.filter(r =>
      Object.values(r).some(v => typeof v === 'string' && v.toLowerCase().includes(q))
    );
  }, [data, search]);

  const openAdd = () => { setForm({}); setModal({ open: true, editing: null }); };
  const openEdit = (item: Row) => { setForm({ ...item }); setModal({ open: true, editing: item }); };

  const handleSave = async () => {
    const cleanForm = { ...form };
    delete cleanForm.city; delete cleanForm.hotel; delete cleanForm.created_at;
    if (typeof cleanForm.amenities === 'string') cleanForm.amenities = (cleanForm.amenities as string).split(',').map(s => s.trim()).filter(Boolean);
    if (typeof cleanForm.image_urls === 'string') cleanForm.image_urls = (cleanForm.image_urls as string).split(',').map(s => s.trim()).filter(Boolean);
    if (typeof cleanForm.popular_dishes === 'string') cleanForm.popular_dishes = (cleanForm.popular_dishes as string).split(',').map(s => s.trim()).filter(Boolean);

    const isEdit = !!modal.editing;
    if (isEdit) {
      const { error } = await (supabase.from(tab) as any).update(cleanForm).eq('id', (modal.editing as Row).id);
      toast({ message: error ? error.message : t('Saved', 'تم الحفظ'), type: error ? 'error' : 'success' });
    } else {
      delete cleanForm.id;
      const { error } = await (supabase.from(tab) as any).insert(cleanForm);
      toast({ message: error ? error.message : t('Created', 'تم الإنشاء'), type: error ? 'error' : 'success' });
    }
    setModal({ open: false, editing: null });
    loadData();
  };

  const handleDelete = async (id: string) => {
    const ok = await confirm({
      title: t('Delete this item?', 'حذف هذا العنصر؟'),
      message: t('This action cannot be undone.', 'الإجراء ده لا يمكن التراجع عنه.'),
      confirmText: t('Delete', 'حذف'),
      cancelText: t('Cancel', 'إلغاء'),
      danger: true,
    });
    if (!ok) return;
    const { error } = await (supabase.from(tab) as any).delete().eq('id', id);
    toast({ message: error ? error.message : t('Deleted', 'تم الحذف'), type: error ? 'error' : 'success' });
    loadData();
  };

  const toggleBan = async (userId: string, banned: boolean) => {
    await (supabase.from('profiles') as any).update({ is_banned: !banned }).eq('id', userId);
    toast({ message: !banned ? t('User banned', 'تم حظر المستخدم') : t('User unbanned', 'تم فك الحظر'), type: 'success' });
    loadData();
  };

  const toggleRole = async (userId: string, role: string) => {
    const newRole = role === 'admin' ? 'user' : 'admin';
    await (supabase.from('profiles') as any).update({ role: newRole }).eq('id', userId);
    toast({ message: t(`Role: ${newRole}`, `الدور: ${newRole}`), type: 'success' });
    loadData();
  };

  const updateComplaint = async (id: string, updates: Row) => {
    await (supabase.from('complaints') as any).update(updates).eq('id', id);
    loadData();
  };

  const notifyStatus = async (orderId: string, type: 'booking' | 'ticket', status: string) => {
    if (status !== 'confirmed' && status !== 'cancelled') return;
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      await fetch('/api/send-status-update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ orderId, type, status }),
      });
    } catch { /* fire-and-forget */ }
  };

  const updateBookingStatus = async (id: string, status: string) => {
    await (supabase.from('bookings') as any).update({ status }).eq('id', id);
    toast({ message: t(`Status: ${status}`, `الحالة: ${status}`), type: 'success' });
    notifyStatus(id, 'booking', status);
    loadData();
  };

  const updateTicketStatus = async (id: string, status: string) => {
    await (supabase.from('tickets') as any).update({ status }).eq('id', id);
    toast({ message: t(`Status: ${status}`, `الحالة: ${status}`), type: 'success' });
    notifyStatus(id, 'ticket', status);
    loadData();
  };

  if (authLoading || !isAdmin) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Loader2 className="animate-spin" style={{ width: 28, height: 28, color: 'var(--primary)' }} />
    </div>
  );

  const tabs: { key: Tab; label: string; icon: React.ElementType; color: string }[] = [
    { key: 'hotels', label: t('Hotels', 'فنادق'), icon: Hotel, color: '#c8860a' },
    { key: 'attractions', label: t('Attractions', 'معالم'), icon: Compass, color: '#27ae60' },
    { key: 'restaurants', label: t('Restaurants', 'مطاعم'), icon: UtensilsCrossed, color: '#e67e22' },
    { key: 'cities', label: t('Cities', 'مدن'), icon: MapPin, color: '#3498db' },
    { key: 'users', label: t('Users', 'مستخدمون'), icon: Users, color: '#9b59b6' },
    { key: 'complaints', label: t('Complaints', 'شكاوى'), icon: MessageSquare, color: '#e74c3c' },
    { key: 'bookings', label: t('Bookings', 'حجوزات'), icon: CalendarDays, color: '#16a085' },
  ];
  const currentTab = tabs.find(tb => tb.key === tab)!;

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '0.7rem 0.9rem', borderRadius: '0.6rem',
    border: '1px solid var(--border)', background: 'var(--bg-section)',
    fontSize: '0.9rem', color: 'var(--text-dark)', fontFamily: 'inherit',
  };

  const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div style={{ marginBottom: '0.75rem' }}>
      <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '0.3rem' }}>{label}</label>
      {children}
    </div>
  );

  const renderForm = () => {
    if (tab === 'hotels') return (
      <div>
        <Field label={t('Name', 'الاسم')}><input style={inputStyle} value={(form.name as string) || ''} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></Field>
        <Field label={t('Name (Arabic)', 'الاسم بالعربية')}><input style={inputStyle} value={(form.name_ar as string) || ''} onChange={e => setForm(p => ({ ...p, name_ar: e.target.value }))} /></Field>
        <Field label={t('City', 'المدينة')}>
          <select style={inputStyle} value={(form.city_id as string) || ''} onChange={e => setForm(p => ({ ...p, city_id: e.target.value }))}>
            <option value="">{t('Select city', 'اختر مدينة')}</option>
            {cities.map(c => <option key={c.id as string} value={c.id as string}>{c.name as string}</option>)}
          </select>
        </Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Stars', 'النجوم')}><input type="number" min={1} max={5} style={inputStyle} value={(form.star_rating as number) || ''} onChange={e => setForm(p => ({ ...p, star_rating: Number(e.target.value) }))} /></Field>
          <Field label={t('Price/night USD', 'سعر/ليلة')}><input type="number" style={inputStyle} value={(form.price_per_night_usd as number) || ''} onChange={e => setForm(p => ({ ...p, price_per_night_usd: Number(e.target.value) }))} /></Field>
        </div>
        <Field label={t('Description', 'الوصف')}><textarea style={{ ...inputStyle, minHeight: 70 }} value={(form.description as string) || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></Field>
        <Field label={t('Hotel Image', 'صورة الفندق')}>
          <ImageUploader
            folder="hotels"
            value={Array.isArray(form.image_urls) ? (form.image_urls as string[])[0] : (form.image_urls as string) || ''}
            onChange={(url) => setForm(p => ({ ...p, image_urls: url ? [url] : [] }))}
          />
        </Field>
        <Field label={t('Amenities (comma)', 'المرافق')}><input style={inputStyle} value={Array.isArray(form.amenities) ? (form.amenities as string[]).join(', ') : (form.amenities as string) || ''} onChange={e => setForm(p => ({ ...p, amenities: e.target.value }))} /></Field>
        <Field label={t('Booking URL', 'رابط الحجز')}><input style={inputStyle} value={(form.booking_url as string) || ''} onChange={e => setForm(p => ({ ...p, booking_url: e.target.value }))} /></Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Latitude', 'خط العرض')}><input type="number" step="any" style={inputStyle} value={(form.latitude as number) || ''} onChange={e => setForm(p => ({ ...p, latitude: Number(e.target.value) }))} /></Field>
          <Field label={t('Longitude', 'خط الطول')}><input type="number" step="any" style={inputStyle} value={(form.longitude as number) || ''} onChange={e => setForm(p => ({ ...p, longitude: Number(e.target.value) }))} /></Field>
        </div>
      </div>
    );
    if (tab === 'attractions') return (
      <div>
        <Field label={t('Name', 'الاسم')}><input style={inputStyle} value={(form.name as string) || ''} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></Field>
        <Field label={t('Name (Arabic)', 'الاسم بالعربية')}><input style={inputStyle} value={(form.name_ar as string) || ''} onChange={e => setForm(p => ({ ...p, name_ar: e.target.value }))} /></Field>
        <Field label={t('City', 'المدينة')}>
          <select style={inputStyle} value={(form.city_id as string) || ''} onChange={e => setForm(p => ({ ...p, city_id: e.target.value }))}>
            <option value="">{t('Select city', 'اختر مدينة')}</option>
            {cities.map(c => <option key={c.id as string} value={c.id as string}>{c.name as string}</option>)}
          </select>
        </Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Category', 'الفئة')}><input style={inputStyle} value={(form.category as string) || ''} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} /></Field>
          <Field label={t('Entry fee USD', 'رسم الدخول')}><input type="number" style={inputStyle} value={(form.entry_fee_usd as number) || ''} onChange={e => setForm(p => ({ ...p, entry_fee_usd: Number(e.target.value) }))} /></Field>
        </div>
        <Field label={t('Duration (hrs)', 'المدة')}><input type="number" step="0.5" style={inputStyle} value={(form.duration_hours as number) || ''} onChange={e => setForm(p => ({ ...p, duration_hours: Number(e.target.value) }))} /></Field>
        <Field label={t('Attraction Image', 'صورة المعلم')}>
          <ImageUploader folder="attractions" value={(form.image_url as string) || ''} onChange={(url) => setForm(p => ({ ...p, image_url: url }))} />
        </Field>
        <Field label={t('Description', 'الوصف')}><textarea style={{ ...inputStyle, minHeight: 70 }} value={(form.description as string) || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Latitude', 'خط العرض')}><input type="number" step="any" style={inputStyle} value={(form.latitude as number) || ''} onChange={e => setForm(p => ({ ...p, latitude: Number(e.target.value) }))} /></Field>
          <Field label={t('Longitude', 'خط الطول')}><input type="number" step="any" style={inputStyle} value={(form.longitude as number) || ''} onChange={e => setForm(p => ({ ...p, longitude: Number(e.target.value) }))} /></Field>
        </div>
      </div>
    );
    if (tab === 'restaurants') return (
      <div>
        <Field label={t('Name', 'الاسم')}><input style={inputStyle} value={(form.name as string) || ''} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></Field>
        <Field label={t('Name (Arabic)', 'الاسم بالعربية')}><input style={inputStyle} value={(form.name_ar as string) || ''} onChange={e => setForm(p => ({ ...p, name_ar: e.target.value }))} /></Field>
        <Field label={t('City', 'المدينة')}>
          <select style={inputStyle} value={(form.city_id as string) || ''} onChange={e => setForm(p => ({ ...p, city_id: e.target.value }))}>
            <option value="">{t('Select city', 'اختر مدينة')}</option>
            {cities.map(c => <option key={c.id as string} value={c.id as string}>{c.name as string}</option>)}
          </select>
        </Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Cuisine', 'المطبخ')}><input style={inputStyle} value={(form.cuisine as string) || ''} onChange={e => setForm(p => ({ ...p, cuisine: e.target.value }))} /></Field>
          <Field label={t('Price (1-4)', 'السعر')}><input type="number" min={1} max={4} style={inputStyle} value={(form.price_range as number) || ''} onChange={e => setForm(p => ({ ...p, price_range: Number(e.target.value) }))} /></Field>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Avg meal USD', 'متوسط الوجبة')}><input type="number" style={inputStyle} value={(form.avg_meal_usd as number) || ''} onChange={e => setForm(p => ({ ...p, avg_meal_usd: Number(e.target.value) }))} /></Field>
          <Field label={t('Rating', 'التقييم')}><input type="number" step="0.1" min={0} max={5} style={inputStyle} value={(form.rating as number) || ''} onChange={e => setForm(p => ({ ...p, rating: Number(e.target.value) }))} /></Field>
        </div>
        <Field label={t('Restaurant Image', 'صورة المطعم')}>
          <ImageUploader folder="restaurants" value={(form.image_url as string) || ''} onChange={(url) => setForm(p => ({ ...p, image_url: url }))} />
        </Field>
        <Field label={t('Description', 'الوصف')}><textarea style={{ ...inputStyle, minHeight: 70 }} value={(form.description as string) || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></Field>
        <Field label={t('Popular dishes (comma)', 'أطباق شهيرة')}><input style={inputStyle} value={Array.isArray(form.popular_dishes) ? (form.popular_dishes as string[]).join(', ') : (form.popular_dishes as string) || ''} onChange={e => setForm(p => ({ ...p, popular_dishes: e.target.value }))} /></Field>
        <Field label={t('Phone', 'الهاتف')}><input style={inputStyle} value={(form.phone as string) || ''} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Latitude', 'خط العرض')}><input type="number" step="any" style={inputStyle} value={(form.latitude as number) || ''} onChange={e => setForm(p => ({ ...p, latitude: Number(e.target.value) }))} /></Field>
          <Field label={t('Longitude', 'خط الطول')}><input type="number" step="any" style={inputStyle} value={(form.longitude as number) || ''} onChange={e => setForm(p => ({ ...p, longitude: Number(e.target.value) }))} /></Field>
        </div>
      </div>
    );
    if (tab === 'cities') return (
      <div>
        <Field label={t('Name', 'الاسم')}><input style={inputStyle} value={(form.name as string) || ''} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></Field>
        <Field label={t('Name (Arabic)', 'الاسم بالعربية')}><input style={inputStyle} value={(form.name_ar as string) || ''} onChange={e => setForm(p => ({ ...p, name_ar: e.target.value }))} /></Field>
        <Field label={t('Slug', 'الرابط')}><input style={inputStyle} value={(form.slug as string) || ''} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} /></Field>
        <Field label={t('Description', 'الوصف')}><textarea style={{ ...inputStyle, minHeight: 60 }} value={(form.description as string) || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></Field>
        <Field label={t('City Image', 'صورة المدينة')}>
          <ImageUploader folder="cities" value={(form.image_url as string) || ''} onChange={(url) => setForm(p => ({ ...p, image_url: url }))} />
        </Field>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
          <Field label={t('Latitude', 'خط العرض')}><input type="number" step="any" style={inputStyle} value={(form.latitude as number) || ''} onChange={e => setForm(p => ({ ...p, latitude: Number(e.target.value) }))} /></Field>
          <Field label={t('Longitude', 'خط الطول')}><input type="number" step="any" style={inputStyle} value={(form.longitude as number) || ''} onChange={e => setForm(p => ({ ...p, longitude: Number(e.target.value) }))} /></Field>
        </div>
      </div>
    );
    return null;
  };

  const renderRows = () => {
    if (loading) return (
      <div style={{ textAlign: 'center', padding: '4rem 2rem' }}>
        <Loader2 className="animate-spin" style={{ width: 28, height: 28, color: 'var(--primary)', margin: '0 auto' }} />
      </div>
    );
    if (filtered.length === 0) return (
      <div style={{ textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-muted)' }}>
        <currentTab.icon style={{ width: 40, height: 40, color: currentTab.color, opacity: 0.3, margin: '0 auto 0.85rem' }} />
        <p style={{ fontSize: '0.92rem', fontWeight: 600 }}>
          {search ? t('No results match your search', 'لا توجد نتائج مطابقة') : t('No data found', 'لا توجد بيانات')}
        </p>
      </div>
    );

    return (
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{
          display: 'none',
          padding: '0.75rem 1rem',
          fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em',
          color: 'var(--text-muted)', borderBottom: '1px solid var(--border)',
        }} className="admin-thead">
          {/* fills filled per tab via JSX below */}
        </div>

        {filtered.map((item, idx) => {
          const baseRowStyle: React.CSSProperties = {
            display: 'grid', gap: '0.6rem', alignItems: 'center',
            padding: '0.85rem 1rem',
            background: idx % 2 === 0 ? 'var(--bg-card)' : 'var(--bg-section)',
            transition: 'background 0.15s',
          };
          const editBtn = (
            <button onClick={() => openEdit(item)} title={t('Edit', 'تعديل')} style={{
              padding: '0.45rem', borderRadius: '0.5rem',
              background: 'rgba(200,134,10,0.12)', color: 'var(--primary)',
              border: 'none', cursor: 'pointer', fontFamily: 'inherit',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Pencil style={{ width: 14, height: 14 }} />
            </button>
          );
          const delBtn = (
            <button onClick={() => handleDelete(item.id as string)} title={t('Delete', 'حذف')} style={{
              padding: '0.45rem', borderRadius: '0.5rem',
              background: 'rgba(231,76,60,0.12)', color: 'var(--danger)',
              border: 'none', cursor: 'pointer', fontFamily: 'inherit',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Trash2 style={{ width: 14, height: 14 }} />
            </button>
          );

          if (tab === 'hotels') return (
            <div key={item.id as string} style={{ ...baseRowStyle, gridTemplateColumns: '1fr auto auto auto auto' }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.92rem', color: 'var(--text-dark)' }}>{item.name as string}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{(item.city as Row)?.name as string}</div>
              </div>
              <span style={{ display: 'inline-flex', gap: '0.1rem' }}>
                {Array.from({ length: item.star_rating as number }).map((_, i) => (
                  <Star key={i} style={{ width: 12, height: 12, color: 'var(--primary)', fill: 'var(--primary)' }} />
                ))}
              </span>
              <span style={{ fontWeight: 800, color: 'var(--primary)', fontSize: '0.9rem', whiteSpace: 'nowrap' }}>${item.price_per_night_usd as number}</span>
              <div style={{ display: 'flex', gap: '0.35rem' }}>{editBtn}{delBtn}</div>
            </div>
          );
          if (tab === 'attractions') return (
            <div key={item.id as string} style={{ ...baseRowStyle, gridTemplateColumns: '1fr auto auto auto' }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.92rem', color: 'var(--text-dark)' }}>{item.name as string}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{(item.city as Row)?.name as string} · {item.category as string}</div>
              </div>
              <span style={{ fontWeight: 800, color: 'var(--primary)', fontSize: '0.9rem', whiteSpace: 'nowrap' }}>${item.entry_fee_usd as number}</span>
              <div style={{ display: 'flex', gap: '0.35rem' }}>{editBtn}{delBtn}</div>
            </div>
          );
          if (tab === 'restaurants') return (
            <div key={item.id as string} style={{ ...baseRowStyle, gridTemplateColumns: '1fr auto auto auto auto' }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: '0.92rem', color: 'var(--text-dark)' }}>{item.name as string}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{(item.city as Row)?.name as string} · {item.cuisine as string}</div>
              </div>
              <span style={{ fontSize: '0.8rem', fontWeight: 800, color: 'var(--text-muted)' }}>{'$'.repeat(item.price_range as number)}</span>
              <span style={{ fontWeight: 800, color: 'var(--primary)', fontSize: '0.9rem', whiteSpace: 'nowrap' }}>~${item.avg_meal_usd as number}</span>
              <div style={{ display: 'flex', gap: '0.35rem' }}>{editBtn}{delBtn}</div>
            </div>
          );
          if (tab === 'cities') return (
            <div key={item.id as string} style={{ ...baseRowStyle, gridTemplateColumns: '1fr 1fr auto' }}>
              <div style={{ fontWeight: 700, color: 'var(--text-dark)', fontSize: '0.92rem' }}>{item.name as string}</div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{item.slug as string}</div>
              <div style={{ display: 'flex', gap: '0.35rem' }}>{editBtn}{delBtn}</div>
            </div>
          );
          if (tab === 'users') return (
            <div key={item.id as string} style={{ ...baseRowStyle, gridTemplateColumns: '1fr auto auto auto auto' }}>
              <div style={{ fontWeight: 700, color: 'var(--text-dark)' }}>{(item.full_name as string) || t('No name', 'بلا اسم')}</div>
              <span style={{
                fontSize: '0.7rem', fontWeight: 700, padding: '0.2rem 0.55rem', borderRadius: 999,
                background: item.role === 'admin' ? 'rgba(200,134,10,0.15)' : 'rgba(100,100,100,0.1)',
                color: item.role === 'admin' ? 'var(--primary)' : 'var(--text-muted)',
                textTransform: 'uppercase', letterSpacing: '0.04em',
              }}>{item.role as string}</span>
              <span style={{ fontSize: '0.78rem', fontWeight: 700, color: item.is_banned ? 'var(--danger)' : 'var(--success)' }}>
                {item.is_banned ? t('Banned', 'محظور') : t('Active', 'نشط')}
              </span>
              <button onClick={() => toggleBan(item.id as string, item.is_banned as boolean)} style={{
                padding: '0.35rem 0.7rem', borderRadius: '0.5rem',
                background: item.is_banned ? 'rgba(39,174,96,0.12)' : 'rgba(231,76,60,0.12)',
                color: item.is_banned ? 'var(--success)' : 'var(--danger)',
                border: 'none', cursor: 'pointer', fontSize: '0.72rem', fontWeight: 700, fontFamily: 'inherit',
                display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
              }}>
                {item.is_banned ? <Check style={{ width: 12, height: 12 }} /> : <Ban style={{ width: 12, height: 12 }} />}
                {item.is_banned ? t('Unban', 'فك') : t('Ban', 'حظر')}
              </button>
              <button onClick={() => toggleRole(item.id as string, item.role as string)} style={{
                padding: '0.35rem 0.7rem', borderRadius: '0.5rem',
                background: 'rgba(200,134,10,0.1)', color: 'var(--primary)',
                border: 'none', cursor: 'pointer', fontSize: '0.72rem', fontWeight: 700, fontFamily: 'inherit',
              }}>
                {item.role === 'admin' ? t('Demote', 'إنزال') : t('Promote', 'ترقية')}
              </button>
            </div>
          );
          if (tab === 'complaints') {
            const expanded = expandedComplaint === (item.id as string);
            return (
              <div key={item.id as string} style={{ ...baseRowStyle, display: 'block' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '0.6rem', alignItems: 'center' }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 700, color: 'var(--text-dark)', fontSize: '0.92rem' }}>{item.subject as string}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{item.user_email as string} · {item.category as string}</div>
                  </div>
                  <select value={item.status as string} onChange={e => updateComplaint(item.id as string, { status: e.target.value })}
                    style={{ ...inputStyle, padding: '0.35rem 0.5rem', fontSize: '0.78rem', width: 'auto' }}>
                    {['pending', 'reviewed', 'forwarded', 'resolved'].map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  <button onClick={() => setExpandedComplaint(expanded ? null : (item.id as string))} style={{
                    padding: '0.4rem', borderRadius: '0.5rem', background: 'rgba(200,134,10,0.1)',
                    color: 'var(--primary)', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                  }}>
                    {expanded ? <ChevronUp style={{ width: 14, height: 14 }} /> : <ChevronDown style={{ width: 14, height: 14 }} />}
                  </button>
                </div>
                {expanded && (
                  <div style={{ marginTop: '0.7rem', padding: '0.85rem 1rem', background: 'var(--bg-card)', borderRadius: '0.6rem', fontSize: '0.85rem', color: 'var(--text-body)', lineHeight: 1.6, border: '1px solid var(--border)' }}>
                    {item.description as string}
                  </div>
                )}
              </div>
            );
          }
          if (tab === 'bookings') {
            const proofUrl = item.payment_proof_url as string | null;
            const method = item.payment_method as string | null;
            const status = item.status as string;
            const txn = item.payment_transaction_id as string | null;
            const code = refCode('HTL', item.id as string);
            const isPending = status === 'pending';
            return (
              <div key={item.id as string} style={{ ...baseRowStyle, display: 'block' }}>
                <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '0.6rem' }}>
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{ fontWeight: 700, color: 'var(--text-dark)', fontSize: '0.92rem' }}>
                      {(item.hotel as Row)?.name as string}
                      <span style={{ marginInlineStart: '0.5rem', fontSize: '0.7rem', color: 'var(--primary)', fontFamily: 'monospace', fontWeight: 700 }}>
                        {code}
                      </span>
                    </div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{item.check_in as string} → {item.check_out as string} · {item.guests as number} {t('guests', 'ضيف')}</div>
                  </div>
                  {method && (
                    <span style={{
                      fontSize: '0.7rem', fontWeight: 700, padding: '0.2rem 0.55rem', borderRadius: 999,
                      background: method === 'instapay' ? 'rgba(108,92,231,0.12)' : 'rgba(39,174,96,0.12)',
                      color: method === 'instapay' ? '#6c5ce7' : '#27ae60',
                      textTransform: 'uppercase', letterSpacing: '0.04em',
                    }}>
                      {method === 'instapay' ? 'InstaPay' : t('Card', 'بطاقة')}
                    </span>
                  )}
                  <span style={{ fontWeight: 800, color: 'var(--primary)' }}>${item.total_price_usd as number}</span>
                  <span style={{
                    fontSize: '0.7rem', fontWeight: 700, padding: '0.2rem 0.55rem', borderRadius: 999,
                    background: status === 'confirmed' ? 'rgba(39,174,96,0.15)' : status === 'cancelled' ? 'rgba(231,76,60,0.15)' : 'rgba(243,156,18,0.18)',
                    color: status === 'confirmed' ? '#27ae60' : status === 'cancelled' ? '#e74c3c' : '#d97706',
                    textTransform: 'uppercase', letterSpacing: '0.04em',
                  }}>{status}</span>
                </div>
                {(txn || proofUrl || isPending) && (
                  <div style={{
                    display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '0.6rem',
                    marginTop: '0.7rem', paddingTop: '0.7rem',
                    borderTop: '1px solid var(--border-light)',
                  }}>
                    {txn && (
                      <span style={{
                        fontSize: '0.75rem', color: 'var(--text-muted)',
                        fontFamily: 'monospace',
                        padding: '0.3rem 0.6rem', borderRadius: '0.4rem',
                        background: 'var(--bg-card)', border: '1px solid var(--border-light)',
                      }}>
                        TXN: <strong style={{ color: 'var(--text-dark)' }}>{txn}</strong>
                      </span>
                    )}
                    {proofUrl && (
                      <button onClick={() => setProofImage(proofUrl)} style={{
                        padding: '0.4rem 0.85rem', borderRadius: '0.5rem',
                        background: 'rgba(108,92,231,0.12)', color: '#6c5ce7',
                        border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                        fontSize: '0.78rem', fontWeight: 700,
                        display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                      }}>
                        📸 {t('View screenshot', 'عرض الإيصال')}
                      </button>
                    )}
                    <div style={{ display: 'flex', gap: '0.4rem', marginInlineStart: 'auto' }}>
                      {isPending && (
                        <button onClick={() => updateBookingStatus(item.id as string, 'confirmed')} style={{
                          padding: '0.45rem 0.95rem', borderRadius: '0.5rem',
                          background: 'linear-gradient(135deg, #27ae60, #16a34a)', color: '#fff',
                          border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                          fontSize: '0.78rem', fontWeight: 800,
                          display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                          boxShadow: '0 4px 10px rgba(39,174,96,0.35)',
                        }}>
                          <Check style={{ width: 14, height: 14 }} /> {t('Approve', 'موافقة')}
                        </button>
                      )}
                      {status !== 'cancelled' && (
                        <button onClick={() => updateBookingStatus(item.id as string, 'cancelled')} style={{
                          padding: '0.45rem 0.85rem', borderRadius: '0.5rem',
                          background: 'rgba(231,76,60,0.12)', color: '#e74c3c',
                          border: 'none', cursor: 'pointer', fontFamily: 'inherit',
                          fontSize: '0.78rem', fontWeight: 700,
                          display: 'inline-flex', alignItems: 'center', gap: '0.3rem',
                        }}>
                          <X style={{ width: 14, height: 14 }} /> {t('Reject', 'رفض')}
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          }
          return null;
        })}
      </div>
    );
  };

  const showAddBtn = ['hotels', 'attractions', 'restaurants', 'cities'].includes(tab);
  const tabStats = tabs.map(tb => ({
    ...tb,
    count: tb.key === tab ? data.length : null,
  }));

  return (
    <div style={{ minHeight: '100vh', padding: '100px 1.25rem 4rem', background: 'var(--bg-main)' }} dir={isAr ? 'rtl' : 'ltr'}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>

        <div style={{
          background: 'linear-gradient(135deg, #0f1729 0%, #1e293b 50%, #7f1d1d 130%)',
          borderRadius: '1.25rem', padding: '1.5rem 1.75rem',
          color: '#fff', position: 'relative', overflow: 'hidden', marginBottom: '1.25rem',
          boxShadow: '0 24px 50px rgba(15,23,41,0.3)',
          border: '1px solid rgba(220,38,38,0.25)',
        }}>
          <div style={{ position: 'absolute', top: -40, insetInlineEnd: -40, width: 180, height: 180, borderRadius: '50%', background: 'radial-gradient(circle, rgba(220,38,38,0.18), transparent 70%)' }} />
          <div style={{ position: 'absolute', bottom: -40, insetInlineStart: 40, width: 140, height: 140, borderRadius: '50%', background: 'radial-gradient(circle, rgba(59,130,246,0.1), transparent 70%)' }} />

          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <div style={{
                  width: 44, height: 44, borderRadius: '0.6rem',
                  background: 'linear-gradient(135deg, #dc2626, #991b1b)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: '0 8px 20px rgba(220,38,38,0.5)',
                }}>
                  <ShieldAlert style={{ width: 22, height: 22, color: '#fff' }} />
                </div>
                <div>
                  <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.2rem' }}>
                    <span style={{
                      fontSize: '0.65rem', fontWeight: 800, letterSpacing: '0.12em',
                      padding: '0.18rem 0.5rem', borderRadius: '0.3rem',
                      background: 'rgba(220,38,38,0.25)', color: '#fca5a5',
                      border: '1px solid rgba(220,38,38,0.35)', textTransform: 'uppercase',
                    }}>
                      <Activity style={{ width: 10, height: 10, display: 'inline', marginInlineEnd: '0.2rem' }} />
                      {t('Admin Console', 'وحدة التحكم')}
                    </span>
                  </div>
                  <h1 style={{ fontSize: '1.4rem', fontWeight: 900, lineHeight: 1 }}>
                    {currentTab.label}
                  </h1>
                </div>
              </div>
              {showAddBtn && (
                <button onClick={openAdd} style={{
                  padding: '0.65rem 1.15rem', borderRadius: '0.55rem',
                  background: '#fff', color: '#0f1729', fontWeight: 800, fontSize: '0.85rem',
                  border: 'none', cursor: 'pointer',
                  display: 'inline-flex', alignItems: 'center', gap: '0.4rem',
                  fontFamily: 'inherit', boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
                }}>
                  <Plus style={{ width: 15, height: 15 }} /> {t('New entry', 'سجل جديد')}
                </button>
              )}
            </div>

            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: '0.6rem',
              padding: '0.85rem 1rem', borderRadius: '0.65rem',
              background: 'rgba(0,0,0,0.3)', backdropFilter: 'blur(8px)',
              border: '1px solid rgba(255,255,255,0.06)',
            }}>
              {[
                { value: globalStats.users, label: t('Users', 'مستخدمون'), color: '#60a5fa' },
                { value: globalStats.bookings, label: t('Bookings', 'حجوزات'), color: '#34d399' },
                { value: globalStats.complaints, label: t('Pending Tickets', 'تذاكر معلقة'), color: '#fbbf24' },
                { value: '$' + globalStats.revenue.toLocaleString(), label: t('Revenue', 'الإيرادات'), color: '#f87171' },
                { value: data.length, label: t('Current rows', 'في الجدول'), color: '#a78bfa' },
              ].map(s => (
                <div key={s.label} style={{ display: 'flex', flexDirection: 'column', borderInlineStart: `2px solid ${s.color}`, paddingInlineStart: '0.65rem' }}>
                  <div style={{ fontSize: '1.1rem', fontWeight: 900, color: '#fff', lineHeight: 1.1, fontFamily: 'monospace' }}>{s.value}</div>
                  <div style={{ fontSize: '0.66rem', opacity: 0.6, textTransform: 'uppercase', letterSpacing: '0.05em', marginTop: '0.15rem' }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{
          display: 'flex', gap: '0.4rem', marginBottom: '1rem',
          overflowX: 'auto', paddingBottom: '0.5rem',
        }}>
          {tabStats.map(tb => {
            const active = tab === tb.key;
            return (
              <button key={tb.key} onClick={() => setTab(tb.key)} style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.45rem',
                padding: '0.6rem 1.1rem', borderRadius: '0.7rem',
                fontSize: '0.85rem', fontWeight: 700, fontFamily: 'inherit',
                cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0,
                border: active ? `1px solid ${tb.color}` : '1px solid var(--border)',
                background: active ? `${tb.color}15` : 'var(--bg-card)',
                color: active ? tb.color : 'var(--text-body)',
                transition: 'all 0.15s',
              }}>
                <tb.icon style={{ width: 14, height: 14 }} /> {tb.label}
              </button>
            );
          })}
        </div>

        {data.length > 5 && (
          <div style={{ marginBottom: '0.85rem', position: 'relative' }}>
            <Search style={{
              position: 'absolute', insetInlineStart: 14, top: '50%', transform: 'translateY(-50%)',
              width: 16, height: 16, color: 'var(--text-muted)',
            }} />
            <input
              type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder={t(`Search ${currentTab.label.toLowerCase()}...`, `بحث في ${currentTab.label}...`)}
              style={{
                width: '100%', padding: '0.7rem 1rem 0.7rem 2.6rem',
                borderRadius: '0.7rem', border: '1px solid var(--border)',
                background: 'var(--bg-card)', fontSize: '0.9rem',
                color: 'var(--text-dark)', fontFamily: 'inherit',
              }}
            />
          </div>
        )}

        <div style={{
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          borderRadius: '1rem', overflow: 'hidden',
        }}>
          {renderRows()}
        </div>

        {proofImage && (
          <div onClick={() => setProofImage(null)} style={{
            position: 'fixed', inset: 0, zIndex: 100,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: '1rem', background: 'rgba(0,0,0,0.85)',
            cursor: 'zoom-out',
          }}>
            <img src={proofImage} alt="payment proof" style={{ maxWidth: '100%', maxHeight: '90vh', objectFit: 'contain', borderRadius: '0.75rem' }}
              onClick={e => e.stopPropagation()} />
            <button onClick={() => setProofImage(null)} style={{
              position: 'absolute', top: 20, insetInlineEnd: 20,
              width: 40, height: 40, borderRadius: '50%',
              background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)',
              border: '1px solid rgba(255,255,255,0.2)', cursor: 'pointer',
              color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <X style={{ width: 18, height: 18 }} />
            </button>
          </div>
        )}

        {modal.open && (
          <div style={{
            position: 'fixed', inset: 0, zIndex: 100,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: '1rem', animation: 'fadeIn 0.15s ease',
          }}>
            <div onClick={() => setModal({ open: false, editing: null })}
              style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }} />
            <div style={{
              position: 'relative',
              background: 'var(--bg-card)', border: '1px solid var(--border)',
              borderRadius: '1.25rem',
              width: '100%', maxWidth: 580, maxHeight: '88vh',
              display: 'flex', flexDirection: 'column',
              boxShadow: '0 24px 60px rgba(0,0,0,0.25)',
              animation: 'scaleIn 0.18s ease',
            }}>
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: '0.5rem',
                    background: `${currentTab.color}1f`, color: currentTab.color,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <currentTab.icon style={{ width: 18, height: 18 }} />
                  </div>
                  <h3 style={{ fontWeight: 800, fontSize: '1.1rem', color: 'var(--text-dark)' }}>
                    {modal.editing ? t('Edit', 'تعديل') : t('Add new', 'إضافة جديد')}
                  </h3>
                </div>
                <button onClick={() => setModal({ open: false, editing: null })}
                  style={{ padding: '0.5rem', borderRadius: '0.5rem', background: 'var(--bg-section)', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}>
                  <X style={{ width: 16, height: 16 }} />
                </button>
              </div>
              <div style={{ padding: '1.25rem 1.5rem', overflowY: 'auto', flex: 1 }}>
                {renderForm()}
              </div>
              <div style={{
                display: 'flex', gap: '0.6rem',
                padding: '1rem 1.5rem', borderTop: '1px solid var(--border)',
                background: 'var(--bg-section)',
              }}>
                <button onClick={() => setModal({ open: false, editing: null })}
                  style={{
                    flex: 1, padding: '0.7rem', borderRadius: '0.6rem',
                    background: 'var(--bg-card)', border: '1px solid var(--border)',
                    color: 'var(--text-body)', fontWeight: 700, fontSize: '0.9rem',
                    cursor: 'pointer', fontFamily: 'inherit',
                  }}>
                  {t('Cancel', 'إلغاء')}
                </button>
                <button onClick={handleSave} className="btn-primary" style={{ flex: 1.5, padding: '0.7rem', justifyContent: 'center' }}>
                  {t('Save', 'حفظ')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
