ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS payment_transaction_id TEXT;
