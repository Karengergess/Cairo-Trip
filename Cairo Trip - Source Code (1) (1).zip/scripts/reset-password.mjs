#!/usr/bin/env node
// Reset a user's password by email. Uses admin Supabase API.
// Run: node scripts/reset-password.mjs <email> <new_password>

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const [email, newPassword] = process.argv.slice(2);
if (!email || !newPassword) {
  console.error('Usage: node scripts/reset-password.mjs <email> <new_password>');
  process.exit(1);
}
if (newPassword.length < 6) {
  console.error('Password must be at least 6 characters.');
  process.exit(1);
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('Missing env vars in .env.local'); process.exit(1); }

const supa = createClient(url, key, { auth: { persistSession: false } });

const { data, error } = await supa.auth.admin.listUsers();
if (error) { console.error(error.message); process.exit(1); }

const user = data.users.find(u => (u.email || '').toLowerCase() === email.toLowerCase());
if (!user) { console.error(`No user with email ${email}`); process.exit(1); }

const { error: updErr } = await supa.auth.admin.updateUserById(user.id, { password: newPassword });
if (updErr) { console.error(updErr.message); process.exit(1); }

console.log(`Password updated for ${email}.`);
