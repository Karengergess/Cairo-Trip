#!/usr/bin/env node
// Removes duplicates from hotels, attractions, restaurants.
// Keeps the OLDEST row per (name + city_id), deletes the rest.
// Run: node scripts/dedupe-all.mjs

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('Missing env vars'); process.exit(1); }
const supa = createClient(url, key, { auth: { persistSession: false } });

async function dedupeTable(table) {
  const { data, error } = await supa
    .from(table)
    .select('id, name, city_id, created_at')
    .order('created_at', { ascending: true });
  if (error) { console.error(`${table}:`, error.message); return; }

  const seen = new Map();
  const toDelete = [];
  for (const row of data) {
    const k = `${row.name}|${row.city_id}`;
    if (seen.has(k)) toDelete.push(row.id);
    else seen.set(k, row.id);
  }

  if (toDelete.length === 0) {
    console.log(`${table}: ${data.length} rows, no duplicates.`);
    return;
  }

  const { error: delErr } = await supa.from(table).delete().in('id', toDelete);
  if (delErr) console.error(`${table} delete:`, delErr.message);
  else console.log(`${table}: kept ${seen.size}, deleted ${toDelete.length}`);
}

console.log('Deduping...\n');
await dedupeTable('hotels');
await dedupeTable('attractions');
await dedupeTable('restaurants');
console.log('\nDone.');
