#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('Missing env vars'); process.exit(1); }
const supabase = createClient(url, key, { auth: { persistSession: false } });

console.log('Deduping restaurants...\n');

const { data, error } = await supabase
  .from('restaurants')
  .select('id, name, city_id, created_at')
  .order('created_at', { ascending: true });
if (error) { console.error(error); process.exit(1); }

const seen = new Map();
const toDelete = [];
for (const r of data) {
  const k = `${r.name}|${r.city_id}`;
  if (seen.has(k)) toDelete.push(r.id);
  else seen.set(k, r.id);
}

console.log(`Found ${data.length} rows, ${toDelete.length} duplicates.`);
if (toDelete.length === 0) { console.log('Nothing to delete.'); process.exit(0); }

const { error: delErr } = await supabase.from('restaurants').delete().in('id', toDelete);
if (delErr) { console.error(delErr); process.exit(1); }
console.log(`Deleted ${toDelete.length} duplicates. Kept ${seen.size} unique restaurants.`);
