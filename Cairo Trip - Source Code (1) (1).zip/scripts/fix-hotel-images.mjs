#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('❌ Missing env vars'); process.exit(1); }
const supabase = createClient(url, key, { auth: { persistSession: false } });

// 24 verified-working Unsplash photo IDs of hotels/resorts/rooms.
const HOTEL_PHOTOS = [
  '1551882547-ff40c63fe5fa', '1564501049412-61c2a3083791', '1582719508461-905c673771fd',
  '1566073771259-6a8506099945', '1542314831-068cd1dbfeeb', '1455587734955-081b22074882',
  '1611892440504-42a792e24d32', '1571003123894-1f0594d2b5d9', '1520250497591-112f2f40a3f4',
  '1540541338287-41700207dee6', '1571896349842-33c89424de2d', '1582719478250-c89cae4dc85b',
  '1578683010236-d716f9a3f461', '1559599238-308793637427', '1555854877-bab0e564b8d5',
  '1568084680786-a84f91d1153c', '1518733057094-95b53143d2a7', '1541625602330-2277a4c46182',
  '1602002418816-5c0aeef426aa', '1631049307264-da0ec9d70304', '1590490360182-c33d57733427',
  '1559592413-7cec4d0cae2b', '1606402179428-a57976d71fa4', '1564013799919-ab600027ffc6',
];

function hash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h) + s.charCodeAt(i) | 0;
  return Math.abs(h);
}

async function main() {
  console.log('🏨 Setting verified hotel photos...\n');

  const { data: hotels, error } = await supabase.from('hotels').select('id, name');
  if (error) throw error;

  let ok = 0;
  const sorted = [...hotels].sort((a, b) => hash(a.name) - hash(b.name));
  for (let i = 0; i < sorted.length; i++) {
    const photoId = HOTEL_PHOTOS[i % HOTEL_PHOTOS.length];
    const image_urls = [`https://images.unsplash.com/photo-${photoId}?w=1000&q=80`];
    const { error: e } = await supabase.from('hotels').update({ image_urls }).eq('id', sorted[i].id);
    if (e) console.log(`  ❌ ${sorted[i].name}: ${e.message}`);
    else { console.log(`  ✓ ${sorted[i].name}`); ok++; }
  }
  console.log(`\n✨ Done. ${ok}/${hotels.length} hotels updated.`);
}

main().catch(e => { console.error('❌', e); process.exit(1); });
