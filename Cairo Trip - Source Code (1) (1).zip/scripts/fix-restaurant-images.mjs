#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('❌ Missing env vars'); process.exit(1); }
const supabase = createClient(url, key, { auth: { persistSession: false } });

// 23 verified-working food/restaurant Unsplash photo IDs (HTTP 200 confirmed).
const ALL = [
  '1414235077428-338989a2e8c0', '1565299624946-b28f40a0ae38', '1546069901-ba9599a7e63c',
  '1555396273-367ea4eb4db5', '1565958011703-44f9829ba187', '1567521464027-f127ff144326',
  '1551218808-94e220e084d2', '1517248135467-4c7edcad34c4', '1574484284002-952d92456975',
  '1514933651103-005eec06c04b', '1604382354936-07c5d9983bd3', '1571997478779-2adcbbe9ab2f',
  '1525755662778-989d0524087e', '1551183053-bf91a1d81141', '1547573854-74d2a71d0826',
  '1467003909585-2f8a72700288', '1583394293214-28ded15ee548', '1596463059283-da257325bab8',
  '1559314809-0d155014e29e', '1526318896980-cf78c088247c', '1555939594-58d7cb561ad1',
  '1493770348161-369560ae357d', '1555982105-d25af4182e4e',
];

const BY_CUISINE = {
  'Egyptian':       ['1546069901-ba9599a7e63c', '1565958011703-44f9829ba187', '1467003909585-2f8a72700288', '1414235077428-338989a2e8c0'],
  'Street Food':    ['1565299624946-b28f40a0ae38', '1565958011703-44f9829ba187', '1583394293214-28ded15ee548'],
  'Mediterranean':  ['1551183053-bf91a1d81141', '1574484284002-952d92456975', '1467003909585-2f8a72700288'],
  'Seafood':        ['1547573854-74d2a71d0826', '1551218808-94e220e084d2', '1559314809-0d155014e29e'],
  'Italian':        ['1604382354936-07c5d9983bd3', '1571997478779-2adcbbe9ab2f', '1555396273-367ea4eb4db5'],
  'Thai':           ['1525755662778-989d0524087e', '1559314809-0d155014e29e', '1596463059283-da257325bab8'],
  'Nubian':         ['1551183053-bf91a1d81141', '1467003909585-2f8a72700288', '1574484284002-952d92456975'],
  'Fine Dining':    ['1517248135467-4c7edcad34c4', '1514933651103-005eec06c04b', '1493770348161-369560ae357d'],
};

function hash(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h) + s.charCodeAt(i) | 0;
  return Math.abs(h);
}

async function main() {
  console.log('🍽  Setting verified food photos by cuisine...\n');

  const { data: restaurants, error } = await supabase.from('restaurants').select('id, name, cuisine');
  if (error) throw error;

  let ok = 0;
  for (const r of restaurants) {
    const pool = BY_CUISINE[r.cuisine] || ALL;
    const photoId = pool[hash(r.name + r.cuisine) % pool.length];
    const image_url = `https://images.unsplash.com/photo-${photoId}?w=1000&q=80`;
    const { error: e } = await supabase.from('restaurants').update({ image_url }).eq('id', r.id);
    if (e) console.log(`  ❌ ${r.name}: ${e.message}`);
    else { console.log(`  ✓ ${r.name} (${r.cuisine})`); ok++; }
  }
  console.log(`\n✨ Done. ${ok}/${restaurants.length} restaurants updated.`);
}

main().catch(e => { console.error('❌', e); process.exit(1); });
