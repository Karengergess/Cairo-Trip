#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('❌ Missing env vars'); process.exit(1); }
const supabase = createClient(url, key, { auth: { persistSession: false } });

const UA = 'EgyptTripPlanner/1.0 (https://egypt-trip-planner.vercel.app; admin@egypttripplanner.app)';

const FALLBACKS = {
  'Great_Pyramid_of_Giza': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Kheops-Pyramid.jpg/1024px-Kheops-Pyramid.jpg',
  'Great_Sphinx_of_Giza': 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Great_Sphinx_of_Giza_-_20080716a.jpg/1024px-Great_Sphinx_of_Giza_-_20080716a.jpg',
  'Karnak': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Karnak_Tempel_05.jpg/1024px-Karnak_Tempel_05.jpg',
  'Luxor_Temple': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/Luxor_Temple%2C_Egypt%2C_July_2007.jpg/1024px-Luxor_Temple%2C_Egypt%2C_July_2007.jpg',
  'Valley_of_the_Kings': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/Valley_of_the_Kings_panorama.jpg/1024px-Valley_of_the_Kings_panorama.jpg',
  'Mortuary_Temple_of_Hatshepsut': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/Hatschepsut-Tempel_Luxor_2016-03-13zhh.jpg/1024px-Hatschepsut-Tempel_Luxor_2016-03-13zhh.jpg',
  'Philae': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Egypt-9A-039_-_Temple_of_Isis_%282217360263%29.jpg/1024px-Egypt-9A-039_-_Temple_of_Isis_%282217360263%29.jpg',
  'Aswan_Dam': 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Hochd%C3%A4mme_Assuan.jpg/1024px-Hochd%C3%A4mme_Assuan.jpg',
  'Cairo_Tower': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Cairo_Tower_at_night_2007.jpg/1024px-Cairo_Tower_at_night_2007.jpg',
  'Grand_Egyptian_Museum': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Grand_Egyptian_Museum_view.jpg/1024px-Grand_Egyptian_Museum_view.jpg',
  'Egyptian_Museum': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Egyptian_Museum_in_Cairo.jpg/1024px-Egyptian_Museum_in_Cairo.jpg',
  'Khan_el-Khalili': 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Khan_el-Khalili_-_panoramio.jpg/1024px-Khan_el-Khalili_-_panoramio.jpg',
  'Al-Azhar_Mosque': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Cairo_Al_Azhar_Mosque.jpg/1024px-Cairo_Al_Azhar_Mosque.jpg',
  'Abu_Simbel_temples': 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Abu_Simbel%2C_Ramesses_Temple%2C_front%2C_Egypt%2C_Oct_2004.jpg/1024px-Abu_Simbel%2C_Ramesses_Temple%2C_front%2C_Egypt%2C_Oct_2004.jpg',
  'Mount_Sinai': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Mount_Sinai_Sunrise.jpg/1024px-Mount_Sinai_Sunrise.jpg',
  'Bibliotheca_Alexandrina': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Bibliotheca_Alexandrina_-_panoramio.jpg/1024px-Bibliotheca_Alexandrina_-_panoramio.jpg',
  'Citadel_of_Qaitbay': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Qaitbay_citadel.JPG/1024px-Qaitbay_citadel.JPG',
  'Catacombs_of_Kom_el_Shoqafa': 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Catacombs_of_Kom_el-Shoqafa.jpg/1024px-Catacombs_of_Kom_el-Shoqafa.jpg',
  'Montaza_Palace': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Mountazah-Palace.jpg/1024px-Mountazah-Palace.jpg',
  'Ras_Muhammad_National_Park': 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Ras_Mohamed_National_Park_-_Egypt.jpg/1024px-Ras_Mohamed_National_Park_-_Egypt.jpg',
  'Blue_Hole_(Red_Sea)': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Blue_Hole_Dahab.jpg/1024px-Blue_Hole_Dahab.jpg',
  // No-slug attractions: try by best-known name
  'Giftun_Island': 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Giftun_Island.jpg/1024px-Giftun_Island.jpg',
  'Naama_Bay': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Naama_Bay_-_Sharm_el_Sheikh%2C_Egypt.jpg/1024px-Naama_Bay_-_Sharm_el_Sheikh%2C_Egypt.jpg',
  'Hurghada_Marina': 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/Hurghada_marina.jpg/1024px-Hurghada_marina.jpg',
  'Three_Pools_Dahab': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/Blue_Hole_Dahab.jpg/1024px-Blue_Hole_Dahab.jpg',
  'Nubian_Village_Aswan': 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Aswan_Nubian_Village_4.jpg/1024px-Aswan_Nubian_Village_4.jpg',
};

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function getWikiThumb(slug) {
  if (!slug) return null;
  const u = `https://en.wikipedia.org/w/api.php?action=query&format=json&prop=pageimages&pithumbsize=1024&titles=${encodeURIComponent(slug)}&origin=*`;
  try {
    const r = await fetch(u, { headers: { 'User-Agent': UA, 'Api-User-Agent': UA } });
    if (!r.ok) return null;
    const text = await r.text();
    if (text.startsWith('You') || text.startsWith('<')) return null; // rate limited or HTML response
    const j = JSON.parse(text);
    const pages = j?.query?.pages || {};
    for (const id of Object.keys(pages)) {
      const src = pages[id]?.thumbnail?.source;
      if (src) return src;
    }
  } catch {
    // swallow
  }
  return null;
}

// Best-guess slug from attraction name (for no-slug entries)
function nameToSlug(name) {
  return name.replace(/\s+/g, '_').replace(/[^A-Za-z0-9_]/g, '');
}

async function main() {
  console.log('🖼  Fetching real Egyptian attraction photos (with delays & fallbacks)...\n');

  const { data: attractions, error } = await supabase
    .from('attractions')
    .select('id, name, wikipedia_slug, image_url')
    .order('name');
  if (error) throw error;

  let updated = 0, fallback = 0, missing = 0;
  for (const a of attractions) {
    const slug = a.wikipedia_slug || nameToSlug(a.name);

    // Try Wikipedia first
    await sleep(700);
    let thumb = await getWikiThumb(slug);

    // Fallback to hardcoded curated URLs
    if (!thumb) {
      thumb = FALLBACKS[slug] || FALLBACKS[nameToSlug(a.name)] || null;
      if (thumb) fallback++;
    }

    if (!thumb) {
      console.log(`  ⚠ ${a.name} → no image found, will show gradient placeholder`);
      // Clear the existing bad image so the gradient takes over
      await supabase.from('attractions').update({ image_url: null }).eq('id', a.id);
      missing++;
      continue;
    }

    const { error: upErr } = await supabase.from('attractions').update({ image_url: thumb }).eq('id', a.id);
    if (upErr) console.log(`  ❌ ${a.name}: ${upErr.message}`);
    else { console.log(`  ✓ ${a.name}`); updated++; }
  }

  console.log(`\n✨ Done. Wikipedia: ${updated - fallback}, Fallback: ${fallback}, Gradient: ${missing}`);
}

main().catch(e => { console.error('❌', e); process.exit(1); });
