#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('❌ Missing env vars in .env.local'); process.exit(1); }

const email = process.argv[2];
if (!email) { console.error('Usage: node scripts/make-admin.mjs <email>'); process.exit(1); }

const supabase = createClient(url, key, { auth: { persistSession: false } });

const { data, error } = await supabase.auth.admin.listUsers();
if (error) { console.error('❌', error.message); process.exit(1); }

const user = data.users.find(u => (u.email || '').toLowerCase() === email.toLowerCase());
if (!user) { console.error(`❌ No user with email ${email}. Have them sign up first.`); process.exit(1); }

const { error: upErr } = await supabase
  .from('profiles')
  .upsert({
    id: user.id,
    role: 'admin',
    full_name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'Admin',
    is_banned: false,
    preferred_language: 'en',
    preferred_currency: 'USD',
  }, { onConflict: 'id' });

if (upErr) { console.error('❌', upErr.message); process.exit(1); }
console.log(`✅ ${email} is now an admin.`);
