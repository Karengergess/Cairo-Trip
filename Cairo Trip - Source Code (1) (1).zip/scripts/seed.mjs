#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'seed-data');

for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url) {
  console.error('❌ Missing NEXT_PUBLIC_SUPABASE_URL in .env.local');
  process.exit(1);
}
if (!serviceKey) {
  console.error('❌ Missing SUPABASE_SERVICE_ROLE_KEY in .env.local');
  console.error('');
  console.error('To get it:');
  console.error('  1. Go to https://supabase.com/dashboard/project/' + (url.match(/\/\/([^.]+)/)?.[1] || 'YOUR_PROJECT') + '/settings/api');
  console.error('  2. Scroll to "Project API keys"');
  console.error('  3. Copy the "service_role" key (the SECRET one, not anon)');
  console.error('  4. Add this line to your .env.local file:');
  console.error('     SUPABASE_SERVICE_ROLE_KEY=eyJ...your-key-here');
  console.error('  5. Re-run: npm run seed');
  process.exit(1);
}

const supabase = createClient(url, serviceKey, { auth: { persistSession: false } });

function readJSON(name) {
  const p = path.join(DATA_DIR, name);
  if (!fs.existsSync(p)) return null;
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

async function getCityIdMap() {
  const { data, error } = await supabase.from('cities').select('id, slug');
  if (error) throw error;
  const map = {};
  for (const c of data) map[c.slug] = c.id;
  return map;
}

async function seedRestaurants() {
  const items = readJSON('restaurants.json');
  if (!items) return console.log('⏭  No restaurants.json - skipped');
  const cityMap = await getCityIdMap();

  const { data: existing } = await supabase.from('restaurants').select('name, city_id');
  const existingKey = new Set((existing || []).map(r => `${r.name}|${r.city_id}`));

  let inserted = 0, skipped = 0, failed = 0;
  for (const r of items) {
    const city_id = cityMap[r.city_slug];
    if (!city_id) { console.warn('  no city for', r.city_slug); failed++; continue; }
    const key = `${r.name}|${city_id}`;
    if (existingKey.has(key)) { skipped++; continue; }
    const { city_slug, ...rest } = r;
    const { error } = await supabase.from('restaurants').insert({ city_id, ...rest });
    if (error) { console.warn('  ', r.name, error.message); failed++; }
    else inserted++;
  }
  console.log(`✅ Restaurants: ${inserted} inserted, ${skipped} already-present, ${failed} failed`);
}

async function updateImagesFromFile(table, file, matchKey = 'name') {
  const items = readJSON(file);
  if (!items) return console.log(`⏭  No ${file} - skipped`);
  let ok = 0, fail = 0;
  for (const row of items) {
    const matchVal = row[matchKey];
    const { [matchKey]: _, ...updates } = row;
    const { error } = await supabase.from(table).update(updates).eq(matchKey, matchVal);
    if (error) { console.warn(`  ⚠ ${matchVal}:`, error.message); fail++; } else ok++;
  }
  console.log(`✅ ${table} updates: ${ok} ok, ${fail} failed`);
}

async function main() {
  console.log('🌱 Seeding via Supabase API...\n');

  await seedRestaurants();
  await updateImagesFromFile('hotels', 'hotels-image-fix.json', 'name');
  await updateImagesFromFile('attractions', 'attractions-image-fix.json', 'name');
  await updateImagesFromFile('restaurants', 'restaurants-image-fix.json', 'name');

  console.log('\n✨ Done.');
}

main().catch(err => { console.error('❌', err); process.exit(1); });
