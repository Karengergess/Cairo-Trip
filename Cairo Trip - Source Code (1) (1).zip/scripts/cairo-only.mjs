#!/usr/bin/env node
import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
for (const f of ['.env', '.env.local', '.env.development.local']) {
  const p = path.join(ROOT, f);
  if (fs.existsSync(p)) dotenv.config({ path: p, override: true });
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) { console.error('Missing env vars'); process.exit(1); }
const supabase = createClient(url, key, { auth: { persistSession: false } });

const KEEP = ['cairo', 'giza'];

console.log('🏛  Trimming everything outside Cairo + Giza...\n');

const { data: allCities } = await supabase.from('cities').select('id, slug, name');
const toDelete = (allCities || []).filter(c => !KEEP.includes(c.slug));
const ids = toDelete.map(c => c.id);

if (ids.length === 0) {
  console.log('Nothing to delete.');
} else {
  console.log('Deleting cities:', toDelete.map(c => c.name).join(', '));
  const { error } = await supabase.from('cities').delete().in('id', ids);
  if (error) { console.error(error); process.exit(1); }
  console.log(`✓ Removed ${ids.length} cities (and all their hotels/attractions/restaurants via CASCADE)`);
}

const HOTELS = [
  {
    name: 'Marriott Mena House', city: 'giza', name_ar: 'ماريوت مينا هاوس',
    description: 'Iconic 1869 palace hotel built as a royal hunting lodge, now 5-star luxury with the most famous Pyramid view in the world. Expect: 40-acre Khedival gardens, two pools (one with Pyramid backdrop), the Khan El Khalili-style Mughal Hall restaurant, the historic 139-Bar where Churchill drank, and rooms where Sinatra, the Aga Khan, and Princess Diana have stayed. Walk to the Pyramids in 5 minutes.',
    description_ar: 'فندق قصر تاريخي من ١٨٦٩ بُني كاستراحة ملكية للصيد، الآن فندق ٥ نجوم بأشهر إطلالة على الأهرامات في العالم. توقع: حدائق خديوية ٤٠ فدان، حمامين سباحة (واحد بإطلالة على الهرم)، مطعم القاعة المغولية بأسلوب خان الخليلي، بار ١٣٩ التاريخي اللي شرب فيه تشرشل، وغرف أقام فيها سيناترا والأغا خان والأميرة ديانا. هتمشي للأهرامات في ٥ دقائق.',
    star_rating: 5, price_per_night_usd: 280, rating: 4.7,
    amenities: ['Pool','Spa','Restaurant','Gym','Free WiFi','Parking','Pyramid View','Garden'],
    image_urls: ['https://images.unsplash.com/photo-1582719508461-905c673771fd?w=1200&q=80'],
    booking_url: 'https://www.marriott.com/en-us/hotels/caimn-marriott-mena-house-cairo/',
    latitude: 29.987, longitude: 31.1381,
  },
  {
    name: 'Four Seasons Nile Plaza', name_ar: 'فور سيزونز نايل بلازا', city: 'cairo',
    description: '5-star modern luxury on the Garden City Nile. Expect: rooms with floor-to-ceiling Nile windows, the only private rooftop infinity pool overlooking the river, 8 restaurants including Bella (Italian), Zitouni (Egyptian), and 8 (Asian), an award-winning spa with a hammam, and a 24-hour gym. Walking distance to Tahrir, the Egyptian Museum, and the new Coptic Cairo. Best for: business travelers, honeymoons, families with kids (great kids club).',
    description_ar: 'فخامة عصرية ٥ نجوم على نيل جاردن سيتي. توقع: غرف بنوافذ زجاجية كاملة على النيل، حمام السباحة الإنفينيتي الوحيد على السطح بإطلالة على النهر، ٨ مطاعم منها بيلا (إيطالي) وزيتوني (مصري) و٨ (آسيوي)، سبا حائز على جوائز فيه حمام مغربي، وجيم ٢٤ ساعة. على مسافة قريبة من التحرير والمتحف المصري والقاهرة القبطية. الأنسب لـ: رجال الأعمال، شهور العسل، والعائلات (نادي أطفال ممتاز).',
    star_rating: 5, price_per_night_usd: 350, rating: 4.8,
    amenities: ['Pool','Spa','Restaurant','Bar','Gym','Free WiFi','River View','Concierge'],
    image_urls: ['https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200&q=80'],
    booking_url: 'https://www.fourseasons.com/caironp/',
    latitude: 30.038, longitude: 31.231,
  },
  {
    name: 'Steigenberger El Tahrir', name_ar: 'شتايجنبرجر التحرير', city: 'cairo',
    description: '4-star city center base for travelers who want everything walkable. Expect: bright modern rooms, a Mediterranean rooftop restaurant, a small fitness center, and breakfast included. Step out the door and you are 2 minutes from the Egyptian Museum, 5 minutes from Tahrir Square, and 10 minutes from the Nile. Good for: solo travelers, couples on a budget, and 1-2 night stopovers focused on the museum.',
    description_ar: 'قاعدة وسط البلد ٤ نجوم للمسافرين اللي عايزين كل حاجة بالمشي. توقع: غرف عصرية مضيئة، مطعم متوسطي على السطح، جيم صغير، وفطار مشمول. تخرج من الباب وأنت على بعد دقيقتين من المتحف المصري، ٥ دقائق من ميدان التحرير، و١٠ دقايق من النيل. الأنسب لـ: المسافرين الفرديين، الأزواج بميزانية متوسطة، والإقامات القصيرة ١-٢ ليلة المركزة على المتحف.',
    star_rating: 4, price_per_night_usd: 130, rating: 4.3,
    amenities: ['Restaurant','Gym','Free WiFi','City View','Bar'],
    image_urls: ['https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=1200&q=80'],
    booking_url: null,
    latitude: 30.0444, longitude: 31.2357,
  },
  {
    name: 'Pyramids View Inn', name_ar: 'بيراميدز فيو إن', city: 'giza',
    description: 'Family-run 3-star boutique with the best rooftop in Giza for the price. Expect: simple but clean rooms, a famous rooftop terrace where you can have breakfast watching the Pyramids change color in the morning light, free WiFi throughout, and a friendly owner who arranges camel rides and Pyramid tours. 2-minute walk to the entrance gate. Best for: backpackers, photographers, and travelers who prioritize the view over the room size.',
    description_ar: 'فندق عائلي ٣ نجوم بأحسن سطح في الجيزة بالنسبة للسعر. توقع: غرف بسيطة لكن نظيفة، تراس سطح شهير تقدر تفطر فيه وأنت بتشوف الأهرامات بتغير لونها في ضوء الصباح، WiFi مجاني، وصاحب الفندق ودود وبيرتب رحلات جمال وجولات الأهرامات. على بعد دقيقتين من بوابة الدخول. الأنسب لـ: مسافري الظهر، المصورين، واللي مهتمين بالإطلالة أكتر من حجم الغرفة.',
    star_rating: 3, price_per_night_usd: 50, rating: 4.0,
    amenities: ['Free WiFi','Rooftop','Restaurant','Pyramid View'],
    image_urls: ['https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=1200&q=80'],
    booking_url: null,
    latitude: 29.9792, longitude: 31.1342,
  },
];

const ATTRACTIONS = [
  {
    name: 'Great Pyramids of Giza', name_ar: 'أهرامات الجيزة', city: 'giza',
    description: "The last surviving wonder of the ancient world. You'll see the three main pyramids (Khufu, Khafre, Menkaure), six smaller queens' pyramids, the Solar Boat Museum (Khufu's reassembled 4,600-year-old wooden boat), and the Workers' Cemetery. You can enter the Great Pyramid for an extra fee, climb the lower courses for photos, ride camels or horses around the plateau, and visit the panorama viewpoint where all 9 pyramids align. Come back at night for the Sound and Light Show.",
    description_ar: 'آخر عجائب الدنيا السبع الباقية. هتشوف الأهرامات الثلاثة الرئيسية (خوفو، خفرع، منقرع)، وستة أهرامات للملكات أصغر، ومتحف مركب الشمس (مركب خوفو الخشبية المعاد تجميعها بعمر ٤٦٠٠ سنة)، ومقابر العمال. تقدر تدخل الهرم الأكبر برسوم إضافية، تركب جمل أو حصان حول الهضبة، وتزور نقطة البانوراما اللي بتشوف منها الـ٩ أهرامات في خط واحد. ارجع بالليل لعرض الصوت والضوء.',
    category: 'Ancient', entry_fee_usd: 15, duration_hours: 3,
    opening_hours: { 'mon-sun': '8:00-17:00' }, wikipedia_slug: 'Great_Pyramid_of_Giza',
    latitude: 29.9792, longitude: 31.1342,
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Kheops-Pyramid.jpg/1200px-Kheops-Pyramid.jpg',
  },
  {
    name: 'Great Sphinx', name_ar: 'أبو الهول', city: 'giza',
    description: 'The 4,500-year-old guardian of the Giza plateau. Stand at the Sphinx terrace for the iconic photo with all three pyramids in the background. The statue is 73m long and 20m tall, carved from a single limestone bedrock with the body of a lion and head of pharaoh Khafre. Look for the Dream Stele between its paws (a 3,400-year-old inscription) and the famous missing nose. Best at sunrise when the light hits the face perfectly.',
    description_ar: 'حارس هضبة الجيزة من ٤٥٠٠ سنة. قف عند تراس أبو الهول للصورة الأيقونية مع الأهرامات الثلاثة في الخلفية. التمثال طوله ٧٣ متر وارتفاعه ٢٠ متر، منحوت من حجر جيري واحد بجسم أسد ورأس الفرعون خفرع. شوف لوحة الحلم بين قدميه (نقش عمره ٣٤٠٠ سنة) والأنف المفقود الشهير. الأحسن وقت الشروق لما الضوء بيقع على الوجه بشكل مثالي.',
    category: 'Ancient', entry_fee_usd: 0, duration_hours: 1,
    opening_hours: { 'mon-sun': '8:00-17:00' }, wikipedia_slug: 'Great_Sphinx_of_Giza',
    latitude: 29.9753, longitude: 31.1376,
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Great_Sphinx_of_Giza_-_20080716a.jpg/1200px-Great_Sphinx_of_Giza_-_20080716a.jpg',
  },
  {
    name: 'Egyptian Museum', name_ar: 'المتحف المصري', city: 'cairo',
    description: "The original 1902 museum on Tahrir Square, packed with 120,000+ artifacts spanning 5,000 years. Highlights you'll see: the Narmer Palette (unification of Egypt), giant statues from Memphis, dynastic-era jewelry, painted sarcophagi, and the Pre-Dynastic to Greco-Roman galleries. Pay extra for the Royal Mummies Hall to see Ramesses II and other pharaohs face-to-face. Note: most Tutankhamun items have moved to the new GEM, but original masks and minor pieces remain here.",
    description_ar: 'متحف ١٩٠٢ الأصلي في ميدان التحرير، مكدس بأكثر من ١٢٠ ألف قطعة على مدى ٥٠٠٠ سنة. أبرز اللي هتشوفه: لوحة نارمر (توحيد مصر)، تماثيل ضخمة من ممفيس، مجوهرات الأسرات، توابيت ملونة، وقاعات من ما قبل الأسرات لليوناني الروماني. ادفع زيادة لقاعة المومياوات الملكية لتشوف رمسيس الثاني وفراعنة تانيين. ملاحظة: معظم قطع توت عنخ آمون اتنقلت للمتحف الكبير، بس الأقنعة الأصلية والقطع الصغيرة لسه هنا.',
    category: 'Museum', entry_fee_usd: 12, duration_hours: 3,
    opening_hours: { 'mon-sun': '9:00-17:00' }, wikipedia_slug: 'Egyptian_Museum',
    latitude: 30.0478, longitude: 31.2336,
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Egyptian_Museum_in_Cairo.jpg/1200px-Egyptian_Museum_in_Cairo.jpg',
  },
  {
    name: 'Khan El-Khalili Bazaar', name_ar: 'خان الخليلي', city: 'cairo',
    description: "Cairo's 14th-century medieval bazaar, a maze of narrow alleys where you'll find handmade brass lanterns, perfume oils, papyrus, gold and silver jewelry, leather goods, spices, and Bedouin textiles. Sit at El-Fishawi café (open 250 years, served Naguib Mahfouz his coffee), watch coppersmiths hammer plates by hand, and visit the adjacent Al-Hussein Mosque. Haggling is expected, start at 30% of asking price. Best at sunset and during Ramadan evenings.",
    description_ar: 'سوق القاهرة القروسطي من القرن الـ١٤، متاهة من الأزقة الضيقة فيها فوانيس نحاسية يدوية، عطور، بردي، مجوهرات ذهب وفضة، جلديات، بهارات، ومنسوجات بدوية. اقعد في مقهى الفيشاوي (مفتوح ٢٥٠ سنة، نجيب محفوظ كان بيشرب قهوته هناك)، شوف النحاسين بيطرقوا الصواني باليد، وزور جامع الحسين المجاور. المساومة متوقعة، ابدأ بـ٣٠٪ من السعر المطلوب. الأحسن وقت الغروب وفي ليالي رمضان.',
    category: 'Market', entry_fee_usd: 0, duration_hours: 2,
    opening_hours: { 'mon-sun': '10:00-22:00' }, wikipedia_slug: 'Khan_el-Khalili',
    latitude: 30.0477, longitude: 31.2625,
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Khan_el-Khalili_-_panoramio.jpg/1200px-Khan_el-Khalili_-_panoramio.jpg',
  },
  {
    name: 'Grand Egyptian Museum', name_ar: 'المتحف المصري الكبير', city: 'giza',
    description: "The largest archaeological museum on Earth, opened steps from the Pyramids. The headline experience: the FULL Tutankhamun collection (all 5,400 objects) displayed together for the first time ever, including the gold death mask, three nested coffins, the chariots, and his folding bed. The Grand Staircase has 87 colossal royal statues climbing to a window with a direct view of the Pyramids. There are 12 themed galleries, a children's museum, the Khufu Solar Boats Museum, an IMAX cinema, and Egyptian-themed restaurants. Plan at least half a day.",
    description_ar: 'أكبر متحف أثري في العالم، افتتح على بعد خطوات من الأهرامات. التجربة الأبرز: مجموعة توت عنخ آمون كاملة (٥٤٠٠ قطعة) معروضة سوا لأول مرة، بما فيها قناع الذهب، التوابيت الثلاثة، العربات، وسريره القابل للطي. السلم الكبير فيه ٨٧ تمثال ملكي ضخم بيطلعوا لشباك مطل على الأهرامات مباشرة. ١٢ قاعة موضوعية، متحف للأطفال، متحف مراكب خوفو الشمسية، سينما IMAX، ومطاعم مصرية. خصص نص يوم على الأقل.',
    category: 'Museum', entry_fee_usd: 25, duration_hours: 4,
    opening_hours: { 'mon-sun': '9:00-19:00' }, wikipedia_slug: 'Grand_Egyptian_Museum',
    latitude: 29.9946, longitude: 31.1171,
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Grand_Egyptian_Museum_view.jpg/1200px-Grand_Egyptian_Museum_view.jpg',
  },
  {
    name: 'Cairo Tower', name_ar: 'برج القاهرة', city: 'cairo',
    description: "187m tall and decorated like a giant lotus stalk on Gezira Island. Take the elevator to the open-air observation deck for unobstructed 360-degree views: the Nile below you, downtown Cairo and Tahrir Square to the east, the Pyramids of Giza to the southwest on a clear day. The revolving restaurant on the next floor down completes a full rotation every hour while you eat. Stay until sunset, then watch the city light up. Cafe and gift shop at the base.",
    description_ar: 'ارتفاعه ١٨٧ متر ومزخرف زي ساق اللوتس العملاق في جزيرة الزمالك. اطلع بالمصعد لسطح المشاهدة المفتوح لإطلالة ٣٦٠ درجة بدون عوائق: النيل تحتك، وسط البلد وميدان التحرير شرقاً، أهرامات الجيزة جنوب غرب في الأيام الصافية. المطعم الدوار في الدور اللي تحت بيلف دورة كاملة كل ساعة وأنت بتأكل. ابقى للغروب وشوف المدينة بتنور. كافيه ومحل هدايا في الأسفل.',
    category: 'Landmark', entry_fee_usd: 8, duration_hours: 1.5,
    opening_hours: { 'mon-sun': '9:00-01:00' }, wikipedia_slug: 'Cairo_Tower',
    latitude: 30.0459, longitude: 31.2243,
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/Cairo_Tower_at_night_2007.jpg/1200px-Cairo_Tower_at_night_2007.jpg',
  },
];

const RESTAURANTS = [
  {
    name: 'Abou El Sid', name_ar: 'أبو السيد', city: 'cairo',
    description: 'Iconic traditional Egyptian restaurant in Zamalek. Serves authentic dishes in a vintage Khedivial-era setting.',
    description_ar: 'مطعم مصري تقليدي شهير في الزمالك، يقدم أطباق أصيلة في أجواء كلاسيكية من العصر الخديوي.',
    cuisine: 'Egyptian', cuisine_ar: 'مصري', price_range: 3, avg_meal_usd: 25, rating: 4.5,
    popular_dishes: ['Molokhia','Stuffed Pigeon','Koshari','Mahshi'],
    image_url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=1200&q=80',
    latitude: 30.0594, longitude: 31.2189,
  },
  {
    name: 'Felfela', name_ar: 'فلفلة', city: 'cairo',
    description: 'Famous downtown spot serving classic Egyptian street food since 1959. A Cairo legend with bright walls and folk decor.',
    description_ar: 'مكان شهير في وسط البلد يقدم الأكل المصري الشعبي الكلاسيكي منذ ١٩٥٩. أسطورة قاهرية بجدران زاهية.',
    cuisine: 'Egyptian', cuisine_ar: 'مصري', price_range: 1, avg_meal_usd: 8, rating: 4.3,
    popular_dishes: ['Foul','Falafel','Shawarma','Liver'],
    image_url: 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=1200&q=80',
    latitude: 30.0488, longitude: 31.2412,
  },
  {
    name: 'Koshary Abou Tarek', name_ar: 'كشري أبو طارق', city: 'cairo',
    description: 'The most legendary koshari shop in Egypt. Five floors of pure carb heaven downtown, a Cairo institution since 1950.',
    description_ar: 'أشهر محل كشري في مصر. خمسة أدوار من جنة الكشري في وسط البلد، مؤسسة قاهرية منذ ١٩٥٠.',
    cuisine: 'Street Food', cuisine_ar: 'أكل شعبي', price_range: 1, avg_meal_usd: 4, rating: 4.7,
    popular_dishes: ['Koshari','Macaroni','Lentils','Chickpeas'],
    image_url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=1200&q=80',
    latitude: 30.0526, longitude: 31.2402,
  },
  {
    name: '9 Pyramids Lounge', name_ar: 'تسعة أهرامات لاونج', city: 'giza',
    description: 'Restaurant inside the Pyramids complex with direct views of all 9 pyramids of the Giza Plateau. A truly unique meal.',
    description_ar: 'مطعم داخل منطقة الأهرامات بإطلالة مباشرة على الـ٩ أهرامات بهضبة الجيزة. تجربة أكل فريدة.',
    cuisine: 'Egyptian', cuisine_ar: 'مصري', price_range: 3, avg_meal_usd: 30, rating: 4.4,
    popular_dishes: ['Grilled Kofta','Mixed Grill','Mezze','Hummus'],
    image_url: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=1200&q=80',
    latitude: 29.9750, longitude: 31.1310,
  },
];

console.log('\n🏨 Upserting Cairo + Giza hotels...');
const { data: cities } = await supabase.from('cities').select('id, slug');
const cityMap = Object.fromEntries((cities || []).map(c => [c.slug, c.id]));

for (const h of HOTELS) {
  const city_id = cityMap[h.city];
  if (!city_id) continue;
  const { error } = await supabase.from('hotels').upsert({
    ...h, city_id, city: undefined,
  }, { onConflict: 'name' }).select();
  if (error) {
    const { error: insErr } = await supabase.from('hotels').insert({ ...h, city_id, city: undefined });
    if (insErr && insErr.code !== '23505') console.warn(' ', h.name, insErr.message);
  }
  console.log(' ✓', h.name);
}

console.log('\n📍 Upserting attractions...');
for (const a of ATTRACTIONS) {
  const city_id = cityMap[a.city];
  if (!city_id) continue;
  const { error } = await supabase.from('attractions').upsert({
    ...a, city_id, city: undefined,
  }, { onConflict: 'name' }).select();
  if (error) {
    await supabase.from('attractions').insert({ ...a, city_id, city: undefined });
  }
  console.log(' ✓', a.name);
}

console.log('\n🍽  Upserting restaurants...');
for (const r of RESTAURANTS) {
  const city_id = cityMap[r.city];
  if (!city_id) continue;
  const { data: existing } = await supabase.from('restaurants').select('id').eq('name', r.name).eq('city_id', city_id).maybeSingle();
  if (existing) {
    await supabase.from('restaurants').update({ ...r, city_id, city: undefined }).eq('id', existing.id);
  } else {
    await supabase.from('restaurants').insert({ ...r, city_id, city: undefined });
  }
  console.log(' ✓', r.name);
}

console.log('\n✨ Done. Cairo Trip is now Cairo-only with curated content.');
